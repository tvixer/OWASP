using System.Collections.ObjectModel;
using Application.Features.Solution.Errors;
using Application.MailTemplates;
using Application.Providers;
using Application.Services;
using Application.Services.Models;
using Domain.Enums;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using Microsoft.Extensions.Configuration;
using IResult = Ftsoft.Common.Result.IResult;

namespace Application.Features.Solution;

public class SendSolutionCommand : Command
{
    public long DirectionId { get; set; }
    public List<Answer> Answers { get; set; }

    public class Answer
    {
        public long QuestionId { get; set; }
        public string Text { get; set; }
    }
}

public class SendSolutionCommandHandler : CommandHandler<SendSolutionCommand>
{
    private readonly SolutionRepository _solutionRepository;
    private readonly EnrollRepository _enrollRepository;
    private readonly IUserRepository _userRepository;
    private readonly IEmailSenderService _emailSenderService;
    private readonly IQuestionRepository _questionRepository;
    private readonly IRazorRenderService _razorRenderService;
    private readonly DirectionRepository _directionRepository;
    private readonly IUserProvider _userProvider;
    private readonly IConfiguration _configuration;
    private readonly IDateProvider _dateProvider;

    private StudentUser _student;
    private Domain.Models.Direction _direction;
    private Enroll _enroll;

    public SendSolutionCommandHandler(
        SolutionRepository solutionRepository,
        IEmailSenderService emailSenderService,
        EnrollRepository enrollRepository,
        IUserRepository userRepository,
        DirectionRepository directionRepository,
        IUserProvider userProvider,
        IQuestionRepository questionRepository,
        IRazorRenderService razorRenderService,
        IDateProvider dateProvider, IConfiguration configuration)
    {
        _solutionRepository = solutionRepository;
        _emailSenderService = emailSenderService;
        _enrollRepository = enrollRepository;
        _userRepository = userRepository;
        _directionRepository = directionRepository;
        _userProvider = userProvider;
        _questionRepository = questionRepository;
        _razorRenderService = razorRenderService;
        _dateProvider = dateProvider;
        _configuration = configuration;
    }

    protected override async Task<IResult> CanHandle(SendSolutionCommand request, CancellationToken cancellationToken)
    {
        var direction = await _directionRepository.SingleOrDefaultAsync(x => x.Id == request.DirectionId,
            cancellationToken);
        if (direction == null)
            return Error(Direction.Errors.NotFoundError.Instance);
        if (_dateProvider.UtcNow() > direction.EndedAtUtc)
            return Error(AcceptingEndedError.Instance);

        var user = _userProvider.User;
        if (user is not StudentUser studentUser)
            return Error(NotFoundError.Instance);

        var enroll = await _enrollRepository.FirstOrDefaultAsync(x =>
            x.StudentId == user.Id && x.DirectionId == direction.Id, cancellationToken);
        if (enroll == null)
            return Error(NotFoundError.Instance);
        var solution = await _solutionRepository.FirstOrDefaultAsync(x =>
            x.AuthorId == user.Id && x.DirectionId == direction.Id, cancellationToken);
        if (solution is not null)
        {
            return Error(AlreadySent.Instance);
        }

        _enroll = enroll;
        _direction = direction;
        _student = studentUser;

        return Successful();
    }

    public override async Task<Result> Handle(SendSolutionCommand request, CancellationToken cancellationToken)
    {
        var utcNow = _dateProvider.UtcNow();

        var questions =
            await _questionRepository.ListAsync(x => x.DirectionId == request.DirectionId, cancellationToken);
        if (questions.Count != request.Answers.Count)
        {
            return Error(BadRequestError.Instance);
        }

        var questionIds = questions.Select(x => x.Id);
        var isQuestionIdsCorrect = request.Answers.All(x => questionIds.Contains(x.QuestionId));
        if (!isQuestionIdsCorrect)
        {
            return Error(BadRequestError.Instance);
        }

        var answers = new Collection<Domain.Models.Solution.Answer>(
            request.Answers
                .Select(x =>
                    new Domain.Models.Solution.Answer(x.Text, x.QuestionId,
                        questions.FirstOrDefault(q => q.Id == x.QuestionId)!.Text))
                .ToList());
        var solution = new Domain.Models.Solution(answers, SolutionStatus.OnCheck, utcNow, _student.Id,
            _student.GetFullname(), request.DirectionId, _direction.Title, _enroll.TutorId);
        await _solutionRepository.AddAsync(solution, cancellationToken);

        var tutor = await _userRepository.SingleOrDefaultAsync(x => x.Id == _enroll.TutorId && x.Role == UserRole.Tutor,
            cancellationToken);

        await _solutionRepository.UnitOfWork.SaveChangesAsync(cancellationToken);

        SendToTutor(solution, _student, tutor!.Email);
        return Successful();
    }

    private async Task SendToTutor(Domain.Models.Solution solution, BaseUser student,
        string tutorEmail)
    {
        var uri = _configuration.GetValue<string>("ClientUri");
        var checkLink = $"{uri}/checkSolution/{solution.Id}";
        var template = await _razorRenderService.RenderAsString("NewSolutionPage",
            new NewSolutionViewModel()
            {
                DirectionTitle = solution.DirectionTitle,
                SendedAt = solution.SentAtUtc.ToString("dd-MM-yy HH:mm:ss zz"),
                CheckLink = checkLink,
                UserEmail = student.Email,
                UserFullname = student.GetFullname()
            });
        _emailSenderService.Send(new Message(new[]
            {
                tutorEmail
            },
            $"Новое решение на U Summer School - {solution.DirectionTitle}",
            template,
            true
        ));
    }
}