namespace Application.Features.Solution.Models;

public class GetManySolutionsResponseDto
{
    public long Id { get; set; }
    public string Status { get; set; }
    public string StudentFullname { get; set; }
    public long SentAt { get; set; }
    public long StudentId { get; set; }
    public long DirectionId { get; set; }
}