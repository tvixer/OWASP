namespace Application.Features.Solution.Models;

public class SolutionSender
{
    public SolutionSender(long id, string fullname)
    {
        Id = id;
        Fullname = fullname;
    }

    public long Id { get; set; }
    public string Fullname { get; set; }
}