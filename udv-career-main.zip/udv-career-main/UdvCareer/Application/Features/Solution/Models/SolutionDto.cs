namespace Application.Features.Solution.Models;

public class SolutionDto
{
    public SolutionDto(long id, string link, long sentAt, string status, SolutionSender? student, long directionId,
        string? feedback)
    {
        Id = id;
        Link = link;
        SentAt = sentAt;
        Status = status;
        Student = student;
        DirectionId = directionId;
        Feedback = feedback;
    }

    public long Id { get; set; }
    public string Link { get; set; }
    public string? Feedback { get; set; }
    public long SentAt { get; set; }
    public string Status { get; set; }
    public SolutionSender? Student { get; set; }
    public long DirectionId { get; set; }
}