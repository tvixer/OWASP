namespace Application.Features.Solution.Models;

public class SendSolutionDto
{

}