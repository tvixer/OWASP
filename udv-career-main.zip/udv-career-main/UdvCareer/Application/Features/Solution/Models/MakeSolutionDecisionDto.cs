using Domain.Enums;

namespace Application.Features.Solution.Models;

public class MakeSolutionDecisionDto
{
    public SolutionStatus Status { get; set; }
    public string Message { get; set; }
}