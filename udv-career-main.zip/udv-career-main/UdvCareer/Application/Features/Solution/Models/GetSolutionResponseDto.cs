namespace Application.Features.Solution.Models;

public class GetSolutionResponseDto
{
    public List<GetSolutionResponseAnswerDto> Answers { get; set; }
    public long SentAt { get; set; }
    public string Status { get; set; }
    public SolutionSender? Student { get; set; }
    public TutorInfo Tutor { get; set; }
    public long AvailablePlaces { get; set; }

    public class GetSolutionResponseAnswerDto
    {
        public long QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string Text { get; set; }
    }

    public class TutorInfo
    {
        public long Id { get; set; }
        public string Fullname { get; set; }
    }
}