namespace Application.Features.Solution.Convert;

public static class SolutionConverter
{
   
}