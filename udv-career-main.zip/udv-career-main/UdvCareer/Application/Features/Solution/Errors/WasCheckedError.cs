using Ftsoft.Common.Result;

namespace Application.Features.Solution.Errors;

public class WasCheckedError : Error
{
    public static WasCheckedError Instance => new WasCheckedError();
    
    public override string Type => "Solution.WasCheckedError";
}