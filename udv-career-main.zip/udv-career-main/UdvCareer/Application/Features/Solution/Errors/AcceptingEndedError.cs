using Ftsoft.Common.Result;

namespace Application.Features.Solution.Errors;

public class AcceptingEndedError : Error
{
    public static AcceptingEndedError Instance => new AcceptingEndedError();

    public override string Type => "Solution.AcceptingEndedError";
}