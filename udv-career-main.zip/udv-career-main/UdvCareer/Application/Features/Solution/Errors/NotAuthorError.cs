using Ftsoft.Common.Result;

namespace Application.Features.Solution.Errors;

public class NotAuthorError : Error
{
    public static NotAuthorError Instance => new NotAuthorError();
    public override string Type => "Solution.NotAuthorError";
}