﻿using Ftsoft.Common.Result;

namespace Application.Features.Solution.Errors;

public class BadRequestError : Error
{
    public static BadRequestError Instance => new BadRequestError();
    public override string Type => "Solution.BadRequestError";
}