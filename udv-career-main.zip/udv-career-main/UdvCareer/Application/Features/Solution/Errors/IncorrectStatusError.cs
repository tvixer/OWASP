using Ftsoft.Common.Result;

namespace Application.Features.Solution.Errors;

public class IncorrectStatusError : Error
{
    public static IncorrectStatusError Instance => new IncorrectStatusError();
    public override string Type => "Solution.IncorrectStatusError";
}