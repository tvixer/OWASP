﻿using Ftsoft.Common.Result;

namespace Application.Features.Solution.Errors;

public class AlreadySent : Error
{
    public static AlreadySent Instance => new AlreadySent();
    public override string Type => "Solution.AlreadySent";
}