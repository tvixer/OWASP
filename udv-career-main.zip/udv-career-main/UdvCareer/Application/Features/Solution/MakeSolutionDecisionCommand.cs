using Application.Features.Solution.Errors;
using Application.Features.Solution.Models;
using Application.MailTemplates;
using Application.Providers;
using Application.Services;
using Application.Services.Models;
using Domain.Enums;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Application.Features.Solution;

public class MakeSolutionDecisionCommand : Command
{
    [FromRoute] public long Id { get; set; }
    [FromBody] public MakeSolutionDecisionDto Dto { get; set; }
}

public sealed class MakeVerdictCommandHandler : CommandHandler<MakeSolutionDecisionCommand>
{
    private readonly ISolutionRepository _solutionRepository;
    private readonly IStudentUserRepository _studentUserRepository;
    private readonly ISolutionMessageRepository _solutionMessageRepository;
    private readonly IDirectionRepository _directionRepository;
    private readonly IEmailSenderService _emailSenderService;
    private readonly IOfferRepository _offerRepository;
    private readonly IDateProvider _dateProvider;
    private readonly IUserProvider _userProvider;
    private readonly IConfiguration _configuration;
    private readonly IRazorRenderService _razorRenderService;

    private SolutionStatus _solutionStatus;
    private Domain.Models.Solution _solution;

    public MakeVerdictCommandHandler(
        ISolutionRepository solutionRepository,
        IStudentUserRepository studentUserRepository,
        IEmailSenderService emailSenderService,
        IDirectionRepository directionRepository,
        IOfferRepository offerRepository,
        IUserProvider userProvider,
        IDateProvider dateProvider,
        ISolutionMessageRepository solutionMessageRepository,
        IConfiguration configuration,
        IRazorRenderService razorRenderService)
    {
        _solutionRepository = solutionRepository;
        _studentUserRepository = studentUserRepository;
        _emailSenderService = emailSenderService;
        _directionRepository = directionRepository;
        _offerRepository = offerRepository;
        _userProvider = userProvider;
        _dateProvider = dateProvider;
        _solutionMessageRepository = solutionMessageRepository;
        _configuration = configuration;
        _razorRenderService = razorRenderService;
    }

    protected override async Task<IResult> CanHandle(MakeSolutionDecisionCommand request,
        CancellationToken cancellationToken)
    {
        var status = request.Dto.Status;
        if (status is SolutionStatus.OnCheck)
            return Error(IncorrectStatusError.Instance);
        var solution =
            await _solutionRepository.SingleOrDefaultAsync(x => x.Id == request.Id,
                cancellationToken);
        if (solution == null)
            return Error(NotFoundError.Instance);

        _solutionStatus = status;
        _solution = solution;
        return Successful();
    }

    public override async Task<Result> Handle(MakeSolutionDecisionCommand request, CancellationToken cancellationToken)
    {
        var decidedBefore = _solution.Status is not SolutionStatus.OnCheck;
        _solution.SetStatus(_solutionStatus);
        var offerExists =
            await _offerRepository.SingleOrDefaultAsync(x =>
                    x.DirectionId == _solution.DirectionId &&
                    x.OfferRecipientId == _solution.AuthorId,
                cancellationToken);
        if (offerExists is null && _solutionStatus == SolutionStatus.Approved)
        {
            offerExists = await CreateOffer(_solution, cancellationToken);
        }

        if (offerExists is not null && _solutionStatus == SolutionStatus.Rejected)
        {
            await _offerRepository.RemoveAsync(offerExists);
        }


        if (!decidedBefore)
        {
            await CreateFeedbackMessage(request.Dto.Message, _solution, cancellationToken);
        }

        await _solutionRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        await NotifyStudent(offerExists, _solution, cancellationToken);
        return Successful();
    }

    private async Task CreateFeedbackMessage(string message, Domain.Models.Solution solution,
        CancellationToken cancellationToken)
    {
        var solutionMessage = SolutionMessage.Create(
            solution.Id,
            _userProvider.User!.Id,
            message,
            false,
            _dateProvider.UtcNow());
        await _solutionMessageRepository.AddAsync(solutionMessage, cancellationToken);
    }

    private async Task<Domain.Models.Offer> CreateOffer(Domain.Models.Solution solution,
        CancellationToken cancellationToken)
    {
        var date = _dateProvider.UtcNow().AddDays(3);
        var offer = new Domain.Models.Offer(date, solution.DirectionId, solution.DirectionTitle,
            _userProvider.User!.Id, solution.AuthorId);
        await _offerRepository.AddAsync(offer, cancellationToken);
        return offer;
    }

    private async Task NotifyStudent(Domain.Models.Offer? offer, Domain.Models.Solution solution,
        CancellationToken cancellationToken)
    {
        var student =
            await _studentUserRepository.SingleOrDefaultAsync(x => x.Id == solution.AuthorId, cancellationToken);
        var uri = _configuration.GetValue<string>("ClientUri");
        var template = await _razorRenderService.RenderAsString("TutorCheckedSolution",
            new TutorCheckedSolutionViewModel()
            {
                DirectionTitle = solution.DirectionTitle,
                SolutionStatus = solution.Status,
                DirectionLink = $"{uri}/direction/{solution.DirectionId}",
                OffersLink = $"{uri}/offers",
                OfferEndDate = offer?.EndedAtUtc.ToString("dd-MM-yyyy hh:mm:ss z") ?? ""
            });
        await _emailSenderService.SendAsync(new Message(new[]
            {
                student.Email,
            }, "Ваше решение было оценено - U Summer School", template, true
        ));
    }
}