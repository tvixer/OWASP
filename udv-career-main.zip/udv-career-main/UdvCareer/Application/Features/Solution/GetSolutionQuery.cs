using Application.Features.Solution.Errors;
using Application.Features.Solution.Models;
using Application.Providers;
using Application.Services;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using NotFoundError = Application.Features.Hr.Errors.NotFoundError;

namespace Application.Features.Solution;

public class GetSolutionQuery : Query<GetSolutionResponseDto>
{
    public long SolutionId { get; set; }
}

public sealed class GetSolutionQueryHandler : QueryHandler<GetSolutionQuery, GetSolutionResponseDto>
{
    private readonly ISolutionRepository _solutionRepository;
    private readonly IDateService _dateService;
    private readonly IOfferRepository _offerRepository;
    private readonly IDirectionRepository _directionRepository;
    private readonly IUserProvider _userProvider;
    private readonly IEnrollRepository _enrollRepository;
    private readonly IUserRepository _userRepository;


    public GetSolutionQueryHandler(ISolutionRepository solutionRepository,
        IDateService dateService, IUserProvider userProvider, IOfferRepository offerRepository, IDirectionRepository directionRepository,
        IEnrollRepository enrollRepository, IUserRepository userRepository)
    {
        _solutionRepository = solutionRepository;
        _dateService = dateService;
        _userProvider = userProvider;
        _offerRepository = offerRepository;
        _directionRepository = directionRepository;
        _enrollRepository = enrollRepository;
        _userRepository = userRepository;
    }

    public override async Task<Result<GetSolutionResponseDto>> Handle(GetSolutionQuery request,
        CancellationToken cancellationToken)
    {
        var solution =
            await _solutionRepository.SingleOrDefaultAsync(x => x.Id == request.SolutionId, cancellationToken);
        if (_userProvider.User!.Role is UserRole.Student && solution.AuthorId != _userProvider.User.Id)
        {
            return Error(NotAuthorError.Instance);
        }
        
        if (_userProvider.User!.Role is UserRole.Tutor && solution.InspectorId != _userProvider.User.Id)
        {
            return Error(NotFoundError.Instance);
        }

        var enroll = await _enrollRepository.SingleOrDefaultAsync(
            x => x.DirectionId == solution.DirectionId && x.StudentId == solution.AuthorId,
            cancellationToken);
        var tutor = await _userRepository.SingleOrDefaultAsync(x => x.Id == enroll.TutorId, cancellationToken);

        var acceptedOffers = await _offerRepository.CountAsync(offer =>
                offer.DirectionId == solution.DirectionId && offer.Status == OfferStatus.Accepted,
            cancellationToken);
        var direction = await _directionRepository.FirstOrDefaultAsync(direction =>
                direction.Id == solution.DirectionId,
            cancellationToken);

        var solutionDto = new GetSolutionResponseDto()
        {
            AvailablePlaces = direction.WillBeAcceptedCount - acceptedOffers,
            Status = solution.Status.ToString(),
            SentAt = _dateService.ToUnixTimestamp(solution.SentAtUtc),
            Student = new SolutionSender(solution.AuthorId, solution.AuthorFullname),
            Tutor = new GetSolutionResponseDto.TutorInfo()
            {
                Id = tutor.Id,
                Fullname = tutor.GetFullname(),
            },
            Answers = solution.Answers.Select(x => new GetSolutionResponseDto.GetSolutionResponseAnswerDto()
            {
                Text = x.Text,
                QuestionId = x.QuestionId,
                QuestionText = x.QuestionText
            }).ToList()
        };
        return Successful(solutionDto);
    }
}