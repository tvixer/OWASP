using Application.Features.Solution.Models;
using Application.Models;
using Application.Providers;
using Application.Services;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.AspNetCore.Mvc;

namespace Application.Features.Solution;

public class GetManySolutionsQuery : Query<PaginatedListDto<GetManySolutionsResponseDto>>
{
    [FromQuery(Name = "directionId")] public long? DirectionId { get; set; }
    [FromQuery(Name = "studentId")] public long? StudentId { get; set; }
    [FromQuery(Name = "limit")] public int Limit { get; set; }
    [FromQuery(Name = "page")] public int Page { get; set; }
}

public sealed class
    GetManySolutionsQueryHandler : QueryHandler<GetManySolutionsQuery, PaginatedListDto<GetManySolutionsResponseDto>>
{
    private readonly ISolutionRepository _solutionRepository;
    private readonly IDateService _dateService;
    private readonly IUserProvider _userProvider;

    public GetManySolutionsQueryHandler(ISolutionRepository solutionRepository, IDateService dateService,
        IUserProvider userProvider)
    {
        _solutionRepository = solutionRepository;
        _dateService = dateService;
        _userProvider = userProvider;
    }

    public override async Task<Result<PaginatedListDto<GetManySolutionsResponseDto>>> Handle(
        GetManySolutionsQuery request,
        CancellationToken cancellationToken)
    {
        var skip = request.Page == 0
            ? 1
            : +(request.Page - 1) * request.Limit;
        var limit = request.Limit == 0 ? 20 : request.Limit;

        var solutions =
            await GetFilteredAndPaginatedSolutions(skip, limit, request.StudentId, request.DirectionId,
                cancellationToken);
        var total = await GetTotal(request.StudentId, request.DirectionId, cancellationToken);

        var solutionDtos = solutions.Select(Convert).ToList();
        var paginatedList = new PaginatedListDto<GetManySolutionsResponseDto>(solutionDtos, total);
        return Successful(paginatedList);
    }

    private async Task<IReadOnlyList<Domain.Models.Solution>> GetFilteredAndPaginatedSolutions(
        int skip, int limit, long? studentId, long? directionId,
        CancellationToken cancellationToken)
    {
        var solutions = await _solutionRepository.Query(queryable =>
        {
            if (directionId is not null)
            {
                queryable = queryable.Where(x => x.DirectionId == directionId);
            }

            if (studentId is not null)
            {
                queryable = queryable.Where(x => x.AuthorId == studentId);
            }

            return queryable
                .Where(x => x.InspectorId == _userProvider.User.Id)
                .Skip(skip)
                .Take(limit);
        }, cancellationToken);
        return solutions;
    }

    private async Task<int> GetTotal(long? studentId, long? directionId, CancellationToken cancellationToken)
    {
        int total;
        if (directionId is not null && studentId is not null)
        {
            total = await _solutionRepository.CountAsync(
                x =>
                    x.DirectionId == directionId &&
                    x.AuthorId == studentId &&
                    x.InspectorId == _userProvider.User.Id,
                cancellationToken);
        }
        else if (directionId is not null)
        {
            total = await _solutionRepository.CountAsync(
                x =>
                    x.DirectionId == directionId &&
                    x.InspectorId == _userProvider.User.Id,
                cancellationToken);
        }
        else if (studentId is not null)
        {
            total = await _solutionRepository.CountAsync(
                x =>
                    x.AuthorId == studentId &&
                    x.InspectorId == _userProvider.User.Id,
                cancellationToken);
        }
        else
        {
            total = await _solutionRepository.CountAsync(cancellationToken);
        }

        return total;
    }

    private GetManySolutionsResponseDto Convert(Domain.Models.Solution solution)
    {
        return new GetManySolutionsResponseDto()
        {
            StudentId = solution.AuthorId,
            StudentFullname = solution.AuthorFullname,
            DirectionId = solution.DirectionId,
            Status = solution.Status.ToString(),
            Id = solution.Id,
            SentAt = _dateService.ToUnixTimestamp(solution.SentAtUtc),
        };
    }
}