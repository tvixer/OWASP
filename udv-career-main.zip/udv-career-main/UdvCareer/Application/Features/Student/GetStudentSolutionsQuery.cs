using Application.Features.Student.DTOs;
using Application.Features.Student.Errors;
using Application.Providers;
using Application.Services;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Student;

public class GetStudentSolutionsQuery : Query<IReadOnlyList<GetStudentSolutionsResponseDto>>
{
    public long UserId { get; set; }
}

public sealed class
    GetStudentSolutionsQueryHandler : QueryHandler<GetStudentSolutionsQuery,
        IReadOnlyList<GetStudentSolutionsResponseDto>>
{
    private readonly ISolutionRepository _solutionRepository;
    private readonly IUserProvider _userProvider;
    private readonly IDateService _dateService;

    public GetStudentSolutionsQueryHandler(ISolutionRepository solutionRepository, IUserProvider userProvider,
        IDateService dateService)
    {
        _solutionRepository = solutionRepository;
        _userProvider = userProvider;
        _dateService = dateService;
    }

    public override async Task<Result<IReadOnlyList<GetStudentSolutionsResponseDto>>> Handle(
        GetStudentSolutionsQuery request, CancellationToken cancellationToken)
    {
        if (request.UserId != _userProvider.User!.Id)
        {
            return Error(StudentForbiddenError.Instance);
        }

        var solutions = await _solutionRepository.ListAsync(x => x.AuthorId == request.UserId, cancellationToken);

        var solutionsResponseDtos = solutions.Select(x => new GetStudentSolutionsResponseDto()
        {
            Id = x.Id,
            Status = x.Status.ToString(),
            DirectionId = x.DirectionId,
            DirectionTitle = x.DirectionTitle,
            SentAt = _dateService.ToUnixTimestamp(x.SentAtUtc)
        }).ToList();

        return Successful(solutionsResponseDtos);
    }
}