using Application.Features.Student.DTOs;
using Domain.Models;

namespace Application.Features.Student.Converters;

public class StudentConverter
{
    public static StudentDto Convert(StudentUser student)
    {
        return new StudentDto(student.Id, student.Name, student.Surname, student.Patronymic, student.Phone, student.Institute,
            student.Specialization, student.DirectionType.ToString(), student.IsBanned, student.Course);
    }

    public static IReadOnlyList<StudentDto> Convert(IEnumerable<StudentUser> students)
    {
        return students.Select(Convert).ToList();
    }
}