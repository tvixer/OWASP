using System.Data;
using ClosedXML.Excel;
using Domain.Enums;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Student;

public class ExportStudentsQuery : Query<byte[]>
{
}

public sealed class ExportStudentsQueryHandler : QueryHandler<ExportStudentsQuery, byte[]>
{
    private readonly IStudentUserRepository _studentUserRepository;
    private readonly IDirectionRepository _directionRepository;
    private readonly IEnrollRepository _enrollRepository;
    private readonly IOfferRepository _offerRepository;
    private readonly ISolutionRepository _solutionRepository;

    public ExportStudentsQueryHandler(
        IStudentUserRepository studentUserRepository,
        IDirectionRepository directionRepository,
        IEnrollRepository enrollRepository,
        ISolutionRepository solutionRepository, IOfferRepository offerRepository)
    {
        _studentUserRepository = studentUserRepository;
        _directionRepository = directionRepository;
        _enrollRepository = enrollRepository;
        _solutionRepository = solutionRepository;
        _offerRepository = offerRepository;
    }

    public override async Task<Result<byte[]>> Handle(ExportStudentsQuery request, CancellationToken cancellationToken)
    {
        var students =
            await _studentUserRepository.ListAsync(su =>
                su.IsConfirmed && su.Role == UserRole.Student, cancellationToken);
        var directions =
            await _directionRepository.ListAsync(cancellationToken);
        var solutions = await _solutionRepository.ListAsync(cancellationToken);

        var directionsColumns = directions.OrderBy(x => x.Title).Select(x => new DataColumn(x.Title))
            .ToArray();


        var dt = new DataTable("Grid");
        AddColumns(dt, directionsColumns);
        foreach (var student in students)
        {
            await AddStudentRow(student, solutions, dt, cancellationToken);
        }

        using var wb = new XLWorkbook();
        wb.Worksheets.Add(dt);
        using var stream = new MemoryStream();
        wb.SaveAs(stream);
        return Successful(stream.ToArray());
    }

    private async Task AddStudentRow(StudentUser student,
        IReadOnlyList<Domain.Models.Solution> solutions,
        DataTable dt, CancellationToken cancellationToken)
    {
        var studentSolutions = await _enrollRepository.Query(
            x =>
                x
                    .Where(enroll => enroll.StudentId == student.Id), cancellationToken);
        var row = dt.NewRow();
        row["ФИО"] = student.GetFullname();
        row["Telegram"] = student.TelegramUsername;
        row["Номер телефона"] = student.Phone;
        row["Институт"] = student.Institute;
        row["Специализация"] = student.Specialization;
        row["Тип направления"] = student.GetHumanizedDirectionType();
        var offer = await _offerRepository.SingleOrDefaultAsync(
            x => x.OfferRecipientId == student.Id && x.Status == OfferStatus.Accepted, cancellationToken);
        row["Итоговое место практики"] = offer?.DirectionTitle ?? "-";

        foreach (var completedSolution in studentSolutions)
        {
            var solution = solutions.FirstOrDefault(x =>
                x.DirectionId == completedSolution.DirectionId && x.AuthorId == completedSolution.StudentId);
            if (solution is not null)
            {
                row[solution.DirectionTitle] = $"да ({solution.SentAtUtc})";
            }
        }

        dt.Rows.Add(row);
    }

    private static void AddColumns(DataTable dt, DataColumn[] directionsColumns)
    {
        dt.Columns.AddRange(new DataColumn[]
        {
            new("ФИО"),
            new("Telegram"),
            new("Номер телефона"),
            new("Институт"),
            new("Специализация"),
            new("Тип направления"),
            new("Фактическое место практики"),
            new("Итоговое место практики")
        });
        dt.Columns.AddRange(directionsColumns);
    }
}