namespace Application.Features.Student.DTOs;

public class UpdateStudentDto
{
    public string Institute { get; set; }
    public string Specialization { get; set; }
    public int Course { get; set; }
    public string DirectionType { get; set; }
}