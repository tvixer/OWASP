namespace Application.Features.Student.DTOs;

public class StudentDto
{
    public StudentDto(long id, string name, string surname, string patronymic, string phone, string institute,
        string specialization, string directionType, bool isBanned, int course)
    {
        Id = id;
        IsBanned = isBanned;
        Course = course;
        Name = name;
        Surname = surname;
        Patronymic = patronymic;
        Phone = phone;
        Institute = institute;
        Specialization = specialization;
        DirectionType = directionType;
    }

    public int Course { get; set; }
    public long Id { get; set; }
    public bool IsBanned { get; set; }
    public string Name { get; set; }
    public string Surname { get; set; }
    public string Patronymic { get; set; }
    public string Phone { get; set; }
    public string Institute { get; set; }
    public string Specialization { get; set; }
    public string DirectionType { get; set; }
}