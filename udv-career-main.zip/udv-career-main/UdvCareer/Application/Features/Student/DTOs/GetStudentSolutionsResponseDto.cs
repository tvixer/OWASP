namespace Application.Features.Student.DTOs;

public class GetStudentSolutionsResponseDto
{
    public long Id { get; set; }
    public string Status { get; set; }
    public long SentAt { get; set; }
    public long DirectionId { get; set; }
    public string DirectionTitle { get; set; }
}