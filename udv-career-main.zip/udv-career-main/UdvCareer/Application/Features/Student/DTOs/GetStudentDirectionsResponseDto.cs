using Application.Features.Direction.DTOs;

namespace Application.Features.Student.DTOs;

public class GetStudentDirectionsResponseDto : DirectionDto
{
}