using Application.Features.Student.DTOs;
using Application.Features.Student.Errors;
using Application.Providers;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Student;

public class UpdateStudentCommand : Command
{
    public long Id { get; set; }
    public UpdateStudentDto UpdateStudentDto { get; set; }
}

public sealed class UpdateStudentCommandHandler : CommandHandler<UpdateStudentCommand>
{
    private readonly IUserProvider _userProvider;
    private readonly IStudentUserRepository _studentUserRepository;

    public UpdateStudentCommandHandler(IUserProvider userProvider, IStudentUserRepository studentUserRepository)
    {
        _userProvider = userProvider;
        _studentUserRepository = studentUserRepository;
    }

    public override async Task<Result> Handle(UpdateStudentCommand request, CancellationToken cancellationToken)
    {
        var user = _userProvider.User!;
        if (user.Role == UserRole.Student && request.Id != user.Id)
        {
            return Error(NotFoundError.Instance);
        }

        var studentUser = await _studentUserRepository.SingleOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
        if (studentUser == null)
        {
            return Error(NotFoundError.Instance);
        }

        var updateStudentDto = request.UpdateStudentDto;
        var isParsed = Enum.TryParse<DirectionType>(updateStudentDto.DirectionType, out var directionType);
        if (!isParsed)
            return Error(IncorrectDirectionTypeError.Instance);

        studentUser.UpdateStudentInfo(updateStudentDto.Course, updateStudentDto.Institute,
            updateStudentDto.Specialization, directionType);

        await _studentUserRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful();
    }
}