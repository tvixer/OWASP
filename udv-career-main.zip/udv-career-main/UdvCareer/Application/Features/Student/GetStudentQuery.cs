using Application.Features.Student.Converters;
using Application.Features.Student.DTOs;
using Application.Features.Student.Errors;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace Application.Features.Student;

public class GetStudentQuery : Query<StudentDto>
{
    [FromRoute] public long Id { get; set; }
}

public sealed class GetStudentQueryHandler : QueryHandler<GetStudentQuery, StudentDto>
{
    private readonly StudentUserRepository _studentUserRepository;

    public GetStudentQueryHandler(StudentUserRepository studentUserRepository)
    {
        _studentUserRepository = studentUserRepository;
    }

    public override async Task<Result<StudentDto>> Handle(GetStudentQuery request, CancellationToken cancellationToken)
    {
        var student =
            await _studentUserRepository.SingleOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
        if (student == null)
            return Error(NotFoundError.Instance);
        return Successful(StudentConverter.Convert(student));
    }
}