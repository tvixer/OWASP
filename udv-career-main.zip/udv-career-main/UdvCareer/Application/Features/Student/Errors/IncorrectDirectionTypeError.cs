using Ftsoft.Common.Result;

namespace Application.Features.Student.Errors;

public class IncorrectDirectionTypeError : Error
{
    public static IncorrectDirectionTypeError Instance => new IncorrectDirectionTypeError();
    public override string Type => "Student.IncorrectDirectionTypeError";
}