using Ftsoft.Common.Result;

namespace Application.Features.Student.Errors;

public class NotFoundError : Error
{
    public static NotFoundError Instance => new NotFoundError();
    public override string Type => "Student.NotFoundError";
}