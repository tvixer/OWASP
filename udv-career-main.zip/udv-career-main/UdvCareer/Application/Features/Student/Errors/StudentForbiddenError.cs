using Ftsoft.Common.Result;

namespace Application.Features.Student.Errors;

public class StudentForbiddenError : Error
{
    public static StudentForbiddenError Instance => new StudentForbiddenError();
    public override string Type => "Student.ForbiddenError";
    
}