using Application.Features.Student.DTOs;
using Application.Features.User.Errors;
using Application.Providers;
using Application.Services;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Student;

public class GetStudentDirectionsQuery : Query<IReadOnlyList<GetStudentDirectionsResponseDto>>
{
    public long Id { get; set; }
}

public sealed class
    GetStudentDirectionsQueryHandler : QueryHandler<GetStudentDirectionsQuery,
        IReadOnlyList<GetStudentDirectionsResponseDto>>
{
    private readonly IStudentUserRepository _studentUserRepository;
    private readonly IEnrollRepository _enrollRepository;
    private readonly IUserProvider _userProvider;
    private readonly IDirectionRepository _directionRepository;
    private readonly IDateService _dateService;

    public GetStudentDirectionsQueryHandler(
        IStudentUserRepository studentUserRepository,
        IEnrollRepository enrollRepository,
        IUserProvider userProvider,
        IDirectionRepository directionRepository, IDateService dateService)
    {
        _directionRepository = directionRepository;
        _dateService = dateService;
        _studentUserRepository = studentUserRepository;
        _enrollRepository = enrollRepository;
        _userProvider = userProvider;
    }

    public override async Task<Result<IReadOnlyList<GetStudentDirectionsResponseDto>>> Handle(
        GetStudentDirectionsQuery request,
        CancellationToken cancellationToken)
    {
        var currentUser = _userProvider.User;
        if (currentUser == null)
        {
            return Error(NotFoundError.Instance);
        }

        var student = await _studentUserRepository.SingleOrDefaultAsync(
            x => x.Id == request.Id,
            cancellationToken);
        if (student == null || (currentUser.Role == UserRole.Student && student.Id != currentUser.Id))
        {
            return Error(Errors.NotFoundError.Instance);
        }

        var enrolls = await _enrollRepository.ListAsync(enroll =>
                enroll.StudentId == student.Id,
            cancellationToken);
        var directionIds = enrolls.Select(x => x.DirectionId).ToArray();
        var directions =
            await _directionRepository.ListAsync(x => directionIds.Contains(x.Id) && x.IsActive, cancellationToken);
        return Successful(directions.Select(Convert).ToList());
    }

    private GetStudentDirectionsResponseDto Convert(Domain.Models.Direction direction)
    {
        var dto = new GetStudentDirectionsResponseDto()
        {
            Id = direction.Id,
            Title = direction.Title,
            Description = direction.Description,
            AvailablePlaces = direction.WillBeAcceptedCount,
            Department = direction.Department.ToString(),
            IsActive = direction.IsActive,
            FinishAcceptingAt = _dateService.ToUnixTimestamp(direction.EndedAtUtc),
        };
        return dto;
    }
}