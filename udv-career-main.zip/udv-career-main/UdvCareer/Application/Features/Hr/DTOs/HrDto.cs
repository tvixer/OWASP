namespace Application.Features.Hr.DTOs;

public class HrDto
{
    
    public HrDto(string name, string surname, string patronymic, string phone)
    {
        Name = name;
        Surname = surname;
        Patronymic = patronymic;
        Phone = phone;
    }

    public string Name { get; set; }
    public string Surname { get; set; }
    public string Patronymic { get; set; }
    public string Phone { get; set; }
}