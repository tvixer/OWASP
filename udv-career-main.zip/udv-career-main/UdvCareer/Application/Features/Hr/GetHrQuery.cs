using Application.Features.Hr.DTOs;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using Microsoft.AspNetCore.Mvc;
using NotFoundError = Application.Features.Hr.Errors.NotFoundError;

namespace Application.Features.Hr;

public class GetHrQuery : Query<HrDto>
{
    [FromRoute] public long Id { get; set; }
}

public sealed class GetHrQueryHandler : QueryHandler<GetHrQuery, HrDto>
{
    private readonly HrUserRepository _hrUserRepository;

    public GetHrQueryHandler(HrUserRepository hrUserRepository)
    {
        _hrUserRepository = hrUserRepository;
    }

    public override async Task<Result<HrDto>> Handle(GetHrQuery request, CancellationToken cancellationToken)
    {
        var tutorUser = await _hrUserRepository.SingleOrDefaultAsync(x => x.Id == request.Id,
            cancellationToken: cancellationToken);
        if (tutorUser == null)
            return Error(NotFoundError.Instance);
        var dto = new HrDto(tutorUser.Name, tutorUser.Surname, tutorUser.Patronymic,
            tutorUser.Phone);
        return Successful(dto);
    }
}