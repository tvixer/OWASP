using Application.Features.User.DTOs;
using Application.Models;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.User;

public class GetManyUsersQuery : Query<PaginatedListDto<GetManyUsersDto>>
{
    public string? Role { get; set; }
    public int Limit { get; set; }
    public int Page { get; set; }
}

public sealed class GetManyUsersQueryHandler : QueryHandler<GetManyUsersQuery, PaginatedListDto<GetManyUsersDto>>
{
    private readonly IUserRepository _userRepository;

    public GetManyUsersQueryHandler(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public override async Task<Result<PaginatedListDto<GetManyUsersDto>>> Handle(GetManyUsersQuery request,
        CancellationToken cancellationToken)
    {
        var page = request.Page <= 0 ? 1 : request.Page;
        var skip = +(page - 1) * request.Limit;
        var limit = request.Limit == 0 ? 16 : request.Limit;
        var isRoleParsed = Enum.TryParse<UserRole>(request.Role, out var role);
        var users = await _userRepository.Query(query =>
        {
            query = !isRoleParsed ? query : query.Where(x => x.Role == role);
            return query.Skip(skip).Take(limit);
        }, cancellationToken);
        var items = users.Select(x =>
                new GetManyUsersDto(x.Id,
                    x.Email, x.Name, x.Surname, x.Patronymic, x.Phone, x.IsConfirmed, x.IsBanned, x.Role.ToString()))
            .ToList();

        int total;
        if (isRoleParsed)
        {
            total = await _userRepository.CountAsync(x => x.Role == role, cancellationToken);
        }
        else
        {
            total = await _userRepository.CountAsync(cancellationToken);
        }

        var paginatedList = new PaginatedListDto<GetManyUsersDto>(items, total);
        return Successful(paginatedList);
    }
}