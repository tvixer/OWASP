namespace Application.Features.User.DTOs;

public class GetManyUsersDto
{
    public GetManyUsersDto(long id, string email, string name, string surname, string patronymic, string phone, bool isConfirmed, bool isBanned,
        string role)
    {
        Id = id;
        Email = email;
        Name = name;
        Surname = surname;
        Patronymic = patronymic;
        Phone = phone;
        IsConfirmed = isConfirmed;
        IsBanned = isBanned;
        Role = role;
    }
    public long Id { get; set; }
    public string Role { get; set; }
    public string Email { get; set; }
    public string Name { get; set; }
    public string Surname { get; set; }
    public string Patronymic { get; set; }
    public string Phone { get; set; }
    public bool IsConfirmed { get; set; }
    public bool IsBanned { get; set; }
}