namespace Application.Features.User.DTOs;

public class UserDto
{
    public UserDto(string email, string name, string surname, string patronymic, string phone, bool isConfirmed,
        string role, string telegramUsername)
    {
        Email = email;
        Name = name;
        Surname = surname;
        Patronymic = patronymic;
        Phone = phone;
        IsConfirmed = isConfirmed;
        Role = role;
        TelegramUsername = telegramUsername;
    }

    public string Role { get; set; }
    public string TelegramUsername { get; set; }
    public string Email { get; set; }
    public string Name { get; set; }
    public string Surname { get; set; }
    public string Patronymic { get; set; }
    public string Phone { get; set; }
    public bool IsConfirmed { get; set; }

    public StudentAdditionalInfo? StudentInfo { get; set; }
}