namespace Application.Features.User.DTOs;

public class StudentAdditionalInfo
{
    public StudentAdditionalInfo(string institute, string specialization, int course, string directionType)
    {
        Institute = institute;
        Specialization = specialization;
        Course = course;
        DirectionType = directionType;
    }

    public string Institute { get; set; }
    public string Specialization { get; set; }
    public int Course { get; set; }
    public string DirectionType { get; set; }
}