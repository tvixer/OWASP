using Application.Features.SolutionMessages.Models;
using Application.Providers;
using Application.Services;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.SolutionMessages;

public class GetSolutionMessagesQuery : Query<IReadOnlyList<SolutionMessageDto>>
{
    public long SolutionId { get; set; }
}

public sealed class GetSolutionMessagesQueryHandler : QueryHandler<GetSolutionMessagesQuery, IReadOnlyList<SolutionMessageDto>>
{
    private readonly ISolutionMessageRepository _solutionMessageRepository;
    private readonly ISolutionRepository _solutionRepository;
    private readonly IUserProvider _userProvider;
    private readonly IDateService _dateService;

    public GetSolutionMessagesQueryHandler(ISolutionMessageRepository solutionMessageRepository, IUserProvider userProvider,
        ISolutionRepository solutionRepository, IDateService dateService)
    {
        _solutionMessageRepository = solutionMessageRepository;
        _userProvider = userProvider;
        _solutionRepository = solutionRepository;
        _dateService = dateService;
    }
    public override async Task<Result<IReadOnlyList<SolutionMessageDto>>> Handle(GetSolutionMessagesQuery request,
        CancellationToken cancellationToken)
    {
        var solution = await _solutionRepository.FirstOrDefaultAsync(x => x.Id == request.SolutionId, cancellationToken);
        if (solution is null)
        {
            return Error(Solution.Errors.NotFoundError.Instance);
        }

        var currentUser = _userProvider.User;
        if (currentUser is null || (currentUser.Id != solution.AuthorId && currentUser.Role is UserRole.Student))
        {
            return Error(Solution.Errors.NotFoundError.Instance);
        }


        var messages = await _solutionMessageRepository.ListAsync(x => x.SolutionId == request.SolutionId, cancellationToken);
        var messagesDto = messages.Select(x => new SolutionMessageDto()
        {
            Id = x.Id,
            FromUserId = x.FromUserId,
            SentAtUtc = _dateService.ToUnixTimestamp(x.SentAtUtc),
            Text = x.Text,
        }).ToList();
        return Successful(messagesDto);
    }
}