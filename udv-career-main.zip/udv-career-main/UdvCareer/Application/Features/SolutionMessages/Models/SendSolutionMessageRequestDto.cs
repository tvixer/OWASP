namespace Application.Features.SolutionMessages.Models;

public record SendSolutionMessageRequestDto(string Text);
