namespace Application.Features.SolutionMessages.Models;

public class GetSolutionMessagesDto
{
    public IReadOnlyList<SolutionMessageDto> Messages { get; set; }
    public long[] MembersIds { get; set; }

}