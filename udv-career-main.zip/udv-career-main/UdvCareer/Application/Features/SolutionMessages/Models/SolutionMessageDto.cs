namespace Application.Features.SolutionMessages.Models;

public class SolutionMessageDto
{
    public long Id { get; set; }
    public long FromUserId { get; set; }
    public string Text { get; set; }
    public long SentAtUtc { get; set; }
}