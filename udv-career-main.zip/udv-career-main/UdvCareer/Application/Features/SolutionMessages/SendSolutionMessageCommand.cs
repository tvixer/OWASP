using Application.Features.Solution.Errors;
using Application.Features.SolutionMessages.Models;
using Application.Providers;
using Application.Services;
using Application.Services.Models;
using Domain.Enums;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.Extensions.Configuration;

namespace Application.Features.SolutionMessages;

public class SendSolutionMessageCommand : Command
{
    public long Id { get; set; }
    public SendSolutionMessageRequestDto SendSolutionMessageRequestDto { get; set; }
}

public sealed class SendSolutionMessageCommandHandler : CommandHandler<SendSolutionMessageCommand>
{
    private readonly ISolutionMessageRepository _solutionMessageRepository;
    private readonly ISolutionRepository _solutionRepository;
    private readonly IEnrollRepository _enrollRepository;
    private readonly IUserRepository _userRepository;
    private readonly IDateProvider _dateProvider;
    private readonly IConfiguration _configuration;
    private readonly IUserProvider _userProvider;
    private readonly IEmailSenderService _emailSenderService;

    private Domain.Models.Solution _solution;

    public SendSolutionMessageCommandHandler(
        ISolutionMessageRepository solutionMessageRepository,
        ISolutionRepository solutionRepository,
        IUserProvider userProvider,
        IEnrollRepository enrollRepository,
        IDateProvider dateProvider,
        IConfiguration configuration,
        IEmailSenderService emailSenderService, IUserRepository userRepository)
    {
        _solutionMessageRepository = solutionMessageRepository;
        _solutionRepository = solutionRepository;
        _userProvider = userProvider;
        _enrollRepository = enrollRepository;
        _dateProvider = dateProvider;
        _configuration = configuration;
        _emailSenderService = emailSenderService;
        _userRepository = userRepository;
    }

    protected override async Task<IResult> CanHandle(SendSolutionMessageCommand request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(request.SendSolutionMessageRequestDto.Text))
        {
            return Error(BadRequestError.Instance);
        }

        var solution = await _solutionRepository.SingleOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
        if (solution is null)
        {
            return Error(Solution.Errors.NotFoundError.Instance);
        }

        if (solution.Status is SolutionStatus.OnCheck)
        {
            return Error(Solution.Errors.IncorrectStatusError.Instance);
        }

        var user = _userProvider.User!;
        var enroll = user.Role switch
        {
            UserRole.Student => await _enrollRepository.SingleOrDefaultAsync(
                x => x.DirectionId == solution.DirectionId && x.StudentId == user.Id, cancellationToken),
            UserRole.Tutor => await _enrollRepository.FirstOrDefaultAsync(
                x => x.DirectionId == solution.DirectionId && x.TutorId == user.Id && x.StudentId == solution.AuthorId,
                cancellationToken),
            _ => null
        };

        _solution = solution;

        return enroll is null ? Error(Solution.Errors.NotFoundError.Instance) : Successful();
    }

    public override async Task<Result> Handle(SendSolutionMessageCommand request, CancellationToken cancellationToken)
    {
        var message = SolutionMessage.Create(
            request.Id,
            _userProvider.User!.Id,
            request.SendSolutionMessageRequestDto.Text,
            false,
            _dateProvider.UtcNow());
        await _solutionMessageRepository.AddAsync(message, cancellationToken);
        await _solutionMessageRepository.UnitOfWork.SaveChangesAsync(cancellationToken);

        await SendEmail(cancellationToken);

        return Successful();
    }

    private async Task SendEmail(CancellationToken cancellationToken)
    {
        const string subject = "Новое сообщение!";
        var link = string.Empty;
        var clientUri = _configuration.GetValue<string>("ClientUri");
        var toEmail = string.Empty;
        if (_userProvider.User!.Role is UserRole.Student)
        {
            var tutor = await _userRepository.SingleOrDefaultAsync(x => x.Id == _solution.InspectorId,
                cancellationToken);
            toEmail = tutor?.Email;
            link = $"{clientUri}/checkSolution/{_solution.Id}";
        }

        if (_userProvider.User.Role is UserRole.Tutor)
        {
            var student =
                await _userRepository.SingleOrDefaultAsync(x => x.Id == _solution.AuthorId, cancellationToken);
            toEmail = student?.Email;
            link = $"{clientUri}/direction/{_solution.DirectionId}";
        }

        var content =
            $"Вам пришло новое сообщение от пользователя \"{_userProvider.User.GetFullname()}\" в чате направления {_solution.DirectionTitle}\nПрочитать: {link}";
        var emailMessage = new Message(new[] { toEmail }!, subject, content);
        _emailSenderService.SendAsync(emailMessage);
    }
}