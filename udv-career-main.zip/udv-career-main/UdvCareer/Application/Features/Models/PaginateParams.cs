﻿using Microsoft.AspNetCore.Mvc;

namespace Application.Features.Models;

public class PaginateParams
{
    [FromQuery(Name = "limit")] public int Limit { get; set; }
    [FromQuery(Name = "page")] public int Page { get; set; }
}