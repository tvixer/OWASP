using Application.Features.Direction.DTOs;
using Application.Features.Tutor.Errors;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
namespace Application.Features.Tutor;

public class GetTutorDirectionsQuery : Query<IReadOnlyList<TutorDirectionDto>>
{
    public long Id { get; set; }
}

public sealed class
    GetTutorDirectionsQueryHandler : QueryHandler<GetTutorDirectionsQuery, IReadOnlyList<TutorDirectionDto>>
{
    private readonly ITutorUserRepository _tutorUserRepository;
    private readonly IDirectionTutorRepository _directionTutorRepository;
    private readonly IDirectionRepository _directionRepository;

    public GetTutorDirectionsQueryHandler(ITutorUserRepository tutorUserRepository,
        IDirectionTutorRepository directionTutorRepository, IDirectionRepository directionRepository)
    {
        _tutorUserRepository = tutorUserRepository;
        _directionTutorRepository = directionTutorRepository;
        _directionRepository = directionRepository;
    }

    public override async Task<Result<IReadOnlyList<TutorDirectionDto>>> Handle(GetTutorDirectionsQuery request,
        CancellationToken cancellationToken)
    {
        var tutor = await _tutorUserRepository.SingleOrDefaultAsync(
            x => x.Id == request.Id,
            cancellationToken);
        if (tutor == null)
            return Error(NotFoundError.Instance);
        var tutorDirections =
            await _directionTutorRepository.Query(
                x => x.Where(dt => dt.TutorId == tutor.Id).Select(x => x.DirectionId),
                cancellationToken);
        var directions = await _directionRepository.ListAsync(x => tutorDirections.Contains(x.Id), cancellationToken);
        return Successful(Convert(directions));
    }

    private TutorDirectionDto Convert(Domain.Models.Direction direction)
    {
        return new TutorDirectionDto()
        {
            Description = direction.Description,
            Id = direction.Id,
            Title = direction.Title,
        };
    }

    private IReadOnlyList<TutorDirectionDto> Convert(IEnumerable<Domain.Models.Direction> directionTutors)
    {
        return directionTutors.Select(Convert).ToList();
    }
}