using Application.Features.Tutor.DTOs;
using Application.Features.Tutor.Errors;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;

namespace Application.Features.Tutor;

public class GetTutorProfileQuery : Query<TutorDto>
{
    public long TutorId { get; set; }
}

public sealed class GetTutorProfileQueryHandler : QueryHandler<GetTutorProfileQuery, TutorDto>
{
    private readonly TutorUserRepository _tutorUserRepository;

    public GetTutorProfileQueryHandler(
        TutorUserRepository tutorUserRepository)
    {
        _tutorUserRepository = tutorUserRepository;
    }

    public override async Task<Result<TutorDto>> Handle(GetTutorProfileQuery request,
        CancellationToken cancellationToken)
    {
        var tutorUser = await _tutorUserRepository.SingleOrDefaultAsync(x => x.Id == request.TutorId,
            cancellationToken: cancellationToken);
        if (tutorUser == null)
            return Error(NotFoundError.Instance);
        var dto = new TutorDto(tutorUser.Name, tutorUser.Surname, tutorUser.Patronymic,
            tutorUser.Phone);
        return Successful(dto);
    }
}