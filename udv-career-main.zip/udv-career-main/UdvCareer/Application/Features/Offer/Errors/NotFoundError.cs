using Ftsoft.Common.Result;

namespace Application.Features.Offer.Errors;

public class NotFoundError : Error
{
    public static NotFoundError Instance => new NotFoundError();
    public override string Type => "Offer.NotFoundError";
}