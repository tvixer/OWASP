using Ftsoft.Common.Result;

namespace Application.Features.Offer.Errors;

public class NotOfferRecipientError : Error
{
    public static NotOfferRecipientError Instance => new NotOfferRecipientError();
    public override string Type => "Offer.NotOfferRecipientError";
}