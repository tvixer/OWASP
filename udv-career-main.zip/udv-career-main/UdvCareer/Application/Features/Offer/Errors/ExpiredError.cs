using Ftsoft.Common.Result;

namespace Application.Features.Offer.Errors;

public class ExpiredError : Error
{
    public static ExpiredError Instance => new ExpiredError();
    public override string Type => "Offer.ExpiredError";
}