using Ftsoft.Common.Result;

namespace Application.Features.Offer.Errors;

public class NotStudentError : Error
{
    public static NotStudentError Instance => new NotStudentError();
    public override string Type => "Offer.NotStudentError";
}