using Ftsoft.Common.Result;

namespace Application.Features.Offer.Errors;

public class AlreadyAcceptedOrRejectedError : Error
{
    public static AlreadyAcceptedOrRejectedError Instance => new AlreadyAcceptedOrRejectedError();

    public override string Type => "Offer.AlreadyAcceptedOrRejectedError";
}