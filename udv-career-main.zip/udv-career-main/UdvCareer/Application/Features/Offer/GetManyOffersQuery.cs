using Application.Features.Offer.Errors;
using Application.Features.Offer.Models;
using Application.Providers;
using Application.Services;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Offer;

public class GetManyOffersQuery : Query<IReadOnlyList<OfferDto>>
{
    public long RecipientId { get; set; }
}

public sealed class GetManyOffersQueryHandler : QueryHandler<GetManyOffersQuery, IReadOnlyList<OfferDto>>
{
    private readonly IOfferRepository _offerRepository;
    private readonly IUserProvider _userProvider;
    private readonly IDateService _dateService;

    public GetManyOffersQueryHandler(IOfferRepository offerRepository, IUserProvider userProvider, IDateService dateService)
    {
        _offerRepository = offerRepository;
        _userProvider = userProvider;
        _dateService = dateService;
    }

    protected override async Task<IResult> CanHandle(GetManyOffersQuery request, CancellationToken cancellationToken)
    {
        if (_userProvider.User?.Role is UserRole.Student && _userProvider.User.Id != request.RecipientId)
        {
            return Error(NotOfferRecipientError.Instance);
        }

        return Successful();
    }

    public override async Task<Result<IReadOnlyList<OfferDto>>> Handle(GetManyOffersQuery request,
        CancellationToken cancellationToken)
    {
        var offers =
            await _offerRepository.ListAsync(x => x.OfferRecipientId == request.RecipientId, cancellationToken);
        var offersDto = offers.Select(x => new OfferDto()
        {
            Status = x.Status,
            Id = x.Id,
            DirectionTitle = x.DirectionTitle,
            EndedAt = _dateService.ToUnixTimestamp(x.EndedAtUtc)
        }).ToList();
        return Successful(offersDto);
    }
}