namespace Application.Features.Offer.Models;

public enum DecideOfferStatus
{
    Accepted,
    Declined
}