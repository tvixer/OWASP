using Domain.Enums;

namespace Application.Features.Offer.Models;

public class OfferDto
{
    public long Id { get; set; } 
    public string DirectionTitle { get; set; }
    public OfferStatus Status { get; set; }
    public long EndedAt { get; set; }
}