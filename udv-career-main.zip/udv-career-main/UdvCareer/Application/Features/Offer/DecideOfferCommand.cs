using Application.Features.Offer.Errors;
using Application.Features.Offer.Models;
using Application.Providers;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Offer;

public class DecideOfferCommand : Command
{
    public long Id { get; set; }
    public DecideOfferStatus Status { get; set; }
}

public sealed class DecideOfferCommandHandler : CommandHandler<DecideOfferCommand>
{
    private readonly IUserProvider _userProvider;
    private readonly IOfferRepository _offerRepository;
    private readonly IDateProvider _dateProvider;

    private Domain.Models.Offer? _offer;

    public DecideOfferCommandHandler(IUserProvider userProvider, IOfferRepository offerRepository, IDateProvider dateProvider)
    {
        _userProvider = userProvider;
        _offerRepository = offerRepository;
        _dateProvider = dateProvider;
    }

    protected override async Task<IResult> CanHandle(DecideOfferCommand request, CancellationToken cancellationToken)
    {
        if (_userProvider.User?.Role is not UserRole.Student)
        {
            return Error(NotStudentError.Instance);
        }

        var offer = await _offerRepository.SingleOrDefaultAsync(x =>
                x.Id == request.Id &&
                x.OfferRecipientId == _userProvider.User.Id,
            cancellationToken);

        if (offer is null)
        {
            return Error(NotFoundError.Instance);
        }

        if (offer.Status is not OfferStatus.Requested)
        {
            return Error(AlreadyAcceptedOrRejectedError.Instance);
        }

        if (_dateProvider.UtcNow() > offer.EndedAtUtc)
        {
            return Error(ExpiredError.Instance);
        }

        var acceptedOffer = await _offerRepository.FirstOrDefaultAsync(
            x => x.OfferRecipientId == _userProvider.User.Id && x.Status == OfferStatus.Accepted, cancellationToken);
        if (acceptedOffer is not null)
        {
            return Error(AlreadyAcceptedOrRejectedError.Instance);
        }

        _offer = offer;

        return Successful();
    }

    public override async Task<Result> Handle(DecideOfferCommand request, CancellationToken cancellationToken)
    {
        switch (request.Status)
        {
            case DecideOfferStatus.Accepted:
                _offer!.SetStatus(OfferStatus.Accepted);
                break;
            case DecideOfferStatus.Declined:
                _offer!.SetStatus(OfferStatus.Declined);
                break;
            default:
                throw new ArgumentOutOfRangeException();
        }

        await _offerRepository.UnitOfWork.SaveChangesAsync(cancellationToken);

        return Successful();
    }
}