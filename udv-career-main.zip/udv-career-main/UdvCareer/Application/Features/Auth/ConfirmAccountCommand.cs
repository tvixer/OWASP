using Application.Features.Auth.Errors;
using Application.Services.TokenServices;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;

namespace Application.Features.Auth;

public class ConfirmAccountCommand : Command
{
    public string Token { get; set; }
}

public class ConfirmAccountCommandHandler : CommandHandler<ConfirmAccountCommand>
{
    private readonly IRegisterTokenService _tokenService;
    private readonly UserRepository _userRepository;

    public ConfirmAccountCommandHandler(IRegisterTokenService tokenService, UserRepository userRepository)
    {
        _tokenService = tokenService;
        _userRepository = userRepository;
    }

    public override async Task<Result> Handle(ConfirmAccountCommand request, CancellationToken cancellationToken)
    {
        var token = _tokenService.Use(request.Token);
        if (token == null)
            return Error(EmailVerificationError.Instance);
        var user = await _userRepository.SingleOrDefaultAsync(x => x.Id == token.UserId, cancellationToken);
        if (user == null)
            return Error(EmailVerificationError.Instance);
        user.Confirm();
        await _userRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful();
    }
}