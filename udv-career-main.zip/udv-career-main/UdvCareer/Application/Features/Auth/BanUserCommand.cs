using Application.Features.User.Errors;
using Application.Providers;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Auth;

public class BanUserCommand : Command
{
    public long UserId { get; set; }
}

public sealed class BanUserCommandHandler : CommandHandler<BanUserCommand>
{
    private readonly IUserRepository _userRepository;
    private readonly IUserProvider _userProvider;

    public BanUserCommandHandler(IUserRepository userRepository, IUserProvider userProvider)
    {
        _userRepository = userRepository;
        _userProvider = userProvider;
    }

    public override async Task<Result> Handle(BanUserCommand request, CancellationToken cancellationToken)
    {
        if (request.UserId == _userProvider.User!.Id)
        {
            return Error(Errors.SuicideError.Instance);
        }

        var user =
            await _userRepository.SingleOrDefaultAsync(x => x.Id == request.UserId, cancellationToken);
        if (user == null)
            return Error(NotFoundError.Instance);
        user.Ban();
        await _userRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful();
    }
}