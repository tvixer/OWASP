namespace Application.Features.Auth.DTOs;

public class RegisterStudentDto
{
   
}