namespace Application.Features.Auth.DTOs;

public class RegisterHrDto
{
    
}