namespace Application.Features.Auth.DTOs;

public class LoginDto
{
    
}