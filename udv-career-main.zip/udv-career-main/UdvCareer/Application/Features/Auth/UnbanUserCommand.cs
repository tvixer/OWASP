using Application.Features.User.Errors;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace Application.Features.Auth;

public class UnbanUserCommand : Command
{
    public long UserId { get; set; }
}

public sealed class UnbanUserCommandHandler : CommandHandler<UnbanUserCommand>
{
    private readonly UserRepository _userRepository;

    public UnbanUserCommandHandler(UserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public override async Task<Result> Handle(UnbanUserCommand request, CancellationToken cancellationToken)
    {
        var user =
            await _userRepository.SingleOrDefaultAsync(x => x.Id == request.UserId, cancellationToken);
        if (user == null)
            return Error(NotFoundError.Instance);
        user.Unban();
        await _userRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful();
    }
}