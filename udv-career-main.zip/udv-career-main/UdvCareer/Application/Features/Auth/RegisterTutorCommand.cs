using Application.Features.Auth.Errors;
using Application.MailTemplates;
using Application.Services;
using Application.Services.Models;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MimeKit;

namespace Application.Features.Auth;

public class RegisterTutorCommand : Command
{
    [FromBody] public string Email { get; set; }
}

public sealed class RegisterTutorCommandHandler : CommandHandler<RegisterTutorCommand>
{
    private readonly IUserRepository _userRepository;
    private readonly ITutorUserRepository _tutorUserRepository;
    private readonly IEmailSenderService _emailSender;
    private readonly IPasswordGeneratorService _passwordGeneratorService;
    private readonly IRazorRenderService _razorRenderService;
    private readonly IConfiguration _configuration;

    public RegisterTutorCommandHandler(IUserRepository userRepository, ITutorUserRepository tutorUserRepository,
        IEmailSenderService emailSender, IPasswordGeneratorService passwordGeneratorService,
        IRazorRenderService razorRenderService, IConfiguration configuration)
    {
        _userRepository = userRepository;
        _tutorUserRepository = tutorUserRepository;
        _emailSender = emailSender;
        _passwordGeneratorService = passwordGeneratorService;
        _razorRenderService = razorRenderService;
        _configuration = configuration;
    }

    protected override async Task<IResult> CanHandle(RegisterTutorCommand request, CancellationToken cancellationToken)
    {
        var user = await _userRepository.SingleOrDefaultAsync(x => x.Email == request.Email, cancellationToken);
        if (user != null)
            return Error(AccountExistsError.Instance);
        return Successful();
    }

    public override async Task<Result> Handle(RegisterTutorCommand request, CancellationToken cancellationToken)
    {
        var password = _passwordGeneratorService.Generate();
        var hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);
        var user = new TutorUser(request.Email, hashedPassword, true, "", "", "", "", false);
        await _tutorUserRepository.AddAsync(user, cancellationToken);
        await _userRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        await SendEmail(request.Email, password);
        return Successful();
    }

    private async Task SendEmail(string email, string password)
    {
        var uri = _configuration.GetValue<string>("ClientUri");
        var template = await _razorRenderService.RenderAsString("LoginCredentialsPage",
            new LoginCredentialsViewModel()
            {
                Email = email, Password = password, EnterUrl = $"{uri}/auth", ResetUrl = $"{uri}/offer-restore-pass"
            });
        _emailSender.Send(new Message(new[]
            {
                email
            }, "Данные для входа на U Summer School", template, true
        ));
    }
}