using Application.Features.Auth.Errors;
using Application.Features.User.Errors;
using Application.Services;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.AspNetCore.Mvc;

namespace Application.Features.Auth;

public class LoginCommand : Command
{
    [FromBody] public string Email { get; set; }
    [FromBody] public string Password { get; set; }
}

public sealed class LoginCommandHandler : CommandHandler<LoginCommand>
{
    private readonly IUserRepository _userRepository;
    private readonly ICryptService _cryptService;
    private readonly IJwtService _jwtService;

    public LoginCommandHandler(IUserRepository userRepository, IJwtService jwtService,
        ICryptService cryptService)
    {
        _userRepository = userRepository;
        _jwtService = jwtService;
        _cryptService = cryptService;
    }

    public override async Task<Result> Handle(LoginCommand request, CancellationToken cancellationToken)
    {
        var user = await _userRepository.SingleOrDefaultAsync(x => x.Email == request.Email, cancellationToken);
        if (user == null || user.IsBanned)
            return Error(NotFoundError.Instance);
        if (!user.IsConfirmed)
            return Error(NotConfirmedError.Instance);
        var isCorrectPassword = _cryptService.Verify(request.Password, user.Password);
        if (!isCorrectPassword)
            return Error(InvalidCredentialsError.Instance);
        var jwtToken = _jwtService.CreateToken(user.Id.ToString(), request.Email, user.Role.ToString());
        return Successful(jwtToken);
    }
}