using Application.Features.User.DTOs;
using Application.Providers;
using Domain.Models;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Auth;

public class GetAuthorizedUserQuery : Query<UserDto>
{
}

public sealed class GetAuthorizedUserQueryHandler : QueryHandler<GetAuthorizedUserQuery, UserDto>
{
    private readonly IUserProvider _userProvider;

    public GetAuthorizedUserQueryHandler(IUserProvider userProvider)
    {
        _userProvider = userProvider;
    }

    public override async Task<Result<UserDto>> Handle(GetAuthorizedUserQuery request,
        CancellationToken cancellationToken)
    {
        var user = _userProvider.User;
        var userDto = new UserDto(user!.Email, user.Name, user.Surname, user.Patronymic, user.Phone,
            user.IsConfirmed, user.Role.ToString(), user.TelegramUsername ?? "");

        if (user is StudentUser studentUser)
        {
            await AddStudentInfo(studentUser, userDto, cancellationToken);
        }

        return Successful(userDto);
    }

    private async Task AddStudentInfo(StudentUser studentUser, UserDto userDto, CancellationToken cancellationToken)
    {
        var studentAdditionalInfo = new StudentAdditionalInfo(studentUser.Institute, studentUser.Specialization,
            studentUser.Course, studentUser.DirectionType.ToString());
        userDto.StudentInfo = studentAdditionalInfo;
    }
}