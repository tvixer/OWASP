using Ftsoft.Common.Result;

namespace Application.Features.Auth.Errors;

public class NotConfirmedError : Error
{
    public static NotConfirmedError Instance => new NotConfirmedError();
    
    public override string Type => "Auth.NotConfirmedError";
}