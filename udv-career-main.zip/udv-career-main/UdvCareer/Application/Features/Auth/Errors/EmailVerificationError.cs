using Ftsoft.Common.Result;

namespace Application.Features.Auth.Errors;

public class EmailVerificationError : Error
{
    public static EmailVerificationError Instance => new EmailVerificationError();
    public override string Type => "Auth.EmailVerificationError";
}