using Ftsoft.Common.Result;

namespace Application.Features.Auth.Errors;

public class InvalidCredentialsError : Error
{
    public static InvalidCredentialsError Instance => new InvalidCredentialsError();
    public override string Type => "Auth.InvalidCredentialsError";
}