using Ftsoft.Common.Result;

namespace Application.Features.Auth.Errors;

public class AccountExistsError : Error
{
    public static AccountExistsError Instance = new AccountExistsError();

    public override string Type => "Auth.AccountExistsError";
}