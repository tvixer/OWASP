using Ftsoft.Common.Result;

namespace Application.Features.Auth.Errors;

public class SuicideError : Error
{
    public static SuicideError Instance => new SuicideError(); 
    public override string Type => "Auth.SuicideError";
}