using Application.Features.Auth.Errors;
using Application.MailTemplates;
using Application.Services;
using Application.Services.Models;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Application.Features.Auth;

public class RegisterHrCommand : Command
{
    public string Email { get; set; }
}

public sealed class RegisterHrCommandHandler : CommandHandler<RegisterHrCommand>
{
    private readonly IUserRepository _userRepository;
    private readonly IEmailSenderService _emailSender;
    private readonly IConfiguration _configuration;
    private readonly IRazorRenderService _razorRenderService;
    private readonly IPasswordGeneratorService _passwordGeneratorService;
    private HrUser? _user;

    public RegisterHrCommandHandler(
        IUserRepository userRepository,
        IEmailSenderService emailSender,
        IConfiguration configuration,
        IPasswordGeneratorService passwordGeneratorService,
        IRazorRenderService razorRenderService
    )
    {
        _userRepository = userRepository;
        _emailSender = emailSender;
        _configuration = configuration;
        _razorRenderService = razorRenderService;
        _passwordGeneratorService = passwordGeneratorService;
    }

    protected override async Task<IResult> CanHandle(RegisterHrCommand request, CancellationToken cancellationToken)
    {
        var user = await _userRepository.SingleOrDefaultAsync(x => x.Email == request.Email, cancellationToken);
        return user != null ? Error(AccountExistsError.Instance) : Successful();
    }

    public override async Task<Result> Handle(RegisterHrCommand request, CancellationToken cancellationToken)
    {
        var password = _passwordGeneratorService.Generate();
        var hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);
        _user = new HrUser(request.Email, hashedPassword, true, "", "", "", "", false);
        await _userRepository.AddAsync(_user, cancellationToken);
        await _userRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        await SendEmail(request.Email, password);
        return Successful();
    }

    private async Task SendEmail(string email, string password)
    {
        var uri = _configuration.GetValue<string>("ClientUri");
        var template = await _razorRenderService.RenderAsString("LoginCredentialsPage",
            new LoginCredentialsViewModel()
            {
                Email = email, Password = password, EnterUrl = $"{uri}/auth", ResetUrl = $"{uri}/offer-restore-pass"
            });
        _emailSender.Send(new Message(new[]
            {
                email
            }, "Данные для входа на U Summer School", template, true
        ));
    }
}