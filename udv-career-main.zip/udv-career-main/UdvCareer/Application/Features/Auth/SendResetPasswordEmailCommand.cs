using Application.Services;
using Application.Services.Models;
using Application.Services.TokenServices;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.AspNetCore.Http;

namespace Application.Features.Auth;

public class SendResetPasswordEmailCommand : Command
{
    public string Email { get; set; }
    public string ResetPagePath { get; set; }
}

public sealed class SendResetPasswordEmailCommandHandler : CommandHandler<SendResetPasswordEmailCommand>
{
    private readonly IResetTokenService _tokenService;
    private readonly IEmailSenderService _emailSenderService;
    private readonly IUserRepository _userRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;


    public SendResetPasswordEmailCommandHandler(IResetTokenService tokenService, IUserRepository userRepository,
        IEmailSenderService emailSenderService, IHttpContextAccessor httpContextAccessor)
    {
        _tokenService = tokenService;
        _userRepository = userRepository;
        _emailSenderService = emailSenderService;
        _httpContextAccessor = httpContextAccessor;
    }

    public override async Task<Result> Handle(SendResetPasswordEmailCommand request,
        CancellationToken cancellationToken)
    {
        var user = await _userRepository.SingleOrDefaultAsync(x => x.Email == request.Email, cancellationToken);
        if (user is null)
        {
            return Successful();
        }

        var httpRequest = _httpContextAccessor.HttpContext!.Request;
        var origin = httpRequest.Headers.Origin.FirstOrDefault();
        var token = _tokenService.Generate(user.Id);
        var url = origin + $"/{request.ResetPagePath}?token={token}";
//         var content = @$"Здравствуйте, {user.GetFullname()}.
//
// Было запрошено восстановление пароля для вашего аккаунта U Summer School
// Чтобы установить новый пароль, перейдите по этой ссылке - {url}
// ";
//         await _emailSenderService.SendAsync(new Message(new[] { request.Email }, "Сброс пароля от U Summer School", content));
        return Successful();
    }
}