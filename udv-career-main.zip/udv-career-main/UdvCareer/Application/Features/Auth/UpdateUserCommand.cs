using Application.Features.User.Errors;
using Application.Providers;
using Application.Services;
using Domain.Enums;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using static System.Enum;

namespace Application.Features.Auth;

public class UpdateUserCommand : Command
{
    public string Name { get; set; }
    public string Surname { get; set; }
    public string Patronymic { get; set; }
    public string Phone { get; set; }
    public string TelegramUsername { get; set; }
    public UpdateStudentInfo? StudentInfo { get; set; }
    public UpdateTutorInfo? TutorInfo { get; set; }
    public UpdateHrInfo? HrInfo { get; set; }

    public class UpdateStudentInfo
    {
        public string Institute { get; set; }
        public string Specialization { get; set; }
        public int Course { get; set; }
        public string DirectionType { get; set; }
    }

    public class UpdateTutorInfo
    {
    }

    public class UpdateHrInfo
    {
    }
}

public class UpdateUserCommandHandler : CommandHandler<UpdateUserCommand>
{
    private readonly IUserProvider _userProvider;
    private readonly IUserRepository _userRepository;
    private readonly IJwtService _jwtService;

    public UpdateUserCommandHandler(IUserRepository userRepository,
        IUserProvider userProvider, IJwtService jwtService)
    {
        _userRepository = userRepository;
        _userProvider = userProvider;
        _jwtService = jwtService;
    }

    public override async Task<Result> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
    {
        var user = _userProvider.User;
        if (user == null)
        {
            return Error(NotFoundError.Instance);
        }

        user.UpdateAccountInfo(request.Name, request.Surname, request.Patronymic, request.Phone,
            request.TelegramUsername);

        if (user is StudentUser studentUser)
        {
            UpdateStudentInfo(request.StudentInfo!, studentUser);
        }

        if (user is HrUser hrUser)
        {
            UpdateHrInfo(request.HrInfo!, hrUser);
        }

        if (user is TutorUser tutorUser)
        {
            UpdateTutorInfo(request.TutorInfo!, tutorUser);
        }

        await _userRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        var token = _jwtService.CreateToken(user.Id.ToString(), user.Email, user.Role.ToString());
        return Successful(token);
    }

    private static void UpdateStudentInfo(UpdateUserCommand.UpdateStudentInfo studentInfo, StudentUser studentUser)
    {
        // Временно выключили стажировку
        var directionType = DirectionType.Practice;
        // TryParse<DirectionType>(studentInfo!.DirectionType, out var directionType);
        studentUser.UpdateStudentInfo(studentInfo.Course,
            studentInfo.Institute,
            studentInfo.Specialization, directionType);
    }

    private static void UpdateHrInfo(UpdateUserCommand.UpdateHrInfo hrInfo, HrUser hrUser)
    {
    }

    private static void UpdateTutorInfo(UpdateUserCommand.UpdateTutorInfo tutorInfo, TutorUser tutorUser)
    {
    }
}