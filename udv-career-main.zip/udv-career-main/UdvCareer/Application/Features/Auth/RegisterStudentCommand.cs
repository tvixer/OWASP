using System.Web;
using Application.Features.Auth.Errors;
using Application.MailTemplates;
using Application.Services;
using Application.Services.Models;
using Application.Services.TokenServices;
using Domain.Enums;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Microsoft.Extensions.Configuration;
using IResult = Ftsoft.Common.Result.IResult;

namespace Application.Features.Auth;

public class RegisterStudentCommand : Command
{
    public string Email { get; set; }
    public string Password { get; set; }
}

public sealed class RegisterStudentCommandHandler : CommandHandler<RegisterStudentCommand>
{
    private readonly IUserRepository _userRepository;
    private readonly IStudentUserRepository _studentUserRepository;
    private readonly IRegisterTokenService _registerTokenService;
    private readonly IEmailSenderService _emailSenderService;
    private readonly ICryptService _cryptService;
    private readonly IConfiguration _configuration;
    private readonly IRazorRenderService _razorRenderService;

    public RegisterStudentCommandHandler(
        IUserRepository userRepository,
        IRegisterTokenService registerTokenService,
        IEmailSenderService emailSenderService,
        IStudentUserRepository studentUserRepository,
        ICryptService cryptService, IConfiguration configuration, IRazorRenderService razorRenderService)
    {
        _userRepository = userRepository;
        _registerTokenService = registerTokenService;
        _emailSenderService = emailSenderService;
        _studentUserRepository = studentUserRepository;
        _cryptService = cryptService;
        _configuration = configuration;
        _razorRenderService = razorRenderService;
    }

    protected override async Task<IResult> CanHandle(RegisterStudentCommand request,
        CancellationToken cancellationToken)
    {
        var existingUser =
            await _userRepository.SingleOrDefaultAsync(x => x.Email == request.Email, cancellationToken);
        return existingUser is not null ? Error(AccountExistsError.Instance) : Successful();
    }

    public override async Task<Result> Handle(RegisterStudentCommand request, CancellationToken cancellationToken)
    {
        var hashedPassword = _cryptService.Hash(request.Password);
        var user = new StudentUser(request.Email, hashedPassword, false, "", "", "", "", false, "", "", 1,
            DirectionType.Practice);
        await _studentUserRepository.AddAsync(user, cancellationToken);
        await _studentUserRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        await SendConfirmationMail(user);
        return Successful();
    }

    private async Task SendConfirmationMail(BaseUser user)
    {
        var token = _registerTokenService.Generate(user.Id);
        var uri = _configuration.GetValue<string>("ClientUri");
        var url = uri + "/api/account/verify?token=" + token + "&redirectTo=" + HttpUtility.UrlEncode(uri);
       
        var template = await _razorRenderService.RenderAsString("RegisterConfirmingPage",
            new RegisterConfirmingViewModel()
            {
                ConfirmLink = url
            });
        await _emailSenderService.SendAsync(new Message(new[]
            {
                user.Email,
            }, "Регистрация на U Summer School", template, true
        ));
    }
}