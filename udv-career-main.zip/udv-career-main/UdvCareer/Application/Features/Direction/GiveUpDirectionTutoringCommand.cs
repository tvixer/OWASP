using Application.Providers;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using NotFoundError = Application.Features.Direction.Errors.NotFoundError;

namespace Application.Features.Direction;

public class GiveUpDirectionTutoringCommand : Command
{
    public long Id { get; set; }
}

public sealed class GiveUpDirectionTutoringCommandHandler : CommandHandler<GiveUpDirectionTutoringCommand>
{
    private readonly IDirectionRepository _directionRepository;
    private readonly IUserProvider _userProvider;
    private readonly IDirectionTutorRepository _directionTutorRepository;

    private long _tutorId;
    private long _directionId;

    public GiveUpDirectionTutoringCommandHandler(
        IDirectionRepository directionRepository,
        IDirectionTutorRepository directionTutorRepository,
        IUserProvider userProvider)
    {
        _directionRepository = directionRepository;
        _directionTutorRepository = directionTutorRepository;
        _userProvider = userProvider;
    }

    protected override async Task<IResult> CanHandle(GiveUpDirectionTutoringCommand request,
        CancellationToken cancellationToken)
    {
        var direction =
            await _directionRepository.SingleOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
        if (direction == null)
            return Error(NotFoundError.Instance);
        _directionId = direction.Id;
        var user = _userProvider.User;
        if (user == null)
        {
            return Error(Tutor.Errors.NotFoundError.Instance);
        }

        _tutorId = user.Id;
        return Successful();
    }

    public override async Task<Result> Handle(GiveUpDirectionTutoringCommand request,
        CancellationToken cancellationToken)
    {
        var directionTutor =
            await _directionTutorRepository.SingleOrDefaultAsync(
                x => x.TutorId == _tutorId && x.DirectionId == _directionId,
                cancellationToken);
        if (directionTutor == null)
        {
            return Error(NotFoundError.Instance);
        }

        await _directionTutorRepository.RemoveAsync(directionTutor);
        await _directionTutorRepository.UnitOfWork.SaveChangesAsync(cancellationToken);

        return Successful();
    }
}