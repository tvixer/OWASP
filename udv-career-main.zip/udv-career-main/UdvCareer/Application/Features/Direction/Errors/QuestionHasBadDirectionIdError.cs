using Ftsoft.Common.Result;

namespace Application.Features.Direction.Errors;

public class QuestionHasBadDirectionIdError : Error
{
    public static QuestionHasBadDirectionIdError Instance => new QuestionHasBadDirectionIdError();
    
    public override string Type => "Direction.QuestionHasBadDirectionIdError";
}