using Ftsoft.Common.Result;

namespace Application.Features.Direction.Errors;

public class NotFoundError : Error
{
    public static NotFoundError Instance => new NotFoundError();
    
    public override string Type => "Direction.NotFoundError";
    
}