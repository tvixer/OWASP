using Ftsoft.Common.Result;

namespace Application.Features.Direction.Errors;

public class NotEnrolledToDirectionError : Error
{
    public static NotEnrolledToDirectionError Instance => new NotEnrolledToDirectionError();
    
    public override string Type => "Direction.NotEnrolledToDirectionError";
}