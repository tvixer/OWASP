using Ftsoft.Common.Result;

namespace Application.Features.Direction.Errors;

public class NoTutorsError : Error
{
    public static NoTutorsError Instance => new NoTutorsError();

    public override string Type => "Direction.NoTutorsError";
}