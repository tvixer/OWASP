using Ftsoft.Common.Result;

namespace Application.Features.Direction.Errors;

public class AlreadyEnrolledError : Error
{

    public static AlreadyEnrolledError Instance => new AlreadyEnrolledError();

    public override string Type => "Direction.AlreadyEnrolledError";
}