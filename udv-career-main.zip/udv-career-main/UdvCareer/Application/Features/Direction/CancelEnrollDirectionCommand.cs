using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using IResult = Ftsoft.Common.Result.IResult;

namespace Application.Features.Direction;

public class CancelEnrollDirectionCommand : Command
{
    [FromRoute] public long Id { get; set; }
}

public sealed class CancelEnrollDirectionCommandHandler : CommandHandler<CancelEnrollDirectionCommand>
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly UserRepository _userRepository;
    private readonly StudentUserRepository _studentUserRepository;
    private readonly DirectionRepository _directionRepository;

    public CancelEnrollDirectionCommandHandler(IHttpContextAccessor httpContextAccessor, UserRepository userRepository,
        StudentUserRepository studentUserRepository,
        DirectionRepository directionRepository)
    {
        _httpContextAccessor = httpContextAccessor;
        _userRepository = userRepository;
        _studentUserRepository = studentUserRepository;
        _directionRepository = directionRepository;
    }

    protected override async Task<IResult> CanHandle(CancelEnrollDirectionCommand request,
        CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
        //
        // var contextUser = _httpContextAccessor.HttpContext?.User;
        // var user = await _userRepository.SingleOrDefaultAsync(x =>
        //     x.Email == contextUser.FindFirstValue(ClaimTypes.Email), cancellationToken);
        // if (user == null)
        //     return Error(UserNotFoundError.Instance);
        // var studentProfile =
        //     await _studentUserRepository
        //         .SingleOrDefaultAsync(x => x.UserId == user.Id, cancellationToken);
        // if (studentProfile == null)
        //     return Error(NotFoundError.Instance);
        // var direction =
        //     await _directionRepository.SingleOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
        // if (direction == null)
        //     return Error(NotFoundError.Instance);
        // return Successful();
    }

    public override async Task<Result> Handle(CancelEnrollDirectionCommand request, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
        // var enroll = _student.Enrolls.SingleOrDefault(x => x.DirectionId == request.Id);
        // if (enroll == null)
        //     return Error(NotEnrolledError.Instance);
        // _student.Enrolls.Remove(enroll);
        // await _studentUserRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        // return Successful();
    }
}