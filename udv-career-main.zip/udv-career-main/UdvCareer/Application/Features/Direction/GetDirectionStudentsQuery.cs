using Application.Features.Direction.Errors;
using Application.Features.Models;
using Application.Features.Student.Converters;
using Application.Features.Student.DTOs;
using Application.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Direction;

public class GetDirectionStudentsQuery : Query<PaginatedListDto<StudentDto>>
{
    public long Id { get; set; }
    public PaginateParams PaginateParams { get; set; }
}

public sealed class
    GetDirectionStudentsQueryHandler : QueryHandler<GetDirectionStudentsQuery, PaginatedListDto<StudentDto>>
{
    private readonly IEnrollRepository _enrollRepository;
    private readonly IStudentUserRepository _studentUserRepository;
    private readonly IDirectionRepository _directionRepository;


    public GetDirectionStudentsQueryHandler(
        IEnrollRepository enrollRepository,
        IStudentUserRepository studentUserRepository,
        IDirectionRepository directionRepository)
    {
        _enrollRepository = enrollRepository;
        _studentUserRepository = studentUserRepository;
        _directionRepository = directionRepository;
    }

    public override async Task<Result<PaginatedListDto<StudentDto>>> Handle(GetDirectionStudentsQuery request,
        CancellationToken cancellationToken)
    {
        var direction = await _directionRepository.SingleOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
        if (direction is null)
        {
            return Error(NotFoundError.Instance);
        }

        var page = request.PaginateParams.Page <= 0 ? 1 : request.PaginateParams.Page;
        var skip = +(page - 1) * request.PaginateParams.Limit;
        var limit = request.PaginateParams.Limit == 0 ? 16 : request.PaginateParams.Limit;

        var enrolls =
            await _enrollRepository.Query(
                query => query.Where(x => x.DirectionId == request.Id).Skip(skip).Take(limit),
                cancellationToken);
        var total =
            await _enrollRepository.CountAsync(x => x.DirectionId == request.Id,
                cancellationToken);
        var studentIds = enrolls.Select(x => x.StudentId);
        var students = await _studentUserRepository.ListAsync(x => studentIds.Contains(x.Id), cancellationToken);
        var items = StudentConverter.Convert(students);
        var paginatedStudents = new PaginatedListDto<StudentDto>(items, total);
        return Successful(paginatedStudents);
    }
}