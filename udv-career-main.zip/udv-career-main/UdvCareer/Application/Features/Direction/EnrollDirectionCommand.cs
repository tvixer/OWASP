using Application.Features.Direction.Errors;
using Application.Providers;
using Domain.Enums;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using NotFoundError = Application.Features.Direction.Errors.NotFoundError;

namespace Application.Features.Direction;

public class EnrollDirectionCommand : Command
{
    public long Id { get; set; }
}

public class EnrollDirectionCommandHandler : CommandHandler<EnrollDirectionCommand>
{
    private readonly DirectionTutorRepository _directionTutorRepository;
    private readonly IUserRepository _tutorUserRepository;
    private readonly StudentUserRepository _studentUserRepository;
    private readonly EnrollRepository _enrollRepository;
    private readonly IUserProvider _userProvider;
    private readonly IDirectionRepository _directionRepository;

    private StudentUser _student;
    private Domain.Models.Direction _direction;

    public EnrollDirectionCommandHandler(
        IDirectionRepository directionRepository, StudentUserRepository studentUserRepository,
        EnrollRepository enrollRepository, DirectionTutorRepository directionTutorRepository,
        IUserRepository tutorUserRepository,
        IUserProvider userProvider)
    {
        _directionRepository = directionRepository;
        _studentUserRepository = studentUserRepository;
        _enrollRepository = enrollRepository;
        _directionTutorRepository = directionTutorRepository;
        _tutorUserRepository = tutorUserRepository;
        _userProvider = userProvider;
    }

    protected override async Task<IResult> CanHandle(EnrollDirectionCommand request,
        CancellationToken cancellationToken)
    {
        var studentProfile =
            await _studentUserRepository
                .SingleOrDefaultAsync(x => x.Id == _userProvider.User!.Id, cancellationToken);
        if (studentProfile == null)
            return Error(Student.Errors.NotFoundError.Instance);
        var direction =
            await _directionRepository.SingleOrDefaultAsync(x => (x.Id == request.Id) && x.IsActive,
                cancellationToken);
        if (direction == null)
            return Error(NotFoundError.Instance);
        _student = studentProfile;
        _direction = direction;

        return Successful();
    }

    public override async Task<Result> Handle(EnrollDirectionCommand request, CancellationToken cancellationToken)
    {
        var enrolls = await
            _enrollRepository.ListAsync(x => x.DirectionId == request.Id, cancellationToken);

        var studentEnroll = enrolls.FirstOrDefault(x => x.StudentId == _userProvider.User!.Id);
        if (studentEnroll != null) return Error(AlreadyEnrolledError.Instance);

        var directionTutors = await _directionTutorRepository.ListAsync(
            x => x.DirectionId == request.Id, cancellationToken);
        var bannedTutors = await _tutorUserRepository.ListAsync(x => x.IsBanned, cancellationToken);
        var bannedTutorsIds = bannedTutors.Select(x => x.Id);
        directionTutors = directionTutors.Where(x => !bannedTutorsIds.Contains(x.Id)).ToList();
        if (directionTutors.Count <= 0) return Error(NoTutorsError.Instance);
        var directionTutor = directionTutors.MinBy(x => enrolls.Count(e => e.TutorId == x.TutorId));
        var tutor = await _tutorUserRepository.SingleOrDefaultAsync(x => x.Id == directionTutor!.TutorId && x.Role == UserRole.Tutor,
            cancellationToken);
        if (tutor is null)
        {
            return Error(Tutor.Errors.NotFoundError.Instance);
        }

        await CreateAndSaveEnroll(tutor, cancellationToken);
        return Successful();
    }

    private async Task CreateAndSaveEnroll(BaseUser? tutor, CancellationToken cancellationToken)
    {
        var enroll = new Enroll(_student.Id, tutor!.Id, _direction.Id);
        await _enrollRepository.AddAsync(enroll, cancellationToken);
        await _enrollRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
    }
}