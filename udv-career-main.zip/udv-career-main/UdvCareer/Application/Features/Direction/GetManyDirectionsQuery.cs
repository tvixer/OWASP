using Application.Features.Direction.DTOs;
using Application.Features.Direction.DTOs.Responses;
using Application.Models;
using Application.Providers;
using Application.Services;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Direction;

public class GetManyDirectionsQuery : Query<PaginatedListDto<GetManyDirectionsResponseDto>>
{
    public GetManyDirectionsDto GetManyDirectionsDto { get; set; }
}

public sealed class
    GetManyDirectionsQueryHandler : QueryHandler<GetManyDirectionsQuery, PaginatedListDto<GetManyDirectionsResponseDto>>
{
    private const int DefaultLimit = 16;

    private readonly IDirectionRepository _directionRepository;
    private readonly IEnrollRepository _enrollRepository;
    private readonly IDateService _dateService;
    private readonly IUserProvider _userProvider;

    public GetManyDirectionsQueryHandler(IDirectionRepository directionRepository,
        IUserProvider userProvider, IDateService dateService, IEnrollRepository enrollRepository)
    {
        _directionRepository = directionRepository;
        _userProvider = userProvider;
        _dateService = dateService;
        _enrollRepository = enrollRepository;
    }

    public override async Task<Result<PaginatedListDto<GetManyDirectionsResponseDto>>> Handle(
        GetManyDirectionsQuery request,
        CancellationToken cancellationToken)
    {
        var skip = request.GetManyDirectionsDto.Page == 0
            ? 0
            : +(request.GetManyDirectionsDto.Page - 1) * request.GetManyDirectionsDto.Limit;
        var limit = request.GetManyDirectionsDto.Limit == 0 ? DefaultLimit : request.GetManyDirectionsDto.Limit;
        var directions = await _directionRepository.Query(queryable =>
        {
            if (request.GetManyDirectionsDto.Department is not null)
            {
                queryable = queryable.Where(x => x.Department == request.GetManyDirectionsDto.Department);
            }

            if (_userProvider.User?.Role is not UserRole.Hr)
            {
                queryable = queryable.Where(x => x.IsActive);
            }

            queryable = queryable.Skip(skip).Take(limit);
            return queryable;
        }, cancellationToken);


        var studentEnrollsIds = new List<long>();
        if (_userProvider.User?.Role == UserRole.Student)
        {
            var enrolls = await
                _enrollRepository.ListAsync(x => x.StudentId == _userProvider.User.Id, cancellationToken);
            studentEnrollsIds = enrolls.Select(x => x.Id).ToList();
        }

        var items = directions.Select(x => Convert(x, studentEnrollsIds.Contains(x.Id))).ToList();
        var total = 0;
        if (_userProvider.User?.Role is UserRole.Hr)
        {
            total = await _directionRepository.CountAsync(cancellationToken);
        }
        else
        {
            total = await _directionRepository.CountAsync(x => x.IsActive, cancellationToken);
        }

        var paginatedList = new PaginatedListDto<GetManyDirectionsResponseDto>(items, total);
        return Successful(paginatedList);
    }

    private GetManyDirectionsResponseDto Convert(Domain.Models.Direction direction, bool enrolled)
    {
        var dto = new GetManyDirectionsResponseDto(
            direction.Id,
            direction.Title,
            direction.Description,
            enrolled,
            direction.WillBeAcceptedCount,
            _dateService.ToUnixTimestamp(direction.EndedAtUtc),
            direction.IsActive,
            direction.Department.ToString());
        return dto;
    }
}