using Application.Features.Direction.Errors;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace Application.Features.Direction;

public class DeleteDirectionCommand : Command
{
    [FromRoute] public long Id { get; set; }
}

public class DeleteDirectionCommandHandler : CommandHandler<DeleteDirectionCommand>
{
    private readonly DirectionRepository _directionRepository;
    private readonly IQuestionRepository _questionRepository;

    public DeleteDirectionCommandHandler(
        DirectionRepository directionRepository, IQuestionRepository questionRepository)
    {
        _directionRepository = directionRepository;
        _questionRepository = questionRepository;
    }

    public override async Task<Result> Handle(DeleteDirectionCommand request, CancellationToken cancellationToken)
    {
        var direction =
            await _directionRepository.SingleOrDefaultAsync(x => x.Id == request.Id,
                cancellationToken: cancellationToken);
        if (direction == null)
            return Error(NotFoundError.Instance);
        var questions = await _questionRepository.ListAsync(x => x.DirectionId == direction.Id, cancellationToken);
        await _questionRepository.RemoveRangeAsync(questions);
        await _directionRepository.RemoveAsync(direction);
        await _directionRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful();
    }
}