using Application.Features.Direction.DTOs.Responses;
using Application.Features.Direction.Errors;
using Application.Providers;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Direction;

public class GetDirectionQuestionsQuery : Query<GetDirectionQuestionsResponseDto>
{
    public long Id { get; set; }
}

public sealed class
    GetDirectionQuestionsQueryHandler : QueryHandler<GetDirectionQuestionsQuery, GetDirectionQuestionsResponseDto>
{
    private readonly IQuestionRepository _questionRepository;
    private readonly IEnrollRepository _enrollRepository;
    private readonly IDirectionRepository _directionRepository;
    private readonly IUserProvider _userProvider;

    public GetDirectionQuestionsQueryHandler(IQuestionRepository questionRepository, IUserProvider userProvider,
        IEnrollRepository enrollRepository, IDirectionRepository directionRepository)
    {
        _questionRepository = questionRepository;
        _userProvider = userProvider;
        _enrollRepository = enrollRepository;
        _directionRepository = directionRepository;
    }

    public override async Task<Result<GetDirectionQuestionsResponseDto>> Handle(GetDirectionQuestionsQuery request,
        CancellationToken cancellationToken)
    {
        if (_userProvider.User is null)
        {
            return Error(NotEnrolledToDirectionError.Instance);
        }

        if (_userProvider.User.Role == UserRole.Student)
        {
            var enroll = await _enrollRepository.SingleOrDefaultAsync(
                x => x.DirectionId == request.Id && x.StudentId == _userProvider.User.Id, cancellationToken);
            if (enroll is null)
            {
                return Error(NotEnrolledToDirectionError.Instance);
            }
        }

        var questions = await _questionRepository.Query(
            queryable => queryable.Where(x => x.DirectionId == request.Id).OrderBy(x => x.Id), cancellationToken);
        var responseDto = new GetDirectionQuestionsResponseDto();
        responseDto.Questions = questions
            .Select(x => new GetDirectionQuestionsResponseDto.GetDirectionQuestionsQuestionDto()
            {
                Id = x.Id,
                Text = x.Text
            }).ToList();
        var direction = await _directionRepository.SingleOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
        responseDto.TaskDescription = direction.TaskDescription;
        return Successful(responseDto);
    }
}