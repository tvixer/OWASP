﻿namespace Application.Features.Direction.DTOs;

public class DirectionDto
{
    public int AvailablePlaces { get; set; }
    public string Title { get; set; }
    public bool IsActive { get; set; }
    public long Id { get; set; }
    public string Description { get; set; }
    public long FinishAcceptingAt { get; set; }
    public string Department { get; set; }
}