using Domain.Enums;

namespace Application.Features.Direction.DTOs;

public class UpdateDirectionDto
{
    public string Title { get; set; }
    public string Description { get; set; }
    public string TaskDescription { get; set; }
    public bool IsActive { get; set; }
    public int WillBeAcceptedCount { get; set; }
    public long FinishingAcceptingAt { get; set; }
    public DirectionDepartment Department { get; set; }
    public List<UpdateDirectionQuestionsQuestionDto> Questions { get; set; }
    
    public class UpdateDirectionQuestionsQuestionDto
    {
        public string Text { get; set; }
    }
}