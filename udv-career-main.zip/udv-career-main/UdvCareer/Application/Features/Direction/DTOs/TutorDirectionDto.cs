namespace Application.Features.Direction.DTOs;

public class TutorDirectionDto
{
    public long Id { get; set; }
    public string Title { get; set; }
    public string? Description { get; set; }
    public long FinishAcceptingAt { get; set; }
}