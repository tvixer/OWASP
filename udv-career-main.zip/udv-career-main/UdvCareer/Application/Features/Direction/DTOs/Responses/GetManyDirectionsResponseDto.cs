namespace Application.Features.Direction.DTOs.Responses;

public class GetManyDirectionsResponseDto : DirectionDto
{
    public GetManyDirectionsResponseDto(long id, string title, string description, bool studentIsEnrolled,
        int availablePlaces, long finishAcceptingAt, bool isActive, string department)
    {
        Id = id;
        Title = title;
        Description = description;
        StudentIsEnrolled = studentIsEnrolled;
        AvailablePlaces = availablePlaces;
        FinishAcceptingAt = finishAcceptingAt;
        IsActive = isActive;
        Department = department;
    }
    
    public bool StudentIsEnrolled { get; set; }

}