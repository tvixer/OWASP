namespace Application.Features.Direction.DTOs.Responses;

public class GetDirectionResponseDto : DirectionDto
{
    public GetDirectionResponseDto(long id, string title, string description, bool studentIsEnrolled,
        int availablePlaces, long finishAcceptingAt, bool isActive, string department)
    {
        Id = id;
        Title = title;
        Description = description;
        StudentIsEnrolled = studentIsEnrolled;
        AvailablePlaces = availablePlaces;
        FinishAcceptingAt = finishAcceptingAt;
        IsActive = isActive;
        Department = department;
    }

    public bool StudentIsEnrolled { get; set; }
    public long? SolutionId { get; set; }
    public string Status { get; set; }
}