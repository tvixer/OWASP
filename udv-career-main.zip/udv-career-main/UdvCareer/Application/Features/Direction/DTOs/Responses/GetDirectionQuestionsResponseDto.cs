namespace Application.Features.Direction.DTOs.Responses;

public class GetDirectionQuestionsResponseDto
{
    public List<GetDirectionQuestionsQuestionDto> Questions { get; set; }
    public string TaskDescription { get; set; }
    public class GetDirectionQuestionsQuestionDto
    {
        public long Id { get; set; }
        public string Text { get; set; }
    }
}