using Domain.Enums;

namespace Application.Features.Direction.DTOs;

public class CreateDirectionDto
{
    public string Title { get; set; }
    public string Description { get; set; }
    public string TaskDescription { get; set; }
    public int WillBeAcceptedCount { get; set; }
    public bool IsActive { get; set; }
    public long EndedAt { get; set; }
    public List<string> Questions { get; set; }
    public DirectionDepartment Department { get; set; }
}