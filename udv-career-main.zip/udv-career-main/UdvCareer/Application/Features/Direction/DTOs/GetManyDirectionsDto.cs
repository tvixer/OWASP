using Application.Features.Models;
using Domain.Enums;

namespace Application.Features.Direction.DTOs;

public class GetManyDirectionsDto : PaginateParams
{
    public DirectionDepartment? Department { get; set; }
}