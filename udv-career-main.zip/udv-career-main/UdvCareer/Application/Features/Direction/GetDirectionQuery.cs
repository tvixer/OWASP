using Application.Features.Direction.DTOs.Responses;
using Application.Features.Direction.Errors;
using Application.Providers;
using Application.Services;
using Domain.Enums;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;

namespace Application.Features.Direction;

public class GetDirectionQuery : Query<GetDirectionResponseDto>
{
    public long Id { get; set; }
}

public sealed class GetDirectionQueryHandler : QueryHandler<GetDirectionQuery, GetDirectionResponseDto>
{
    private readonly IDirectionRepository _directionRepository;
    private readonly IEnrollRepository _enrollRepository;
    private readonly IUserProvider _userProvider;
    private readonly ISolutionRepository _solutionRepository;
    private readonly IDateService _dateService;

    public GetDirectionQueryHandler(IDirectionRepository directionRepository,
        IDateService dateService, IEnrollRepository enrollRepository,
        IUserProvider userProvider, ISolutionRepository solutionRepository)
    {
        _directionRepository = directionRepository;
        _dateService = dateService;
        _enrollRepository = enrollRepository;
        _userProvider = userProvider;
        _solutionRepository = solutionRepository;
    }

    public override async Task<Result<GetDirectionResponseDto>> Handle(GetDirectionQuery request,
        CancellationToken cancellationToken)
    {
        var direction =
            await _directionRepository.SingleOrDefaultAsync(
                x => x.Id == request.Id,
                cancellationToken: cancellationToken);
        if (direction == null)
            return Error(NotFoundError.Instance);

        var directionDto = new GetDirectionResponseDto(
            direction.Id,
            direction.Title,
            direction.Description,
            false,
            direction.WillBeAcceptedCount,
            _dateService.ToUnixTimestamp(direction.EndedAtUtc), direction.IsActive,
            direction.Department.ToString());
        var user = _userProvider.User;
        if (user is null) return Successful(directionDto);

        if (user.Role is not (UserRole.Student or UserRole.StudentNotFilled))
        {
            return Successful(directionDto);
        }

        if (user.IsBanned)
        {
            return Successful(directionDto);
        }

        if (!direction.IsActive)
        {
            return Error(NotFoundError.Instance);
        }

        var enroll =
            await _enrollRepository.SingleOrDefaultAsync(
                x => x.DirectionId == request.Id && x.StudentId == user.Id,
                cancellationToken);

        if (enroll is not null)
        {
            directionDto.StudentIsEnrolled = true;
            var solution = await _solutionRepository.FirstOrDefaultAsync(
                x => x.DirectionId == request.Id && x.AuthorId == user.Id, cancellationToken);
            directionDto.Status = "NotStarted";
            directionDto.SolutionId = null;
            if (solution is not null)
            {
                directionDto.Status = solution.Status.ToString();
                directionDto.SolutionId = solution.Id;
            }
        }

        return Successful(directionDto);
    }
}