using Application.Features.Direction.DTOs;
using Application.Features.Direction.Errors;
using Application.Services;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using NotFoundError = Application.Features.Direction.Errors.NotFoundError;

namespace Application.Features.Direction;

public class UpdateDirectionCommand : Command
{
    public long Id { get; set; }
    public UpdateDirectionDto UpdateDirectionDto { get; set; }
}

public class UpdateDirectionCommandHandler : CommandHandler<UpdateDirectionCommand>
{
    private readonly IDirectionRepository _directionRepository;
    private readonly IQuestionRepository _questionRepository;
    private readonly IDateService _dateService;

    public UpdateDirectionCommandHandler(IDirectionRepository directionRepository,
        IQuestionRepository questionRepository, IDateService dateService)
    {
        _directionRepository = directionRepository;
        _questionRepository = questionRepository;
        _dateService = dateService;
    }

    public override async Task<Result> Handle(UpdateDirectionCommand request, CancellationToken cancellationToken)
    {
        var direction = await _directionRepository.SingleOrDefaultAsync(x => request.Id == x.Id, cancellationToken);
        if (direction == null)
            return Error(NotFoundError.Instance);
        var requestUpdateDirectionDto = request.UpdateDirectionDto;
        var oldQuestions = await _questionRepository
            .ListAsync(x => direction.Id == x.DirectionId, cancellationToken);
        var newQuestions = request.UpdateDirectionDto.Questions
            .Select(question => new Question(question.Text, direction.Id)).ToList();
        if (requestUpdateDirectionDto.WillBeAcceptedCount < 0)
        {
            return Error(QuestionHasBadDirectionIdError.Instance);
        }

        direction.Update(
            requestUpdateDirectionDto.Title,
            requestUpdateDirectionDto.Description,
            requestUpdateDirectionDto.IsActive,
            _dateService.ToDateTime(requestUpdateDirectionDto.FinishingAcceptingAt),
            requestUpdateDirectionDto.WillBeAcceptedCount,
            requestUpdateDirectionDto.TaskDescription,
            requestUpdateDirectionDto.Department);
        await _questionRepository.RemoveRangeAsync(oldQuestions);
        await _questionRepository.AddRangeAsync(newQuestions, cancellationToken);
        await _directionRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful();
    }
}