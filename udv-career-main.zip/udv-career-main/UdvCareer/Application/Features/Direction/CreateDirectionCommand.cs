using Application.Features.Direction.DTOs;
using Application.Services;
using Domain.Models;
using Domain.Repositories;
using Ftsoft.Application.Cqs.Mediatr;
using Infrastructure.Storage.Repositories;

namespace Application.Features.Direction;

public class CreateDirectionCommand : Command
{
    public CreateDirectionDto CreateDirectionDto { get; set; }
}

public class CreateDirectionCommandHandler : CommandHandler<CreateDirectionCommand>
{
    private readonly IDirectionRepository _directionRepository;
    private readonly IQuestionRepository _questionRepository;
    private readonly IDateService _dateService;

    public CreateDirectionCommandHandler(DirectionRepository directionRepository,
        IDateService dateService, IQuestionRepository questionRepository)
    {
        _directionRepository = directionRepository;
        _dateService = dateService;
        _questionRepository = questionRepository;
    }

    public override async Task<Ftsoft.Common.Result.Result> Handle(CreateDirectionCommand request,
        CancellationToken cancellationToken)
    {
        var dto = request.CreateDirectionDto;

        var direction = new Domain.Models.Direction(
            dto.Title,
            dto.Description,
            dto.WillBeAcceptedCount,
            dto.IsActive,
            _dateService.ToDateTime(dto.EndedAt),
            dto.TaskDescription,
            dto.Department);
        await _directionRepository.AddAsync(direction, cancellationToken);
        await _directionRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        var questions = dto.Questions.Select(text => new Question(text, direction.Id)).ToList();
        await _questionRepository.AddRangeAsync(questions, cancellationToken);
        await _questionRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful(direction.Id);
    }
}