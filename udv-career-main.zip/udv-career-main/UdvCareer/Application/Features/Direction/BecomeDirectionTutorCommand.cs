using Application.Features.Direction.Errors;
using Application.Providers;
using Domain.Enums;
using Domain.Models;
using Ftsoft.Application.Cqs.Mediatr;
using Ftsoft.Common.Result;
using Infrastructure.Storage.Repositories;
using Microsoft.AspNetCore.Mvc;
using IResult = Ftsoft.Common.Result.IResult;

namespace Application.Features.Direction;

public class BecomeDirectionTutorCommand : Command
{
    [FromRoute] public long DirectionId { get; set; }
}

public sealed class BecomeDirectionTutorCommandHandler : CommandHandler<BecomeDirectionTutorCommand>
{
    private readonly DirectionRepository _directionRepository;
    private readonly IUserProvider _userProvider;
    private readonly DirectionTutorRepository _directionTutorRepository;

    private long _tutorId;
    private long _directionId;

    public BecomeDirectionTutorCommandHandler(DirectionRepository directionRepository, DirectionTutorRepository directionTutorRepository,
        IUserProvider userProvider)
    {
        _directionRepository = directionRepository;
        _directionTutorRepository = directionTutorRepository;
        _userProvider = userProvider;
    }

    protected override async Task<IResult> CanHandle(BecomeDirectionTutorCommand request,
        CancellationToken cancellationToken)
    {
        var direction =
            await _directionRepository.SingleOrDefaultAsync(x => x.Id == request.DirectionId, cancellationToken);
        if (direction == null)
            return Error(NotFoundError.Instance);
        if (_userProvider.User?.Role is not UserRole.Tutor)
        {
            return Error(Tutor.Errors.NotFoundError.Instance);
        }

        var isEnrolled =
            await _directionTutorRepository.SingleOrDefaultAsync(
                x => x.DirectionId == request.DirectionId && x.TutorId == _userProvider.User.Id, cancellationToken);
        if (isEnrolled is not null)
        {
            return Error(AlreadyEnrolledError.Instance);
        }

        _directionId = direction.Id;
        _tutorId = _userProvider.User.Id;
        return Successful();
    }

    public override async Task<Result> Handle(BecomeDirectionTutorCommand request, CancellationToken cancellationToken)
    {
        var directionTutor = new DirectionTutor(_tutorId, _directionId);
        await _directionTutorRepository.AddAsync(directionTutor, cancellationToken);
        await _directionTutorRepository.UnitOfWork.SaveChangesAsync(cancellationToken);
        return Successful();
    }
}