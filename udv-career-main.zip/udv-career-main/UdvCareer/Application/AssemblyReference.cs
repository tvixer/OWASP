namespace Application;

public class AssemblyReference
{
    
    
}