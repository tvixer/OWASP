﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Application.MailTemplates;

public class LoginCredentialsPage : PageModel
{
    public void OnGet()
    {
        
    }
}