﻿using Domain.Enums;

namespace Application.MailTemplates;

public class TutorCheckedSolutionViewModel
{
    public string DirectionLink { get; set; }
    public string DirectionTitle { get; set; }
    public SolutionStatus SolutionStatus { get; set; }
    public string OfferEndDate { get; set; }
    public string OffersLink { get; set; }
}