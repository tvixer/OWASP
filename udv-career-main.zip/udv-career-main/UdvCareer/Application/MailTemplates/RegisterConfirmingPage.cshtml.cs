﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Application.MailTemplates;

public class RegisterConfirmingPage : PageModel
{
    public void OnGet()
    {
        
    }
}