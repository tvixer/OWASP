﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Application.MailTemplates;

public class TutorCheckedSolution : PageModel
{
    public void OnGet()
    {
        
    }
}