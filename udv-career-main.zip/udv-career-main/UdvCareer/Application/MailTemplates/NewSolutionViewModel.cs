﻿namespace Application.MailTemplates;

public class NewSolutionViewModel
{
    public string UserFullname { get; set; }
    public string UserEmail { get; set; }
    public string DirectionTitle { get; set; }
    public string SendedAt { get; set; }
    public string CheckLink { get; set; }
}