﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Application.MailTemplates;

public class NewSolutionPage : PageModel
{
    public void OnGet()
    {
        
    }
}