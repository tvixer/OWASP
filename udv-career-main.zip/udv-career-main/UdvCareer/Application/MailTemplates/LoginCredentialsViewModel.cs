﻿namespace Application.MailTemplates;

public class LoginCredentialsViewModel
{
    public string Email { get; set; }
    public string Password { get; set; }
    public string EnterUrl { get; set; }
    public string ResetUrl { get; set; }
}