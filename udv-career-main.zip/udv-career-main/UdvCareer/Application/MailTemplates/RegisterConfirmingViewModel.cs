﻿namespace Application.MailTemplates;

public class RegisterConfirmingViewModel
{
    public string ConfirmLink { get; set; }
}