using Application.Providers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace Application.Filters;

public class AuthorizationFilter : IAsyncAuthorizationFilter
{
    private readonly IUserProvider _userProvider;
    private readonly ILogger<AuthorizationFilter> _logger;

    public AuthorizationFilter(IUserProvider userProvider, ILogger<AuthorizationFilter> logger)
    {
        _userProvider = userProvider;
        _logger = logger;
    }

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        _logger.LogError("Starting authorizing");
        var authorized = await IsAuthorize(context);
        _logger.LogError("Authorized " + authorized);
        if (!authorized)
        {
            context.Result = new UnauthorizedResult();
        }
    }

    private async Task<bool> IsAuthorize(ActionContext context)
    {
        await _userProvider.Login(context.HttpContext);
        return true;
    }
}