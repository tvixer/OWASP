using Application.Providers;
using Microsoft.Extensions.Configuration;

namespace Application.Services.TokenServices;

public class ResetTokenService : BaseTokenService, IResetTokenService
{
    public override string GetTokenLifetimeConfigurationString()
    {
        return "ResetTokenLifetime";
    }

    public ResetTokenService(IConfiguration configuration, IDateProvider dateProvider) : base(configuration, dateProvider)
    {
    }
}