namespace Application.Services.TokenServices;

public interface IRegisterTokenService : ITokenService
{
    
}