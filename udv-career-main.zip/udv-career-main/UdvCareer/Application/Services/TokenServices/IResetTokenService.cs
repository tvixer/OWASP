namespace Application.Services.TokenServices;

public interface IResetTokenService : ITokenService
{
    
}