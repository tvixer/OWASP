namespace Application.Services.TokenServices;

public interface ITokenService
{
    public string GetTokenLifetimeConfigurationString();
    public string? Generate(long userId);
    public Token? Use(string email);
}

public class Token
{
    public Token(string id, long userId, DateTime expiredAt)
    {
        Id = id;
        UserId = userId;
        ExpiredAt = expiredAt;
    }

    public string Id { get; set; }
    public long UserId { get; set; }
    public DateTime ExpiredAt { get; set; }
}