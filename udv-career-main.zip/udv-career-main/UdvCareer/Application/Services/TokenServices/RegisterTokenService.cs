using Application.Providers;
using Microsoft.Extensions.Configuration;

namespace Application.Services.TokenServices;

public class RegisterTokenService : BaseTokenService, IRegisterTokenService
{
    public override string GetTokenLifetimeConfigurationString()
    {
        return "RegisterTokenLifetime";
    }

    public RegisterTokenService(IConfiguration configuration, IDateProvider dateProvider) : base(configuration, dateProvider)
    {
    }
}