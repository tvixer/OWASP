﻿using System.Collections.Concurrent;
using Application.Providers;
using Microsoft.Extensions.Configuration;

namespace Application.Services.TokenServices;

public abstract class BaseTokenService : ITokenService
{
    private readonly IConfiguration _configuration;
    private readonly ConcurrentDictionary<string, Token> _tokens = new();
    private readonly List<Token> _tokensSortedByExpiration = new();
    private readonly TokenComparer _comparer = new();
    private readonly IDateProvider _dateProvider;
    public abstract string GetTokenLifetimeConfigurationString();

    public BaseTokenService(IConfiguration configuration, IDateProvider dateProvider)
    {
        _configuration = configuration;
        _dateProvider = dateProvider;
    }

    public string? Generate(long userId)
    {
        var guid = Guid.NewGuid().ToString();
        var expiredAt = _dateProvider.UtcNow().AddMinutes(double.Parse(_configuration[GetTokenLifetimeConfigurationString()]));
        var tokenData = new Token(guid, userId, expiredAt);
        var isAdded = Add(tokenData);
        Shrink();
        return isAdded ? tokenData.Id : null;
    }

    private bool Add(Token token)
    {
        var index = _tokensSortedByExpiration.BinarySearch(token, _comparer);
        _tokensSortedByExpiration.Insert(~index, token);
        return _tokens.TryAdd(token!.Id, token);
    }

    private void Shrink()
    {
        var now = _dateProvider.UtcNow();
        for (var i = 0; i < _tokensSortedByExpiration.Count; i++)
        {
            if (_tokensSortedByExpiration[i].ExpiredAt <= now)
            {
                Remove();
                i--;
                continue;
            }

            break;
        }
    }

    private void Remove()
    {
        if (_tokensSortedByExpiration.Count <= 0)
            return;
        var token = _tokensSortedByExpiration[0];
        _tokens.TryRemove(token.Id, out _);
        _tokensSortedByExpiration.RemoveAt(0);
    }

    public Token? Use(string token)
    {
        if (!_tokens.Remove(token, out var tokenData))
        {
            return null;
        }

        if (tokenData.Id != token || tokenData.ExpiredAt >= DateTime.Now)
        {
            return null;
        }

        return tokenData;
    }

    private class TokenComparer : IComparer<Token>
    {
        public int Compare(Token? x, Token? y)
        {
            var result = x.ExpiredAt.CompareTo(y.ExpiredAt);
            return result != 0 ? result : string.Compare(x.Id, y.Id, StringComparison.Ordinal);
        }
    }
}