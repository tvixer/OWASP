﻿namespace Application.Services;

public interface IPasswordGeneratorService
{
    public string Generate();
}