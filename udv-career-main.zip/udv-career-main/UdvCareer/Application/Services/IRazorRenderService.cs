﻿namespace Application.Services;

public interface IRazorRenderService
{
    public Task<string> RenderAsString(string templateName, object model);
}