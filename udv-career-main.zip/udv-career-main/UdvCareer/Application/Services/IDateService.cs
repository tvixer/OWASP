namespace Application.Services;

public interface IDateService
{
    public long ToUnixTimestamp(DateTime dateTime);
    public DateTime ToDateTime(long unixTimestamp);
}