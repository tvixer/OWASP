namespace Application.Services;

public interface IJwtService
{
    public string? CreateToken(string id, string email, string role);
}