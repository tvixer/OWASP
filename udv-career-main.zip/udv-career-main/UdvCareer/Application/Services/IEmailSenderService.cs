using Application.Services.Models;

namespace Application.Services;

public interface IEmailSenderService
{
    void Send(Message message);
    Task SendAsync(Message message);
}