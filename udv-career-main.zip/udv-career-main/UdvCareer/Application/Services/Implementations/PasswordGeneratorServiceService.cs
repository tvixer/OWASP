﻿namespace Application.Services.Implementations;

public class PasswordGeneratorServiceService : IPasswordGeneratorService
{
    public string Generate()
    {
        var password = Guid.NewGuid().ToString("N").ToLower()
            .Replace("1", "").Replace("o", "").Replace("0", "")[..10];
        return password;
    }
}