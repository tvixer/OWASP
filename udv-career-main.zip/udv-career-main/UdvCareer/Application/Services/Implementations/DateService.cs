namespace Application.Services.Implementations;

public class DateService : IDateService
{
    public long ToUnixTimestamp(DateTime dateTime)
    {
        return ((DateTimeOffset)dateTime).ToUnixTimeMilliseconds();
    }

    public DateTime ToDateTime(long unixTimestamp)
    {
        return DateTimeOffset.FromUnixTimeMilliseconds(unixTimestamp).UtcDateTime;
    }
}