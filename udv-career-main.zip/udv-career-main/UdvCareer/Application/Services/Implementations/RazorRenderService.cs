﻿using Microsoft.AspNetCore.Mvc.Razor;
using RazorEngine;
using RazorEngine.Templating;

namespace Application.Services.Implementations;

public class RazorRenderService : IRazorRenderService
{
    public async Task<string> RenderAsString(string templateName, object model)
    {
        var razorView = await File.ReadAllTextAsync(
            Path.GetDirectoryName(typeof(AssemblyReference).Assembly.Location) + "/MailTemplates/" +
            templateName+".cshtml");
            
        var html = Engine.Razor.RunCompile(razorView, templateName, null, model);
        return html;
    }
    
    
}