namespace Application.Providers;

public interface IDateProvider
{
    public DateTime UtcNow();
}