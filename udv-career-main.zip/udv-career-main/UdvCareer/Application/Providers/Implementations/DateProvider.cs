namespace Application.Providers.Implementations;

public class DateProvider : IDateProvider
{
    public DateTime UtcNow()
    {
        return DateTime.UtcNow;
    }
}