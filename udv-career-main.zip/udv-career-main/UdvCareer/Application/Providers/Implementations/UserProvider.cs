using System.Security.Claims;
using Domain.Models;
using Infrastructure.Storage.Repositories;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;

namespace Application.Providers.Implementations;

public class UserProvider : IUserProvider
{
    private readonly UserRepository _userRepository;

    public UserProvider(UserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public async Task<bool> Login(HttpContext httpContext)
    {
        if (httpContext == null)
        {
            throw new Exception("HttpContext is null");
        }

        var auth = await httpContext.AuthenticateAsync(JwtBearerDefaults.AuthenticationScheme);
        if (auth.Succeeded)
        {
            var claimsPrincipal = auth.Principal;
            var cancellationToken = httpContext.RequestAborted;
            var parsed = long.TryParse(claimsPrincipal.FindFirstValue(ClaimTypes.NameIdentifier), out var id);
            if (!parsed)
            {
                return false;
            }

            User = await _userRepository.SingleOrDefaultAsync(x => x.Id == id, cancellationToken);
        }

        return User != null;
    }


    public BaseUser? User { get; private set; }
}