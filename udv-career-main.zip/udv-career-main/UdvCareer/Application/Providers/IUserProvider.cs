using Domain.Models;
using Microsoft.AspNetCore.Http;

namespace Application.Providers;

public interface IUserProvider
{
    public Task<bool> Login(HttpContext httpContext);
    public BaseUser? User { get; }
}