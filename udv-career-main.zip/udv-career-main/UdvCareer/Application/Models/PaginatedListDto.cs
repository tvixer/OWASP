namespace Application.Models;

public class PaginatedListDto<T>
{
    public PaginatedListDto(IReadOnlyList<T> items, int total)
    {
        Items = items;
        Total = total;
    }

    public IReadOnlyList<T> Items { get; set; }
    public int Total { get; set; }
}