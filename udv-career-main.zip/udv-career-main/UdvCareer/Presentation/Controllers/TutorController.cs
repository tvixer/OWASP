using Application.Features.Direction.DTOs;
using Application.Features.Direction.DTOs.Responses;
using Application.Features.Tutor;
using Application.Features.Tutor.Errors;
using Ftsoft.Common.Result;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers
{
    [Route("api/tutor")]
    [ApiController]
    public class TutorController : BaseController
    {
        private readonly IMediator _mediator;

        public TutorController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [Authorize(Roles = "Tutor,Hr")]
        [HttpGet("{id:long}/directions")]
        public async Task<ActionResult<List<GetDirectionResponseDto>>> GetTutorDirections(
            [FromRoute] long id)
        {
            var getTutorDirectionsQuery = new GetTutorDirectionsQuery
            {
                Id = id
            };
            var result = await _mediator.Send(getTutorDirectionsQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok(result.GetValue<IReadOnlyList<TutorDirectionDto>>());
        }
    }
}