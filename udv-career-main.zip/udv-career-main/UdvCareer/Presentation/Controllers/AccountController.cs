using System.Text.Json;
using Application.Features.Auth;
using Application.Features.User.DTOs;
using Application.Features.User.Errors;
using Ftsoft.Common.Result;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers
{
    [Authorize]
    [Route("api/account")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IMediator mediator, ILogger<AccountController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        [HttpGet]
        [Authorize(Roles = "Student,StudentNotFilled,Hr,Tutor")]
        public async Task<ActionResult<UserDto>> GetAuthorizedUser(
        )
        {
            var getAuthorizedUserQuery = new GetAuthorizedUserQuery();
            var result = await _mediator.Send(getAuthorizedUserQuery);
            if (!result.IsSuccessfull)
                return BadRequest(result.GetErrors().FirstOrDefault());
            return Ok(result.Value);
        }

        [AllowAnonymous]
        [HttpPut]
        public async Task<ActionResult> UpdateAuthorizedUser([FromBody] UpdateUserCommand updateUserCommand)
        {
            var result = await _mediator.Send(updateUserCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok(result.GetValue<string>());
        }


        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<ActionResult<string>> Login([FromBody] LoginCommand loginCommand)
        {
            var result = await _mediator.Send(loginCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok(result.GetValue<string?>());
        }

        [AllowAnonymous]
        [HttpGet("verify")]
        public async Task<ActionResult> Verify(
            [FromQuery(Name = "token")] string token,
            [FromQuery(Name = "redirectTo")] string redirectTo
        )
        {
            var confirmAccountCommand = new ConfirmAccountCommand()
            {
                Token = token
            };
            var result = await _mediator.Send(confirmAccountCommand);
            if (!result.IsSuccessfull)
            {
                return BadRequest(result.GetErrors().FirstOrDefault());
            }

            return Redirect(redirectTo);
        }


        [Authorize]
        [HttpPost("logout")]
        public ActionResult Logout()
        {
            // TODO: Добавить менеджер токенов
            return Ok();
        }


        [AllowAnonymous]
        [HttpPost("reset-password")]
        public async Task<ActionResult> ResetPassword([FromBody] ResetPasswordCommand resetPasswordCommand)
        {
            var result = await _mediator.Send(resetPasswordCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("send-reset-mail")]
        public async Task<ActionResult> SendResetPasswordMail(
            [FromBody] SendResetPasswordEmailCommand sendResetPasswordEmailCommand)
        {
            var result = await _mediator.Send(sendResetPasswordEmailCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("register/student")]
        public async Task<ActionResult> RegisterStudent([FromBody] RegisterStudentCommand registerStudentCommand)
        {
            var result = await _mediator.Send(registerStudentCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Hr")]
        [HttpPost("register/tutor")]
        public async Task<ActionResult> RegisterTutor([FromBody] RegisterTutorCommand registerTutorCommand)
        {
            _logger.LogInformation("Registering Tutor: " + JsonSerializer.Serialize(registerTutorCommand));
            var result = await _mediator.Send(registerTutorCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Hr")]
        [HttpPost("register/hr")]
        public async Task<ActionResult> RegisterHr([FromBody] RegisterHrCommand registerHrCommand)
        {
            _logger.LogInformation("Registering HR: " + JsonSerializer.Serialize(registerHrCommand));
            var result = await _mediator.Send(registerHrCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Hr")]
        [HttpPost("ban")]
        public async Task<ActionResult> Ban([FromBody] BanUserCommand banUserCommand)
        {
            var result = await _mediator.Send(banUserCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Hr")]
        [HttpPost("unban")]
        public async Task<ActionResult> Unban([FromBody] UnbanUserCommand unbanUserCommand)
        {
            var result = await _mediator.Send(unbanUserCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }
    }
}