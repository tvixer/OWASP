using Application.Features.Offer;
using Application.Features.Offer.Errors;
using Application.Features.Offer.Models;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers
{
    [Authorize]
    [Route("api/offers")]
    [ApiController]
    public class OfferController : ControllerBase
    {
        private readonly IMediator _mediator;

        public OfferController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [Authorize(Roles = "Student")]
        [HttpPost("{id:long}")]
        public async Task<ActionResult> DecideOffer([FromRoute] long id, [FromBody] DecideOfferStatus status)
        {
            var decideOfferCommand = new DecideOfferCommand()
            {
                Id = id,
                Status = status
            };
            var result = await _mediator.Send(decideOfferCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }

        [HttpGet]
        [Authorize(Roles = "Student,Hr,Tutor")]
        public async Task<ActionResult<IReadOnlyList<OfferDto>>> GetManyOffers([FromQuery] long studentId)
        {
            var getManyOffersQuery = new GetManyOffersQuery()
            {
                RecipientId = studentId
            };
            var result = await _mediator.Send(getManyOffersQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok(result.Value);
        }
    }
}