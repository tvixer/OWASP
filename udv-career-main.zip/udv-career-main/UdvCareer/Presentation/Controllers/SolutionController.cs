using Application.Features.Solution;
using Application.Features.Solution.Errors;
using Application.Features.Solution.Models;
using Application.Features.SolutionMessages;
using Application.Features.SolutionMessages.Models;
using Application.Models;
using Ftsoft.Common.Result;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers
{
    [Authorize]
    [Route("api/solutions")]
    [ApiController]
    public class SolutionController : BaseController
    {
        private readonly IMediator _mediator;

        public SolutionController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [Authorize(Roles = "Hr,Tutor")]
        [HttpGet]
        public async Task<ActionResult<PaginatedListDto<GetManySolutionsResponseDto>>> GetSolutions(
            [FromQuery] GetManySolutionsQuery getManySolutionsQuery)
        {
            var result = await _mediator.Send(getManySolutionsQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok(result.GetValue<PaginatedListDto<GetManySolutionsResponseDto>>());
        }

        [Authorize(Roles = "Tutor,Student")]
        [HttpGet("{id:long}/messages")]
        public async Task<ActionResult<IReadOnlyList<SolutionMessageDto>>> GetSolutionMessages(
            [FromRoute] long id)
        {
            var getSolutionMessagesQuery = new GetSolutionMessagesQuery()
            {
                SolutionId = id
            };
            var result = await _mediator.Send(getSolutionMessagesQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok(result.GetValue<IReadOnlyList<SolutionMessageDto>>());
        }

        [Authorize(Roles = "Tutor,Student")]
        [HttpPost("{id:long}/messages")]
        public async Task<ActionResult> SendSolutionMessage(
            [FromRoute] long id, [FromBody] SendSolutionMessageRequestDto solutionMessageRequestDto)
        {
            var getSolutionMessagesQuery = new SendSolutionMessageCommand()
            {
                Id = id, SendSolutionMessageRequestDto = solutionMessageRequestDto
            };
            var result = await _mediator.Send(getSolutionMessagesQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok();
        }


        [Authorize(Roles = "Hr,Tutor,Student")]
        [HttpGet("{id:long}")]
        public async Task<ActionResult<GetSolutionResponseDto>> GetSolution([FromRoute] long id)
        {
            var getSolutionQuery = new GetSolutionQuery()
            {
                SolutionId = id
            };
            var result = await _mediator.Send(getSolutionQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok(result.GetValue<GetSolutionResponseDto>());
        }

        [Authorize(Roles = "Student")]
        [HttpPost]
        public async Task<ActionResult> SendSolution([FromBody] SendSolutionCommand sendSolutionCommand)
        {
            var result = await _mediator.Send(sendSolutionCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Tutor")]
        [HttpPost("{id:long}/verdict")]
        public async Task<ActionResult> MakeVerdict([FromRoute] long id, [FromBody] MakeSolutionDecisionDto dto)
        {
            var command = new MakeSolutionDecisionCommand
            {
                Id = id,
                Dto = dto
            };
            var result = await _mediator.Send(command);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }
    }
}