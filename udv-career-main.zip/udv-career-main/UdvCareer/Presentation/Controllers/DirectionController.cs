using Application.Features.Direction;
using Application.Features.Direction.DTOs;
using Application.Features.Direction.DTOs.Responses;
using Application.Features.Direction.Errors;
using Application.Features.Models;
using Application.Features.Student.DTOs;
using Application.Models;
using Ftsoft.Common.Result;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers
{
    [Route("api/directions")]
    [ApiController]
    public class DirectionController : BaseController
    {
        private readonly IMediator _mediator;

        public DirectionController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<PaginatedListDto<GetManyDirectionsResponseDto>>> GetManyDirections(
            [FromQuery] GetManyDirectionsDto getManyDirectionsDto
        )
        {
            var getManyDirectionsQuery = new GetManyDirectionsQuery()
            {
                GetManyDirectionsDto = getManyDirectionsDto
            };
            var result = await _mediator.Send(getManyDirectionsQuery);
            if (result.IsSuccessfull)
            {
                return Ok(result.GetValue<PaginatedListDto<GetManyDirectionsResponseDto>>());
            }

            var error = result.GetErrors().FirstOrDefault();
            if (error is NotFoundError)
            {
                return NotFound(error);
            }

            return BadRequest(error);
        }

        [AllowAnonymous]
        [HttpGet("{id:long}")]
        public async Task<ActionResult<GetDirectionResponseDto>> GetDirection([FromRoute] long id)
        {
            var getDirectionQuery = new GetDirectionQuery()
            {
                Id = id
            };
            var result = await _mediator.Send(getDirectionQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            var data = result.GetValue<GetDirectionResponseDto>();
            return Ok(data);
        }

        [Authorize(Roles = "Hr,Tutor")]
        [HttpGet("{id:long}/students")]
        public async Task<ActionResult> GetDirectionStudents(
            [FromRoute(Name = "id")] long id,
            [FromQuery] PaginateParams paginateParams)
        {
            var getDirectionStudentsQuery = new GetDirectionStudentsQuery()
            {
                Id = id,
                PaginateParams = paginateParams
            };
            var result = await _mediator.Send(getDirectionStudentsQuery);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok(result.GetValue<PaginatedListDto<StudentDto>>());
        }

        [Authorize(Roles = "Student")]
        [HttpPost("{id:long}/students")]
        public async Task<ActionResult> EnrollDirection([FromRoute] long id)
        {
            var enrollDirectionCommand = new EnrollDirectionCommand()
            {
                Id = id
            };
            var result = await _mediator.Send(enrollDirectionCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Tutor")]
        [HttpPost("{id:long}/tutors")]
        public async Task<ActionResult> BecomeTutor([FromRoute] long id)
        {
            var becomeDirectionTutorCommand = new BecomeDirectionTutorCommand()
            {
                DirectionId = id
            };
            var result = await _mediator.Send(becomeDirectionTutorCommand);
            if (!result.IsSuccessfull)
                return BadRequest(result.GetErrors().FirstOrDefault());
            return Ok();
        }

        [Authorize(Roles = "Tutor")]
        [HttpDelete("{id:long}/tutors")]
        public async Task<ActionResult> GiveUpTutoring([FromRoute] long id)
        {
            var giveUpDirectionTutoringCommand = new GiveUpDirectionTutoringCommand()
            {
                Id = id
            };
            var result = await _mediator.Send(giveUpDirectionTutoringCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Hr")]
        [HttpPost]
        public async Task<ActionResult<long>> CreateDirection([FromBody] CreateDirectionDto createDirectionDto)
        {
            var createDirectionCommand = new CreateDirectionCommand()
            {
                CreateDirectionDto = createDirectionDto
            };
            var result = await _mediator.Send(createDirectionCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                return BadRequest(error);
            }

            return Ok(result.GetValue<long>());
        }

        [Authorize(Roles = "Hr")]
        [HttpDelete("{id:long}")]
        public async Task<ActionResult> DeleteDirection([FromRoute] long id)
        {
            var deleteDirectionCommand = new DeleteDirectionCommand()
            {
                Id = id
            };
            var result = await _mediator.Send(deleteDirectionCommand);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Hr")]
        [HttpPut("{id:long}")]
        public async Task<ActionResult> UpdateDirection(
            [FromRoute] long id,
            [FromBody] UpdateDirectionDto updateDirectionDto)
        {
            var command = new UpdateDirectionCommand()
            {
                Id = id,
                UpdateDirectionDto = updateDirectionDto
            };
            var result = await _mediator.Send(command);
            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok();
        }

        [Authorize(Roles = "Hr,Student,Tutor")]
        [HttpGet("{id:long}/questions")]
        public async Task<ActionResult<GetDirectionQuestionsResponseDto>> GetDirectionQuestions(
            [FromRoute] long id
        )
        {
            var command = new GetDirectionQuestionsQuery()
            {
                Id = id
            };
            var result = await _mediator.Send(command);

            if (!result.IsSuccessfull)
            {
                var error = result.GetErrors().FirstOrDefault();
                if (error is NotFoundError)
                {
                    return NotFound(error);
                }

                return BadRequest(error);
            }

            return Ok(result.GetValue<GetDirectionQuestionsResponseDto>());
        }
    }
}