using Application.Features.User;
using Application.Features.User.DTOs;
using Application.Models;
using Ftsoft.Common.Result;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers;

[Route("api/users")]
[ApiController]
public class UserController : BaseController
{
    private readonly IMediator _mediator;

    public UserController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [Authorize(Roles = "Hr")]
    [HttpGet]
    public async Task<ActionResult<PaginatedListDto<GetManyUsersDto>>> GetUsers(
        [FromQuery(Name = "role")] string? role,
        [FromQuery(Name = "limit")] int limit,
        [FromQuery(Name = "page")] int page
    )
    {
        var getStudentDirectionsQuery = new GetManyUsersQuery()
        {
            Limit = limit,
            Page = page,
            Role = role
        };
        var result = await _mediator.Send(getStudentDirectionsQuery);
        if (!result.IsSuccessfull)
        {
            var error = result.GetErrors().FirstOrDefault();
            return BadRequest(error);
        }

        return Ok(result.GetValue<PaginatedListDto<GetManyUsersDto>>());
    }
}