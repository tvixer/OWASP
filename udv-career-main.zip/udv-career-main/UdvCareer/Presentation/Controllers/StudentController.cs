using Application.Features.Direction.DTOs.Responses;
using Application.Features.Student;
using Application.Features.Student.DTOs;
using Application.Features.Student.Errors;
using Application.Providers;
using Ftsoft.Common.Result;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers;

[Route("api/students")]
[ApiController]
public class StudentController : BaseController
{
    private readonly IMediator _mediator;
    private readonly IDateProvider _dateProvider;

    public StudentController(IMediator mediator, IDateProvider dateProvider)
    {
        _mediator = mediator;
        _dateProvider = dateProvider;
    }

    [Authorize(Roles = "Hr,Tutor")]
    [HttpGet("{id:long}")]
    public async Task<ActionResult<StudentDto>> GetStudent([FromRoute] long id)
    {
        var getStudentQuery = new GetStudentQuery()
        {
            Id = id
        };
        var result = await _mediator.Send(getStudentQuery);
        if (!result.IsSuccessfull)
        {
            var error = result.GetErrors().FirstOrDefault();
            if (error is NotFoundError)
            {
                return NotFound(error);
            }

            return BadRequest(error);
        }

        return Ok(result.GetValue<StudentDto>());
    }

    [Authorize(Roles = "Student,Hr")]
    [HttpPut("{id:long}")]
    public async Task<ActionResult> UpdateStudent(
        [FromRoute] long id,
        [FromBody] UpdateStudentDto updateStudentDto)
    {
        var updateStudentCommand = new UpdateStudentCommand()
        {
            Id = id,
            UpdateStudentDto = updateStudentDto
        };
        var result = await _mediator.Send(updateStudentCommand);
        if (!result.IsSuccessfull)
        {
            var error = result.GetErrors().FirstOrDefault();
            if (error is NotFoundError)
            {
                return NotFound(error);
            }

            return BadRequest(error);
        }

        return Ok();
    }

    [Authorize(Roles = "Student")]
    [HttpGet("{id:long}/directions")]
    public async Task<ActionResult<IReadOnlyList<GetStudentDirectionsResponseDto>>> GetStudentDirections(
        [FromRoute] long id)
    {
        var getStudentDirectionsQuery = new GetStudentDirectionsQuery
        {
            Id = id
        };
        var result = await _mediator.Send(getStudentDirectionsQuery);
        if (!result.IsSuccessfull)
        {
            var error = result.GetErrors().FirstOrDefault();
            if (error is NotFoundError)
            {
                return NotFound(error);
            }

            return BadRequest(error);
        }

        return Ok(result.GetValue<IReadOnlyList<GetStudentDirectionsResponseDto>>());
    }


    [Authorize(Roles = "Student")]
    [HttpGet("{id:long}/solutions")]
    public async Task<ActionResult<List<GetDirectionResponseDto>>> GetStudentSolutions(
        [FromRoute] long id)
    {
        var getStudentDirectionsQuery = new GetStudentDirectionsQuery
        {
            Id = id
        };
        var result = await _mediator.Send(getStudentDirectionsQuery);
        if (!result.IsSuccessfull)
        {
            var error = result.GetErrors().FirstOrDefault();
            if (error is NotFoundError)
            {
                return NotFound(error);
            }

            return BadRequest(error);
        }

        return Ok(result.GetValue<List<GetDirectionResponseDto>>());
    }

    [Authorize(Roles = "Hr,Tutor")]
    [HttpGet("export")]
    public async Task<ActionResult> ExportList()
    {
        var exportStudentsQuery = new ExportStudentsQuery();
        var result = await _mediator.Send(exportStudentsQuery);
        if (!result.IsSuccessfull)
        {
            var error = result.GetErrors().FirstOrDefault();
            return BadRequest(error);
        }

        var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        return File(result.GetValue<byte[]>(), contentType,
            $"students{_dateProvider.UtcNow().ToLongTimeString()}.xlsx");
    }
}