using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class UserRepository : EFRepository<BaseUser, CareerDbContext>, IUserRepository
{
    public UserRepository(CareerDbContext context) : base(context)
    {
    }
}