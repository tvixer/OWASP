using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class QuestionRepository : EFRepository<Question, CareerDbContext>, IQuestionRepository
{
    public QuestionRepository(CareerDbContext context) : base(context)
    {
    }
}