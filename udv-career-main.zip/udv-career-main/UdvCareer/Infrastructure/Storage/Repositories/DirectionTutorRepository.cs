using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class DirectionTutorRepository : EFRepository<DirectionTutor, CareerDbContext>, IDirectionTutorRepository
{
    public DirectionTutorRepository(CareerDbContext context) : base(context)
    {
    }
}