using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class DirectionRepository :  EFRepository<Direction, CareerDbContext>, IDirectionRepository
{
    public DirectionRepository(CareerDbContext context) : base(context)
    {
    }
}