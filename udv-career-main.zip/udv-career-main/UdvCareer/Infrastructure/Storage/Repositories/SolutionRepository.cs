using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;
using Solution = Domain.Models.Solution;

namespace Infrastructure.Storage.Repositories;

public class SolutionRepository : EFRepository<Solution, CareerDbContext>, ISolutionRepository
{
    public SolutionRepository(CareerDbContext context) : base(context)
    {
    }
}