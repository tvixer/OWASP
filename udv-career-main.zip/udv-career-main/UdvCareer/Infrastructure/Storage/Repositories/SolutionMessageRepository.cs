using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class SolutionMessageRepository : EFRepository<SolutionMessage, CareerDbContext>, ISolutionMessageRepository
{

    public SolutionMessageRepository(CareerDbContext context) : base(context)
    {
    }
}