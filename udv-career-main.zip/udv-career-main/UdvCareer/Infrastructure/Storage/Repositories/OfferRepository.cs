using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class OfferRepository : EFRepository<Offer, CareerDbContext>, IOfferRepository
{
    public OfferRepository(CareerDbContext context) : base(context)
    {
    }
}