using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class HrUserRepository : EFRepository<HrUser, CareerDbContext>, IHrUserRepository
{
    public HrUserRepository(CareerDbContext context) : base(context)
    {
    }
}