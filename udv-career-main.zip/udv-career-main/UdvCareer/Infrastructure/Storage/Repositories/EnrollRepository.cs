using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class EnrollRepository : EFRepository<Enroll, CareerDbContext>, IEnrollRepository
{
    public EnrollRepository(CareerDbContext context) : base(context)
    {
    }
}