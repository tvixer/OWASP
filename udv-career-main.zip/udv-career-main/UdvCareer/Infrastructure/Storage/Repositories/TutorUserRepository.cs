using Domain.Models;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;

namespace Infrastructure.Storage.Repositories;

public class TutorUserRepository : EFRepository<TutorUser, CareerDbContext>, ITutorUserRepository
{
    public TutorUserRepository(CareerDbContext context) : base(context)
    {
    }
}