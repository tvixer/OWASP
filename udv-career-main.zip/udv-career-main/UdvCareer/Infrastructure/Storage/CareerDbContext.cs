using Domain.Models;
using Ftsoft.Storage;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Storage;

public class CareerDbContext : DbContext, IUnitOfWork
{
    public CareerDbContext()
    {
    }

    public CareerDbContext(DbContextOptions options) : base(options)
    {
    }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(CareerDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    public DbSet<BaseUser> BaseUsers { get; set; }
    public DbSet<Direction> Directions { get; set; }
    public DbSet<DirectionTutor> DirectionTutors { get; set; }
    public DbSet<Enroll> Enrolls { get; set; }
    public DbSet<HrUser> HrUsers { get; set; }
    public DbSet<StudentUser> StudentUsers { get; set; }
    public DbSet<TutorUser> TutorUsers { get; set; }
    public DbSet<Solution> Solutions { get; set; }
    public DbSet<Offer> Offers { get; set; }
    public DbSet<Question> Questions { get; set; }
    public DbSet<SolutionMessage> SolutionMessages { get; set; }
}