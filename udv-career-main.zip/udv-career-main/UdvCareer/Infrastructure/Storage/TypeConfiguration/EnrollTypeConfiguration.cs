using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class EnrollTypeConfiguration : IEntityTypeConfiguration<Enroll>
{
    public void Configure(EntityTypeBuilder<Enroll> builder)
    {
    }
}