using Domain.Enums;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class DirectionTypeConfiguration : IEntityTypeConfiguration<Direction>
{
    public void Configure(EntityTypeBuilder<Direction> builder)
    {
        builder.Property(x => x.Title).HasMaxLength(100);
        builder.Property(x => x.Description).HasMaxLength(100000);
        builder.Property(x => x.TaskDescription).HasMaxLength(5000);
        builder.Property(x => x.WillBeAcceptedCount).IsRequired();
        builder.Property(x => x.Department).IsRequired();
        builder.Property(x => x.IsActive).IsRequired();

        builder.HasData(
            new Direction(
                "Тестовое направление",
                "Description",
                20,
                true,
                DateTime.UtcNow.AddDays(30), "Description", DirectionDepartment.USSC) { Id = 1 },
            new Direction(
                "Неактивное направление",
                "Description",
                20,
                false,
                DateTime.UtcNow.AddDays(30), "Description", DirectionDepartment.USSC) { Id = 2 },
            new Direction(
                "Просроченное направление",
                "Description",
                20,
                false,
                DateTime.UtcNow.AddDays(-30), "Description", DirectionDepartment.UDV) { Id = 3 }
        );
    }
}