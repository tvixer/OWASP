using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class TutorUserTypeConfiguration : IEntityTypeConfiguration<TutorUser>
{
    public void Configure(EntityTypeBuilder<TutorUser> builder)
    {
        builder.ToTable("TutorUsers");

        builder.HasData(new TutorUser(
            "tutor@h.ru",
            "$2a$11$OivsBSqdX.z5Wfi2KIJYqevBDcK4qAIqQIgP2nxslMT5Onsk5nuy.",
            true,
            "",
            "",
            "",
            "88005553535",
            false) { Id = 2 });
    }
}