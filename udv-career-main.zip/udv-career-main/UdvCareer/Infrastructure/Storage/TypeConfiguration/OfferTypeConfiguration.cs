using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class OfferTypeConfiguration : IEntityTypeConfiguration<Offer>
{
    public void Configure(EntityTypeBuilder<Offer> builder)
    {
        builder.Property(x => x.Status).IsRequired();
        builder.Property(x => x.DirectionId).IsRequired();
        builder.Property(x => x.DirectionTitle).IsRequired();
        builder.Property(x => x.OfferRecipientId).IsRequired();
        builder.Property(x => x.EndedAtUtc).IsRequired();
    }
}