using Domain.Enums;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class StudentUserTypeConfiguration : IEntityTypeConfiguration<StudentUser>
{
    public void Configure(EntityTypeBuilder<StudentUser> builder)
    {
        builder.ToTable("StudentUsers");

        builder.Property(x => x.Institute).HasMaxLength(200);
        builder.Property(x => x.Specialization).HasMaxLength(100);
        builder.Property(x => x.DirectionType);

        builder.HasData(new StudentUser(
            "student@h.ru",
            "$2a$11$OivsBSqdX.z5Wfi2KIJYqevBDcK4qAIqQIgP2nxslMT5Onsk5nuy.",
            true,
            "",
            "",
            "",
            "88005553535",
            false,
            "UrFU",
            "Prog",
            1,
            DirectionType.Internship)
        {
            Id = 3
        });
    }
}