using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class SolutionTypeConfiguration : IEntityTypeConfiguration<Solution>
{
    public void Configure(EntityTypeBuilder<Solution> builder)
    {
        builder.Property(x => x.Status).IsRequired();
        builder.Property(x => x.SentAtUtc).IsRequired();
        builder.Property(x => x.InspectorId).IsRequired();
        builder.Property(x => x.AuthorFullname).IsRequired();
        builder.Property(x => x.AuthorId).IsRequired();
        builder.Property(x => x.DirectionTitle).IsRequired();

        builder.OwnsMany(x => x.Answers, (navigationBuilder =>
        {
            navigationBuilder.ToTable("Answers");
            navigationBuilder.Property(x => x.Text).IsRequired();
            navigationBuilder.Property(x => x.QuestionId).IsRequired();
        }));
    }
}