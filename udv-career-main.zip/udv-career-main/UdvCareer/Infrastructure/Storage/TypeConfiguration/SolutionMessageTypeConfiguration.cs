using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class SolutionMessageTypeConfiguration : IEntityTypeConfiguration<SolutionMessage>
{

    public void Configure(EntityTypeBuilder<SolutionMessage> builder)
    {
        builder.Property(x => x.Text).HasMaxLength(500).IsRequired();
        builder.Property(x => x.IsRead).IsRequired();
        builder.Property(x => x.FromUserId).IsRequired();
        builder.Property(x => x.SolutionId).IsRequired();
        builder.Property(x => x.SentAtUtc).IsRequired();
    }
}