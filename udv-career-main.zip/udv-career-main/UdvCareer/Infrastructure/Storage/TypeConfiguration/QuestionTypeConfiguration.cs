using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class QuestionTypeConfiguration : IEntityTypeConfiguration<Question>
{
    public void Configure(EntityTypeBuilder<Question> builder)
    {
        builder.Property(x => x.Text).HasMaxLength(3000).IsRequired();
        builder.Property(x => x.DirectionId).IsRequired();

        builder.HasData(
            new Question("Вопрос 1.1", 1) { Id = 1 },
            new Question("Вопрос 1.2", 1) { Id = 2 },
            new Question("Вопрос 1.3", 1) { Id = 3 },
            new Question("Вопрос 2.1", 2) { Id = 4 }
        );
    }
}