using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class HrUserTypeConfiguration : IEntityTypeConfiguration<HrUser>
{
    public void Configure(EntityTypeBuilder<HrUser> builder)
    {
        builder.ToTable("HrUsers");

        builder.HasData(new HrUser("hr@h.ru",
            "$2a$11$OivsBSqdX.z5Wfi2KIJYqevBDcK4qAIqQIgP2nxslMT5Onsk5nuy.",
            true,
            "",
            "",
            "",
            "88005553535",
            false
        ) { Id = 1 });
    }
}