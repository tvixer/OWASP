using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Storage.TypeConfiguration;

public class DirectionTutorTypeConfiguration : IEntityTypeConfiguration<DirectionTutor>
{
    public void Configure(EntityTypeBuilder<DirectionTutor> builder)
    {
        builder.HasData(new DirectionTutor(2, 1) { Id = 1 });
    }
}