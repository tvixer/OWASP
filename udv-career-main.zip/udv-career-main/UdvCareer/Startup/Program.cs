using System.Text;
using System.Text.Json.Serialization;
using Application.Filters;
using Application.Providers;
using Application.Providers.Implementations;
using Application.Services;
using Application.Services.Implementations;
using Application.Services.TokenServices;
using Domain.Repositories;
using Ftsoft.Storage.EntityFramework;
using Infrastructure.Storage;
using Infrastructure.Storage.Repositories;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Events;

var builder = WebApplication.CreateBuilder(args);

var applicationProjectAssembly = typeof(Application.AssemblyReference).Assembly;

var careerProjectAssembly = typeof(Presentation.AssemblyReference).Assembly;

builder.Services.AddMediatR(applicationProjectAssembly);
builder.Services
    .AddControllers(x => { x.Filters.Add<AuthorizationFilter>(); })
    .AddJsonOptions(x =>
    {
        x.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        x.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    })
    .AddApplicationPart(careerProjectAssembly);


builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(opt =>
{
    opt.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidIssuer = builder.Configuration["Auth:Jwt:Issuer"],
        ValidAudience = builder.Configuration["Auth:Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(builder.Configuration["Auth:Jwt:Key"])
        ),
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = false,
        ValidateIssuerSigningKey = true,
    };
});
builder.Services.AddAuthorization();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddHttpContextAccessor();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "UdvCareer",
        Version = "v1"
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "UdvCareer API",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});


builder.Services.AddDbContext<CareerDbContext>(
    opt => { opt.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")); }
);

builder.Services.RegisterRepository<IUserRepository, UserRepository>();
builder.Services.RegisterRepository<IQuestionRepository, QuestionRepository>();
builder.Services.RegisterRepository<IStudentUserRepository, StudentUserRepository>();
builder.Services.RegisterRepository<IHrUserRepository, HrUserRepository>();
builder.Services.RegisterRepository<ITutorUserRepository, TutorUserRepository>();
builder.Services.RegisterRepository<IDirectionRepository, DirectionRepository>();
builder.Services.RegisterRepository<IDirectionTutorRepository, DirectionTutorRepository>();
builder.Services.RegisterRepository<IEnrollRepository, EnrollRepository>();
builder.Services.RegisterRepository<ISolutionRepository, SolutionRepository>();
builder.Services.RegisterRepository<IOfferRepository, OfferRepository>();
builder.Services.RegisterRepository<ISolutionMessageRepository, SolutionMessageRepository>();


builder.Services.AddScoped<ICryptService, CryptService>();
builder.Services.AddScoped<IEmailSenderService, EmailSenderService>();
builder.Services.AddScoped<IRazorRenderService, RazorRenderService>();
builder.Services.AddScoped<IUserProvider, UserProvider>();
builder.Services.AddScoped<IJwtService, JwtService>();

builder.Services.AddSingleton<IPasswordGeneratorService, PasswordGeneratorServiceService>();
builder.Services.AddSingleton<IDateProvider, DateProvider>();
builder.Services.AddSingleton<IDateService, DateService>();
builder.Services.AddSingleton<IRegisterTokenService, RegisterTokenService>();
builder.Services.AddSingleton<IResetTokenService, ResetTokenService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    // app.UseHttpsRedirection();
}

app.UseForwardedHeaders(new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();