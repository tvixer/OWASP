namespace Domain.Models;

public class SolutionMessage : BaseEntity
{
    private SolutionMessage() {}
    public SolutionMessage(long solutionId, long fromUserId, string text, bool isRead, DateTime sentAtUtc)
    {
        SolutionId = solutionId;
        FromUserId = fromUserId;
        Text = text;
        IsRead = isRead;
        SentAtUtc = sentAtUtc;
    }

    public static SolutionMessage Create(long solutionId, long fromUserId, string text, bool isRead, DateTime sentAtUtc)
    {
        return new SolutionMessage(solutionId, fromUserId, text, isRead, sentAtUtc);
    }
    
    public long SolutionId { get; set; }
    public long FromUserId { get; set; }
    public string Text { get; set; }
    public bool IsRead { get; set; }
    public DateTime SentAtUtc { get; set; }
}