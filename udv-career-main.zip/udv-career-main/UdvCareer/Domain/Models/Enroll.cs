namespace Domain.Models;

public class Enroll : BaseEntity
{
    private Enroll()
    {
    }

    public Enroll(long studentId, long tutorId, long directionId)
    {
        StudentId = studentId;
        TutorId = tutorId;
        DirectionId = directionId;
    }

    public long StudentId { get; private set; }
    public long TutorId { get; private set; }
    public long DirectionId { get; private set; }
}