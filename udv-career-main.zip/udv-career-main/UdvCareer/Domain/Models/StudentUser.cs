using Domain.Enums;

namespace Domain.Models;

public class StudentUser : BaseUser
{
    public StudentUser()
    {
    }

    public StudentUser(string email, string password, bool isConfirmed, string name, string surname, string patronymic,
        string phone, bool isBanned, string institute, string specialization, int course, DirectionType directionType) :
        base(email, password, isConfirmed, name, surname, patronymic,
            phone, isBanned)
    {
        Institute = institute;
        Specialization = specialization;
        Course = course;
        DirectionType = directionType;
        Role = UserRole.StudentNotFilled;
    }

    public string Institute { get; private set; }
    public string Specialization { get; private set; }
    public int Course { get; private set; }
    public DirectionType DirectionType { get; private set; }


    public void UpdateStudentInfo(int course,
        string institute,
        string specialization, DirectionType directionType)
    {
        Course = course;
        Institute = institute;
        Specialization = specialization;
        DirectionType = directionType;
        Role = UserRole.Student;
    }

    public string GetHumanizedDirectionType()
    {
        return DirectionType switch
        {
            DirectionType.Practice => "Практика",
            DirectionType.Internship => "Стажировка",
            _ => throw new ArgumentOutOfRangeException()
        };
    }
}