using System.Collections.ObjectModel;
using Domain.Enums;

namespace Domain.Models;

public class Solution : BaseEntity
{
    private Solution()
    {
    }

    public Solution(Collection<Answer> answers, SolutionStatus status, DateTime sentAtUtc, long authorId,
        string authorFullName, long directionId, string directionTitle, long inspectorId)
    {
        Answers = answers;
        Status = status;
        SentAtUtc = sentAtUtc;
        AuthorId = authorId;
        AuthorFullname = authorFullName;
        DirectionId = directionId;
        DirectionTitle = directionTitle;
        InspectorId = inspectorId;
    }


    public long AuthorId { get; private set; }
    public long InspectorId { get; private set; }
    public string AuthorFullname { get; private set; }
    public long DirectionId { get; private set; }
    public string DirectionTitle { get; private set; }
    public Collection<Answer> Answers { get; private set; }
    public DateTime SentAtUtc { get; private set; }
    public SolutionStatus Status { get; private set; }

    public void SetStatus(SolutionStatus status)
    {
        Status = status;
    }

    public void Update(Collection<Answer> answers, DateTime sentAt)
    {
        if (Status != SolutionStatus.OnCheck)
        {
            return;
        }

        foreach (var oldAnswer in Answers)
        {
            var newAnswers = answers.First(x => x.QuestionId == oldAnswer.QuestionId);
            oldAnswer.Text = newAnswers.Text;
            oldAnswer.QuestionText = newAnswers.QuestionText;
        }

        SentAtUtc = sentAt;
    }

    public class Answer
    {
        public Answer(string text, long questionId, string questionText)
        {
            Text = text;
            QuestionId = questionId;
            QuestionText = questionText;
        }

        public string QuestionText { get; set; }
        public string Text { get; set; }
        public long QuestionId { get; set; }
    }
}