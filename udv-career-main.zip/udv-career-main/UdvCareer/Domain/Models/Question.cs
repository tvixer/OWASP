namespace Domain.Models;

public class Question : BaseEntity
{
    private Question()
    {
    }

    public Question(string text, long directionId)
    {
        Text = text;
        DirectionId = directionId;
    }

    public void Delete(DateTime utcNow)
    {
        DeletedAtUtc = utcNow;
    }

    public string Text { get; private set; }
    public long DirectionId { get; private set; }
    public DateTime DeletedAtUtc { get; private set; }
}