using Domain.Enums;

namespace Domain.Models;

public class Direction : BaseEntity
{
    private Direction(DirectionDepartment department)
    {
        Department = department;
    }

    public Direction(string title, string description, int willBeAcceptedCount, bool isActive, DateTime endedAt,
        string taskDescription, DirectionDepartment department)
    {
        Title = title;
        WillBeAcceptedCount = willBeAcceptedCount;
        IsActive = isActive;
        Description = description;
        EndedAtUtc = endedAt;
        TaskDescription = taskDescription;
        Department = department;
    }

    public DirectionDepartment Department { get; private set; }
    public string Title { get; private set; }
    public string TaskDescription { get; private set; }
    public int WillBeAcceptedCount { get; private set; }
    public string Description { get; private set; }
    public bool IsActive { get; private set; }
    public DateTime EndedAtUtc { get; private set; }

    public void Update(string title, string description, bool isActive, DateTime endedAtUtc, int willBeAcceptedCount,
        string taskDescription, DirectionDepartment department)
    {
        Title = title;
        TaskDescription = taskDescription;
        WillBeAcceptedCount = willBeAcceptedCount;
        Description = description;
        IsActive = isActive;
        EndedAtUtc = endedAtUtc;
        Department = department;
    }
}