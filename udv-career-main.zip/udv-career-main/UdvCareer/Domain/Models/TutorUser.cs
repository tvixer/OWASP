using Domain.Enums;

namespace Domain.Models;

public class TutorUser : BaseUser
{
    
    public TutorUser(string email, string password, bool isConfirmed, string name, string surname, string patronymic,
        string phone, bool isBanned) : base(email, password, isConfirmed, name, surname, patronymic, phone, isBanned)
    {
        Role = UserRole.Tutor;
    }
}