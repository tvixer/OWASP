using Domain.Enums;

namespace Domain.Models;

public class Offer : BaseEntity
{
    public Offer(DateTime endedAtUtc, long directionId, string directionTitle, long offerCreatorId, long offerRecipientId)
    {
        EndedAtUtc = endedAtUtc;
        DirectionId = directionId;
        DirectionTitle = directionTitle;
        OfferCreatorId = offerCreatorId;
        OfferRecipientId = offerRecipientId;
        Status = OfferStatus.Requested;
    }

    public void SetStatus(OfferStatus status)
    {
        if (Status != OfferStatus.Requested)
        {
            throw new Exception("Status already accepted or rejected");
        }

        Status = status;
    }

    public DateTime EndedAtUtc { get; private set; }
    public OfferStatus Status { get; private set; }
    public long DirectionId { get; private set; }
    public string DirectionTitle { get; private set; }
    public long OfferCreatorId { get; private set; }
    public long OfferRecipientId { get; private set; }
}