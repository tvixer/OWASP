using Ftsoft.Domain;

namespace Domain.Models;

public class BaseEntity : Entity
{
    public long Id { get; set; }
}