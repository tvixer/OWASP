using Domain.Enums;

namespace Domain.Models;

public class BaseUser : BaseEntity
{
    public BaseUser()
    {
    }

    public BaseUser(string email, string password, bool isConfirmed, string name,
        string surname, string patronymic, string phone, bool isBanned)
    {
        Email = email;
        Password = password;
        IsConfirmed = isConfirmed;
        Name = name;
        Surname = surname;
        Patronymic = patronymic;
        Phone = phone;
        IsBanned = isBanned;
    }

    public UserRole Role { get; protected set; }
    public string Email { get; private set; }
    public string Password { get; private set; }
    public bool IsConfirmed { get; private set; }
    public string Name { get; protected set; }
    public string Surname { get; protected set; }
    public string Patronymic { get; protected set; }
    public string Phone { get; protected set; }
    public bool IsBanned { get; private set; }
    public string? TelegramUsername { get; private set; }
    public void UpdateAccountInfo(string name, string surname, string patronymic, string phone, string telegramUsername)
    {
        Name = name;
        Surname = surname;
        Patronymic = patronymic;
        Phone = phone;
        TelegramUsername = telegramUsername;
    }

    public void ChangePassword(string password)
    {
        Password = password;
    }

    public string GetFullname()
    {
        return $"{Name} {Patronymic} {Surname}";
    }

    public void Ban()
    {
        IsBanned = true;
    }

    public void Unban()
    {
        IsBanned = false;
    }

    public void Confirm()
    {
        IsConfirmed = true;
    }
}