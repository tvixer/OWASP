namespace Domain.Models;

public class DirectionTutor : BaseEntity
{
    private DirectionTutor() {}
    
    public DirectionTutor(long tutorId, long directionId)
    {
        TutorId = tutorId;
        DirectionId = directionId;
    }

    public long TutorId { get; private set; }
    public long DirectionId { get; private set; }
}