using Ftsoft.Storage;
using Solution = Domain.Models.Solution;

namespace Domain.Repositories;

public interface ISolutionRepository : IRepository<Solution>
{
}