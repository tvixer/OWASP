using Ftsoft.Storage;
using Direction = Domain.Models.Direction;

namespace Domain.Repositories;

public interface IDirectionRepository : IRepository<Direction>
{
    
}