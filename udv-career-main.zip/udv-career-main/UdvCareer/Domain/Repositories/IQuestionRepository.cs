using Domain.Models;
using Ftsoft.Storage;

namespace Domain.Repositories;

public interface IQuestionRepository : IRepository<Question>
{
    
}