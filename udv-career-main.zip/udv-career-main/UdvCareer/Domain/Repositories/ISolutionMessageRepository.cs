using Domain.Models;
using Ftsoft.Storage;

namespace Domain.Repositories;

public interface ISolutionMessageRepository : IRepository<SolutionMessage>
{
    
}