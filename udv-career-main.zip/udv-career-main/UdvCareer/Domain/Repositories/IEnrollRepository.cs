using Domain.Models;
using Ftsoft.Storage;

namespace Domain.Repositories;

public interface IEnrollRepository : IRepository<Enroll>
{
}