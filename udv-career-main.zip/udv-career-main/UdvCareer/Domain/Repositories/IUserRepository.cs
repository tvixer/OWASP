using Domain.Models;
using Ftsoft.Storage;

namespace Domain.Repositories;

public interface IUserRepository : IRepository<BaseUser>
{
    
}