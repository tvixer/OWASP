﻿namespace Domain.Enums;

public enum DirectionDepartment
{
    UDV = 0,
    USSC = 1,
}