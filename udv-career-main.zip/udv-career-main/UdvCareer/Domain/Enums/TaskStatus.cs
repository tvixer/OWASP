namespace Domain.Enums;

public enum TaskStatus
{
    OnInspection,
    Accepted,
    Rejected
}