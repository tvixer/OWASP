namespace Domain.Enums;

public enum DirectionType
{
    Practice = 0,
    Internship = 1
}