namespace Domain.Enums;

public enum UserRole
{
    Student = 0,
    Tutor = 1,
    Hr = 2,
    StudentNotFilled = 3
}