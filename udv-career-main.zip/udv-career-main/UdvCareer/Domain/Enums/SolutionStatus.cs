namespace Domain.Enums;

public enum SolutionStatus
{
    OnCheck = 0,
    Approved = 1,
    Rejected = 2,
}