namespace Domain.Enums;

public enum OfferStatus
{
    Requested,
    Accepted,
    Declined
}