import moment from 'moment';
import { decodeToken } from 'react-jwt';

export const LIMIT_ON_PAGE = 20;
export const RESET_PASS_PAGE_PATH = 'restore-pass';
export const AUTH_PAGE_PATH = 'auth';

class Utils {
  /**
   * Создает ссылку на страницу внутри приложения.
   * @param relativeUrl адрес раздела
   */
  public createUrl(relativeUrl: string) {
    return `${window.origin}/${relativeUrl}`;
  }

  public validateEmail(value: string) {
    return /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/.test(value);
  }
  public getId() {
    const token = decodeToken(localStorage['authToken']) as any;
    return token.sub;
  }
  public formatDate(dateStr: number) {
    return moment(dateStr).format('DD.MM.YY HH:MM');
  }

  public ellipses(str: string, length: number) {
    return str.length > length ? `${str.trim().slice(0, length)}...` : str;
  }

  public getCountPage(total: number) {
    return Math.ceil(total / LIMIT_ON_PAGE);
  }
}

export const utils = new Utils();
