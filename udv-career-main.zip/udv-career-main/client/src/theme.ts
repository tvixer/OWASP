import { createTheme } from '@mui/material';

const BORDER_RADIUS = 25;

export const theme = createTheme({
  breakpoints: {
    values: {
      xs: 0,
      sm: 480,
      md: 750,
      lg: 950,
      xl: 1122,
    },
  },
  palette: {
    primary: {
      main: '#EF7F1A',
    },
    secondary: {
      main: '#808080',
    },
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundColor: '#C5C5C5',
          borderRadius: 25,
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          width: '100%',
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: BORDER_RADIUS,
          backgroundColor: '#fff',
          minHeight: 50,
          paddingLeft: 5,
        },
      },
    },
    MuiFilledInput: {
      styleOverrides: {
        root: {
          minHeight: 42,
          backgroundColor: '#CCCCCC',
          borderRadius: BORDER_RADIUS,
          borderBottom: 'none',
          '&:before, :after, :hover:not(.Mui-disabled):before': {
            borderBottom: 0,
          },
          '&.MuiInputBase-multiline': {
            paddingBottom: 20,
            paddingLeft: 20,
          },
        },
        input: {
          paddingTop: 0,
          paddingBottom: 0,
        },
      },
    },
    MuiPagination: {
      styleOverrides: {
        root: {
          paddingTop: 20,
          borderTop: '1px solid #ADADAD;',
        },
      },
    },
    MuiPaginationItem: {
      styleOverrides: {
        root: {
          color: 'white',
          backgroundColor: '#808080',
          borderRadius: '50%',
          height: 50,
          minWidth: 50,
          '&.MuiPaginationItem-ellipsis': {
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          },
          '&.Mui-selected': {
            backgroundColor: '#EF7F1A',
          },
        },
      },
    },
    MuiLink: {
      styleOverrides: {
        root: {
          fontSize: 17,
          textDecorationColor: '#FFFFFF',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: 'white',
          borderRadius: 0,
          boxShadow: 'none',
        },
      },
    },
    MuiTypography: {
      styleOverrides: {
        root: {},
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: BORDER_RADIUS,
          height: 45,
          textTransform: 'none',
          color: '#fff',
          fontSize: '1rem',
        },
      },
    },
    MuiFormLabel: {
      styleOverrides: {
        root: {
          color: '#6F6F6F',
          top: '2px !important',
          '&.MuiInputLabel-shrink': {
            top: '0px !important',
          },
        },
      },
    },
  },
  typography: {
    fontFamily: 'Inter, sans-serif',
    fontWeightMedium: 300,
    h1: {
      fontWeight: 500,
      fontSize: 100,
      lineHeight: '100px',
      color: '#2B2A29',
    },
    h3: {
      color: '#2B2A29',
      fontWeight: 700,
    },
    h4: {
      fontWeight: 500,
    },
    h5: {
      fontWeight: 500,
    },
    //for <a>
    body1: {
      color: '#fff',
      fontSize: 17,
      lineHeight: '21px',
    },
    body2: {
      color: '#2B2A29',
      fontSize: 17,
      lineHeight: '21px',
    },
    //for error
    subtitle2: {
      color: '#e84040',
      fontSize: 17,
      lineHeight: '21px',
    },
    //for succes message
    subtitle1: {
      color: '#30962c',
      fontSize: 17,
      lineHeight: '21px',
    },
  },
});
