import { SolutionStatus } from './solutionsTypes';

export interface IDirectionData {
  studentIsEnrolled: boolean;
  availablePlaces: number;
  title: string;
  id: number;
  description: string;
  finishAcceptingAt: number;
  status: SolutionStatus;
  isActive: boolean;
  solutionId?: number;
  department: Department;
}

export enum Department {
  USSC = 'USSC',
  UDV = 'UDV',
}

export interface IDirectionsResponse {
  items: IDirectionData[];
  total: number;
}

export interface ICreateDirectionData {
  title: string;
  description: string;
  willBeAcceptedCount: number;
  isActive: boolean;
  endedAt?: number;
  questions: string[];
  taskDescription: string;
  department: Department;
}

export interface IUpdateDirectionData {
  title: string;
  description: string;
  willBeAcceptedCount: number;
  isActive: boolean;
  finishingAcceptingAt?: number;
  questions: { text: string }[];
  taskDescription: string;
  department: Department;
}

export interface IQuestion {
  id: number;
  text: string;
}

export interface IQuestionResponse {
  taskDescription: string;
  questions: IQuestion[];
}
export interface IStudentResponse {
  items: IStudentData[];
  total: number;
}

export interface IStudentData {
  directionType: string;
  institute: string;
  name: string;
  patronymic: string;
  phone: string;
  specialization: string;
  surname: string;
  id: number;
  isBanned: boolean;
  course: number;
}
