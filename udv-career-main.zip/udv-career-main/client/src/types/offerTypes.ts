export interface IOffer {
  id: number;
  directionTitle: string;
  status: OfferStatus;
  endedAt: number;
}

export type OfferStatus = 'Requested' | 'Accepted' | 'Declined';
