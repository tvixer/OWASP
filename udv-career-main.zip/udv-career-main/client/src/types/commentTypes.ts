export interface IComment {
  id: number;
  fromUserId: number;
  text: string;
  sentAtUtc: number;
}
