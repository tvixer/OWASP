export interface IStudent {
  name: string;
  surname: string;
  patronymic: string;
  phone: string;
  telegramUsername: string;
  studentInfo: {
    course: string;
    institute: string;
    specialization: string;
    directionType: string;
  };
}
export interface IUpdateStudentProfile {
  name: string;
  surname: string;
  patronymic: string;
  phone: string;
  telegramUsername: string;
  studentInfo: {
    course: number;
    institute: string;
    specialization: string;
    directionType: string;
  };
}

export interface IHRTutorData {
  name: string;
  surname: string;
  patronymic: string;
  phone: string;
  email: string;
  telegramUsername: string;
}

export interface IUserData {
  id: number;
  email: string;
  isBanned: boolean;
  isConfirmed: boolean;
  name: string;
  patronymic: string;
  phone: string;
  role: string;
  surname: string;
}

export interface IUserResponse {
  items: IUserData[];
  total: number;
}
