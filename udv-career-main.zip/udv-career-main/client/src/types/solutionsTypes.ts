export interface ISolutionsRequest {
  directionId: string;
  answers: IAnswer[];
}

export interface IAnswer {
  questionId: number;
  text: string;
}

export interface ISolutionDataResponse {
  items: ISolutionData[];
  total: number;
}

export interface ISolutionData {
  id: number;
  status: string;
  studentFullname: string;
  sentAt: number;
  studentId: number;
  directionId: string;
}
export type SolutionStatus = 'NotStarted' | 'Approved' | 'Rejected' | 'OnCheck';

export interface ISolutionDetailedData {
  answers: IAnswerWithQuestion[];
  sentAt: number;
  status: SolutionStatus;
  availablePlaces: number;
  student: IUser;
  tutor: IUser;
}

export interface IUser {
  id: number;
  fullname: string;
}

export interface IAnswerWithQuestion extends IAnswer {
  questionText: string;
}

export interface IVerdict {
  status: SolutionStatus;
  message: string;
}
