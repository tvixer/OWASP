declare module '*.scss';
declare module '*.png';
declare module '*.jpg';
declare module '*.svg';
