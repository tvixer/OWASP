export type FieldType = {
  value: string;
  error?: string;
};
