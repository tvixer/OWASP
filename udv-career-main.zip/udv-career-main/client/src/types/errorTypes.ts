export interface IError {
  type: ErrorEnum;
  data: any;
}

export enum ErrorEnum {
  'Auth.AccountExistsError' = 'Пользователь с такой почтой уже существует',
  'Auth.EmailVerificationError' = 'Ошибка верификации почты',
  'Auth.InvalidCredentialsError' = 'Логин или пароль введены неверно',
  'Auth.NotConfirmedError' = 'Аккаунт не подтвержден',
  'User.NotFoundError' = 'Неверный логин или пароль',
  'Offer.AlreadyAcceptedOrRejectedError' = 'Решение уже было принято',
  'Offer.ExpiredError' = 'Приглашение просрочено',
  'Offer.NotFoundError' = 'Приглашение не найдено',
  'Offer.NotOfferRecipientError' = 'Набор на направление закрыт',
  'Offer.NotStudentError' = 'Не найден студент',
  'Solution.AcceptingEndedError' = 'Срок сдачи тествого прошёл',
  'Solution.NotAuthorError' = 'Автор решения забанен',
  'Solution.NotFoundError' = 'Не найдено',
  'Solution.WasCheckedError' = 'Уже было проверено',
}
