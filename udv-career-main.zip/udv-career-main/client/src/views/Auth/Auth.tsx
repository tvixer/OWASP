import { Button, Link, Stack, TextField, Typography } from '@mui/material';
import { observer } from 'mobx-react';
import React, { FC, useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { utils } from '../../common/utils';
import { PasswordField } from '../../components/PasswordField/PasswordField';
import { LoginCard } from '../../containers/LoginCard/LoginCard';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import { FieldType } from '../../types/common';

const Auth: FC = () => {
  const [login, setLogin] = useState<FieldType>({
    value: '',
    error: '',
  });
  const [pass, setPass] = useState<FieldType>({ value: '', error: '' });
  const [valid, setValid] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);

  const submit = async () => {
    try {
      await authStore.login(login.value, pass.value);
      navigate('/');
    } catch (e) {
      if (typeof e === 'string') {
        setError(e as string);
      }
      console.error(e);
    }
  };

  useEffect(() => {
    if (!utils.validateEmail(login.value) || pass.value.length < 3) {
      setValid(false);
    } else {
      setValid(true);
    }
  }, [login.value, pass.value]);

  return (
    <LoginCard title={'Вход'}>
      <form
        onSubmit={(e) => {
          submit();
          e.preventDefault();
        }}
        onKeyUp={(event) => event.key === 'Enter' && submit()}
      >
        <Stack spacing={3}>
          <TextField
            placeholder={'E-mail'}
            type={'email'}
            autoComplete={'email'}
            value={login.value}
            error={!!login.error}
            helperText={login.error}
            onChange={(event) => {
              setError('');
              setLogin({ value: event.target.value, error: '' });
            }}
            onBlur={() => {
              if (!utils.validateEmail(login.value)) {
                setLogin({ value: login.value, error: 'Проверьте email' });
              }
            }}
          />
          <PasswordField
            autoComplete={'current-password'}
            value={pass.value}
            onChange={(event) => {
              setError('');
              setPass({ value: event.target.value, error: '' });
            }}
            placeholder={'Пароль'}
          />
          <Link
            href={utils.createUrl('offer-restore-pass')}
            style={{ fontSize: 20, textAlign: 'left', color: '#fff' }}
          >
            Не помню пароль
          </Link>
          <Button variant={'contained'} disabled={!valid} onClick={submit}>
            Войти
          </Button>
          {error && <Typography variant={'subtitle2'}>{error}</Typography>}
        </Stack>
      </form>
      <Link
        href={utils.createUrl('registration')}
        style={{
          marginTop: 36,
          textAlign: 'center',
          fontSize: 20,
          color: '#fff',
        }}
      >
        Зарегистрироваться
      </Link>
    </LoginCard>
  );
};

export default observer(Auth);
