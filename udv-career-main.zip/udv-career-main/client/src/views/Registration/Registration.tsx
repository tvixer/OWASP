import CircleIcon from '@mui/icons-material/Circle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import {
  Button,
  Checkbox,
  FormControlLabel,
  Link,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import React, { FC, useEffect, useState } from 'react';

import { accountApi } from '../../api/accountAPI';
import { utils } from '../../common/utils';
import { PasswordField } from '../../components/PasswordField/PasswordField';
import { LoginCard } from '../../containers/LoginCard/LoginCard';
import { FieldType } from '../../types/common';

type StateReg = 'default' | 'success' | 'error';

const Registration: FC = () => {
  const [login, setLogin] = useState<FieldType>({ value: '', error: '' });
  const [password, setPassword] = useState<FieldType>({ value: '', error: '' });
  const [repeatPassword, setRepeatPassword] = useState<FieldType>({
    value: '',
    error: '',
  });
  const [confirmPersonalData, setConfirmPersonalData] = useState(false);
  const [isValid, setIsValid] = useState(false);
  const [stateReg, setStateReg] = useState<StateReg>('default');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true);
    try {
      await accountApi.registerStudent(login.value, password.value);
      setStateReg('success');
    } catch (e) {
      setStateReg('error');
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  //Проверка на валидность
  useEffect(() => {
    let currentValid = true;
    if (
      [login, password, repeatPassword].filter(
        (value) => value.value.length === 0 || value.error !== ''
      ).length !== 0 ||
      !confirmPersonalData
    ) {
      currentValid = false;
    }
    setIsValid(currentValid);
  }, [login, confirmPersonalData, password, repeatPassword]);

  return (
    <LoginCard title={'Регистрация'}>
      {stateReg === 'default' && (
        <form
          onSubmit={(e) => {
            submit();
            e.preventDefault();
          }}
        >
          <Stack spacing={3}>
            <TextField
              type={'email'}
              autoComplete={'email'}
              onBlur={() => {
                if (!utils.validateEmail(login.value)) {
                  setLogin({
                    value: login.value,
                    error: 'Неправильный email',
                  });
                }
              }}
              value={login.value}
              onChange={(event) => {
                setLogin({ value: event.target.value, error: '' });
              }}
              error={!!login.error}
              helperText={login.error}
              placeholder={'E-mail'}
            />
            <PasswordField
              name="new-password"
              value={password.value}
              autoComplete={'new-password'}
              onChange={(event) => {
                setPassword({ value: event.target.value, error: '' });
              }}
              placeholder={'Пароль'}
            />
            <PasswordField
              tabIndex={3}
              value={repeatPassword.value}
              error={!!repeatPassword.error}
              helperText={repeatPassword.error}
              onChange={(event) => {
                setRepeatPassword({
                  value: event.target.value,
                  error:
                    event.target.value !== password.value
                      ? 'Пароли не совпадают'
                      : '',
                });
              }}
              placeholder={'Повторите пароль'}
            />
            <FormControlLabel
              control={
                <Checkbox
                  onChange={(event) =>
                    setConfirmPersonalData(event.target.checked)
                  }
                  icon={<RadioButtonUncheckedIcon />}
                  checkedIcon={<CircleIcon />}
                />
              }
              label={
                <Typography variant={'body1'}>
                  я соглашаюсь на{' '}
                  <Link href="https://www.youtube.com/watch?v=6eRNLHgvUt0">
                    обработку персональных данных
                  </Link>
                </Typography>
              }
            />
            <Button
              variant={'contained'}
              onClick={submit}
              disabled={!isValid || loading}
              type={'submit'}
            >
              Зарегистрироваться
            </Button>
            <Typography textAlign={'center'}>
              У вас уже есть профиль?{' '}
              <Link href={utils.createUrl('auth')} style={{ color: '#fff' }}>
                Войдите
              </Link>
            </Typography>
          </Stack>
        </form>
      )}
      {stateReg === 'success' && (
        <Stack spacing={2}>
          <Typography
            variant={'h4'}
            color={'#fff'}
            fontWeight={300}
            fontSize={'1.3rem'}
            textAlign={'center'}
          >
            Вы успешно зарегистрированы
          </Typography>
          <Typography
            variant={'body1'}
            fontSize={'1.2rem'}
            lineHeight={1.1}
            fontWeight={400}
            textAlign={'center'}
            paddingBottom={5}
          >
            На вашу почту была отправлена инструкция для подтверждения
          </Typography>
        </Stack>
      )}
      {stateReg === 'error' && (
        <Stack spacing={3}>
          <Typography
            variant={'h4'}
            color={'#fff'}
            fontWeight={300}
            textAlign={'center'}
          >
            Произошла ошибка регистрации
          </Typography>
          <Typography
            variant={'body1'}
            fontSize={30}
            lineHeight={'36px'}
            fontWeight={400}
            textAlign={'center'}
            paddingBottom={5}
          >
            Попробуйте снова позже
          </Typography>
        </Stack>
      )}
    </LoginCard>
  );
};

export default Registration;
