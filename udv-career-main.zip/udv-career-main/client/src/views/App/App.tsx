import { observer } from 'mobx-react';
import React, { FC, useContext } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';

import { Header } from '../../components/Header/Header';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import { CheckSolutionPage } from '../../pages/CheckSolutionPage/CheckSolutionPage';
import { DirectionPage } from '../../pages/DirectionPage/DirectionPage';
import { DirectionsPalettePage } from '../../pages/DirectionsPalettePage/DirectionsPalettePage';
import { EditCreateDirectionPage } from '../../pages/EditCreateDirectionPage/EditCreateDirectionPage';
import { EmployersListPage } from '../../pages/EmployersListPage/EmployersListPage';
import { OffersPage } from '../../pages/OffersPage/OffersPage';
import { ProfilePage } from '../../pages/ProfilePage/ProfilePage';
import { SolutionsListPage } from '../../pages/SolutionsListPage/SolutionsListPage';
import { StudentDirectionsPage } from '../../pages/StudentDirectionsPage/StudentDirectionsPage';
import { StudentsListPage } from '../../pages/StudentsListPage/StudentsListPage';
import { TutorDirectionsPage } from '../../pages/TutorDirectionsPage/TutorDirectionsPage';
import { Department } from '../../types/directionTypes';
import classes from './styles.module.scss';

const App: FC = () => {
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);

  const generalRoute = () => {
    return (
      <>
        <Route path={'direction/:directionId'} element={<DirectionPage />} />
        <Route path={'profile/*'} element={<ProfilePage />} />
        <Route path={':department'} element={<DirectionsPalettePage />} />
        <Route
          path={'/*'}
          element={<Navigate to={`/${Department.USSC}`} replace />}
        />
      </>
    );
  };

  const hrRoutes = () => {
    return (
      <>
        <Route
          path={'direction/create'}
          element={<EditCreateDirectionPage />}
        />
        <Route
          path={'direction/edit/:directionId'}
          element={<EditCreateDirectionPage changing />}
        />
        <Route path={'students/*'} element={<StudentsListPage />} />
        <Route path={'/hrAndTutors/*'} element={<EmployersListPage />} />
      </>
    );
  };

  const tutorsRoutes = () => {
    return (
      <>
        <Route path={'solutions/*'} element={<SolutionsListPage />} />
        <Route path={'myDirections'} element={<TutorDirectionsPage />} />
        <Route
          path={'checkSolution/:solutionId'}
          element={<CheckSolutionPage />}
        />
      </>
    );
  };

  const studentRoutes = () => {
    return (
      <>
        <Route path={'offers'} element={<OffersPage />} />
        <Route path={'myDirections'} element={<StudentDirectionsPage />} />
      </>
    );
  };
  return (
    <div className={classes.root}>
      <>
        <Header />
        <Routes>
          {authStore.role === 'Hr' && hrRoutes()}
          {authStore.role === 'Tutor' && tutorsRoutes()}
          {(authStore.role === 'Student' ||
            authStore.role === 'StudentNotFilled') &&
            studentRoutes()}
          {generalRoute()}
        </Routes>
      </>
    </div>
  );
};

export default observer(App);
