import { Button, Link, Stack, TextField, Typography } from '@mui/material';
import React, { useState } from 'react';

import { accountApi } from '../../api/accountAPI';
import { RESET_PASS_PAGE_PATH, utils } from '../../common/utils';
import { LoginCard } from '../../containers/LoginCard/LoginCard';
import { FieldType } from '../../types/common';

const OfferRestorePass = () => {
  const [login, setLogin] = useState<FieldType>({
    value: '',
    error: '',
  });
  const [sentOffer, setSentOffer] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    setLoading(true);
    try {
      setError('');
      await accountApi.offerToRestorePassword(
        login.value,
        RESET_PASS_PAGE_PATH
      );
      setSentOffer(true);
    } catch (e) {
      console.error(e);
      setError('Произошла ошибка');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LoginCard title={'Восстановление пароля'}>
      <Stack spacing={3}>
        {!sentOffer ? (
          <>
            <TextField
              placeholder={'E-mail'}
              type={'email'}
              autoComplete={'email'}
              value={login.value}
              error={!!login.error}
              helperText={login.error}
              onChange={(event) => {
                setError('');
                setLogin({ value: event.target.value, error: '' });
              }}
              onBlur={() => {
                if (!utils.validateEmail(login.value)) {
                  setLogin({ value: login.value, error: 'Проверьте email' });
                }
              }}
            />
            <Button
              variant={'contained'}
              disabled={!!login.error || loading}
              onClick={submit}
            >
              Восстановить
            </Button>
          </>
        ) : (
          <Typography
            variant={'body1'}
            fontSize={30}
            lineHeight={'36px'}
            fontWeight={400}
            textAlign={'center'}
            paddingBottom={5}
          >
            На вашу почту была отправлена инструкция для восстановления пароля
          </Typography>
        )}
        {error && <Typography variant={'subtitle2'}>{error}</Typography>}
      </Stack>
      <Typography
        textAlign={'center'}
        style={{
          marginTop: 40,
          textAlign: 'center',
          fontSize: 17,
          color: '#fff',
        }}
      >
        У вас уже есть профиль?{' '}
        <Link href={utils.createUrl('auth')} style={{ color: '#fff' }}>
          Войдите
        </Link>
      </Typography>
    </LoginCard>
  );
};

export default OfferRestorePass;
