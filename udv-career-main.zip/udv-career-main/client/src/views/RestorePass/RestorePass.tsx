import { Button, Link, Stack, Typography } from '@mui/material';
import React, { useState } from 'react';

import { accountApi } from '../../api/accountAPI';
import { utils } from '../../common/utils';
import { PasswordField } from '../../components/PasswordField/PasswordField';
import { LoginCard } from '../../containers/LoginCard/LoginCard';
import { FieldType } from '../../types/common';

const RestorePass = () => {
  const [password, setPassword] = useState<FieldType>({ value: '', error: '' });
  const [repeatPassword, setRepeatPassword] = useState<FieldType>({
    value: '',
    error: '',
  });
  const [restored, setRestored] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    try {
      setError('');
      const token = new URLSearchParams(location.search).get('token');
      await accountApi.restorePass(token, password.value);
      setRestored(true);
    } catch (e) {
      console.error(e);
      setError('Произошла ошибка');
    }
  };

  return (
    <LoginCard title={'Восстановление пароля'}>
      <Stack spacing={3}>
        {!restored ? (
          <>
            <PasswordField
              name="new-password"
              value={password.value}
              autoComplete={'new-password'}
              onChange={(event) => {
                setPassword({ value: event.target.value, error: '' });
              }}
              placeholder={'Новый пароль'}
            />
            <PasswordField
              value={repeatPassword.value}
              error={!!repeatPassword.error}
              helperText={repeatPassword.error}
              onChange={(event) => {
                setRepeatPassword({
                  value: event.target.value,
                  error:
                    event.target.value !== password.value
                      ? 'Пароли не совпадают'
                      : '',
                });
              }}
              placeholder={'Повторить новый пароль'}
            />
            <Button
              variant={'contained'}
              disabled={!!password.error || !!repeatPassword.error}
              onClick={submit}
            >
              Подтвердить
            </Button>
          </>
        ) : (
          <Typography
            variant={'body1'}
            fontSize={'1.3rem'}
            fontWeight={400}
            lineHeight={1.2}
            textAlign={'center'}
          >
            Пароль успешно изменен! <br />
            Теперь вы можете{' '}
            <Link
              href={utils.createUrl('auth')}
              style={{ color: '#fff', fontSize: '1.3rem' }}
            >
              войти
            </Link>
          </Typography>
        )}
        {error && <Typography variant={'subtitle2'}>{error}</Typography>}
      </Stack>
    </LoginCard>
  );
};

export default RestorePass;
