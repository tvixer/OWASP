import SendIcon from '@mui/icons-material/Send';
import { Box, TextField } from '@mui/material';
import { FC, useEffect, useRef, useState } from 'react';

import { solutionApi } from '../../api/solutionAPI';
import { IComment } from '../../types/commentTypes';
import { IUser } from '../../types/solutionsTypes';
import { Comment } from '../Comment/Comment';
import classes from './styles.module.scss';

interface CommentsBlockProps {
  firstUser: IUser;
  secondUser: IUser;
  solutionId: string;
}

export const CommentsBlock: FC<CommentsBlockProps> = ({
  secondUser,
  firstUser,
  solutionId,
}) => {
  const [textInput, setTextInput] = useState('');
  const [comments, setComments] = useState<IComment[]>([]);
  const intervalRef = useRef<NodeJS.Timer | null>(null);
  const commentListRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    getComments();
    intervalRef.current = setInterval(() => getComments(), 10000);
    return () => {
      intervalRef.current && clearInterval(intervalRef.current);
    };
  }, []);

  useEffect(() => {
    const list = commentListRef.current;
    if (list) {
      list.scrollTo({
        top: list.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [comments]);

  const getComments = async () => {
    setComments(await solutionApi.getComments(solutionId));
  };

  const sendComment = async () => {
    if (textInput.trim().length === 0) return;
    await solutionApi.sendComment(solutionId, textInput.trim());
    setComments(await solutionApi.getComments(solutionId));
    setTextInput('');
  };

  return (
    <Box className={classes.container}>
      <div>
        <div className={classes.title}>Комментарии</div>
        <Box className={classes.commentList} ref={commentListRef}>
          {comments.length &&
            comments.map((comment) =>
              comment.fromUserId === firstUser.id ? (
                <Comment
                  author={firstUser.fullname}
                  text={comment.text}
                  side={'right'}
                  key={comment.id}
                />
              ) : (
                <Comment
                  author={secondUser.fullname}
                  text={comment.text}
                  side={'left'}
                  key={comment.id}
                />
              )
            )}
        </Box>
      </div>
      <div className={classes.inputContainer}>
        <TextField
          multiline
          variant={'standard'}
          className={classes.input}
          value={textInput}
          placeholder={'Напишите сообщение...'}
          onChange={(event) => {
            console.log(event.target.value);
            setTextInput(event.target.value);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              sendComment();
              e.preventDefault();
            }
          }}
        />
        <button onClick={() => sendComment()}>
          <SendIcon color={'secondary'} />
        </button>
      </div>
    </Box>
  );
};
