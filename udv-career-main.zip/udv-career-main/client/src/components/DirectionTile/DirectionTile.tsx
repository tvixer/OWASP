import { Button, Stack, Typography } from '@mui/material';
import { observer } from 'mobx-react';
import React, { CSSProperties, FC, useContext } from 'react';
import { useNavigate } from 'react-router-dom';

import { utils } from '../../common/utils';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import { Department } from '../../types/directionTypes';
import { ReactComponent as UDV } from './img/UDV.svg';
import USSCImage from './img/USSC.png';
import classes from './styles.module.scss';

interface DirectionTileProps {
  description: string;
  title: string;
  id: number;
  availablePlaces: number;
  isActive: boolean;
  style?: CSSProperties;
  department: Department;
}
const DirectionTile: FC<DirectionTileProps> = ({
  description,
  title,
  id,
  availablePlaces,
  isActive,
  style,
  department,
}) => {
  const navigate = useNavigate();
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);

  return (
    <Stack
      justifyContent={'space-between'}
      className={classes.container}
      sx={{
        backgroundColor: department === Department.USSC ? '#f3f3f3' : '#494949',
      }}
      onClick={() => {
        navigate(`/direction/${id}`);
      }}
      style={style}
    >
      <Stack
        justifyContent={'space-between'}
        height={'100%'}
        maxHeight={'320px'}
      >
        <Stack justifyContent={'space-between'} spacing={1}>
          <Typography
            variant={'h5'}
            fontSize={'1.3rem'}
            color={department === Department.USSC ? '#2B2A29' : '#fff'}
          >
            {utils.ellipses(title, 18)}
          </Typography>
          <Typography
            variant={'body2'}
            sx={{ fontSize: 16 }}
            color={department === Department.USSC ? '#6F6F6F' : '#fff'}
          >
            {utils.ellipses(description, 50)}
          </Typography>
        </Stack>
        <Stack
          direction={'row'}
          gap={2}
          alignItems={'center'}
          justifyContent={'space-between'}
          marginBottom={2}
          color={department === Department.USSC ? '#2B2A29' : '#fff'}
        >
          <div>
            <div className={classes.count}>
              {availablePlaces} <p>мест</p>
            </div>
          </div>
          <Stack>
            {department === Department.USSC ? (
              <img src={USSCImage} alt={'Лого УЦСБ'} />
            ) : (
              <UDV />
            )}
            {authStore.role === 'Hr' && (
              <Typography
                color={isActive ? '#329D00' : '#D61212'}
                lineHeight={'28px'}
              >
                {isActive ? 'Активно' : 'Не активно'}
              </Typography>
            )}
          </Stack>
        </Stack>
      </Stack>
      <Button
        variant={'contained'}
        sx={{
          backgroundColor:
            department === Department.USSC ? 'primary' : '#734280',
        }}
      >
        Открыть
      </Button>
    </Stack>
  );
};
const DirectionTileWrapped = observer(DirectionTile);
export { DirectionTileWrapped as DirectionTile };
