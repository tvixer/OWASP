import {
  Box,
  Button,
  Snackbar,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import Grid2 from '@mui/material/Unstable_Grid2';
import { AxiosError, isAxiosError } from 'axios';
import clsx from 'clsx';
import { observer } from 'mobx-react';
import moment from 'moment';
import React, {
  FC,
  Fragment,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { Link } from 'react-router-dom';

import { offerApi } from '../../api/offerAPI';
import { utils } from '../../common/utils';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import { IOffer, OfferStatus } from '../../types/offerTypes';
import classes from './styles.module.scss';

const OffersList: FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [offers, setOffers] = useState<IOffer[]>([]);
  const [error, setError] = useState('');
  const headers = useMemo(
    () => ['Направление', 'Статус', 'Сделать выбор до'],
    []
  );
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);
  const countColumns = 8;

  useEffect(() => {
    requestOffers();
  }, []);

  const requestOffers = async () => {
    try {
      await setOffers(await offerApi.getOffers(utils.getId()));
    } catch (e) {
      if (typeof e === 'string') {
        setError(e as string);
      } else {
        if (isAxiosError(e)) {
          const error: AxiosError = e;
          if (error.response?.status !== 403) {
            setError('Произошла неизвестная ошибка');
          }
        }
      }
    }
  };

  const renderHeader = useCallback(() => {
    return (
      <>
        {headers.map((header) => {
          return (
            <Grid2
              className={clsx(classes.header, classes.item)}
              xs={2}
              key={header}
            >
              {header}
            </Grid2>
          );
        })}
        <Grid2 xs={2} className={clsx(classes.header, classes.item)}></Grid2>
      </>
    );
  }, [headers]);

  const getStatus = (offer: IOffer) => {
    if (isAfter(offer.endedAt)) return 'Просрочено';
    if (
      offers.find((ofr) => ofr.status === 'Accepted') &&
      offer.status !== 'Accepted'
    )
      return 'Отклонено';
    switch (offer.status) {
      case 'Accepted':
        return 'Принято';
      case 'Declined':
        return 'Отклонено';
      case 'Requested':
      default:
        return 'Ожидает решения';
    }
  };

  const isAfter = (date: number) => moment().utc().isAfter(moment(date));

  const sendResponseToOffer = async (offerId: number, status: OfferStatus) => {
    try {
      await offerApi.sendResponseToOffer(offerId, status);
      await requestOffers();
    } catch (e) {
      typeof e === 'string'
        ? setError(e as string)
        : setError('Произошла неизвестная ошибка');
    }
  };

  const isDisabledButton = useCallback(
    (offer: IOffer): boolean => {
      return (
        offer.status !== 'Requested' ||
        !!offers.find((ofr) => ofr.status === 'Accepted') ||
        moment().utc().isAfter(moment(offer.endedAt))
      );
    },
    [offers]
  );

  const renderItems = useCallback(
    (offer: IOffer) => {
      return (
        <Fragment key={offer.id}>
          <Grid2 className={classes.item} xs={2}>
            {utils.ellipses(offer.directionTitle, 17)}
          </Grid2>
          <Grid2
            className={classes.item}
            xs={2}
            color={
              getStatus(offer) === 'Принято'
                ? '#329D00'
                : ['Просрочено', 'Отклонено'].includes(getStatus(offer))
                ? '#D61212'
                : 'inherit'
            }
          >
            {getStatus(offer)}
          </Grid2>
          <Grid2
            className={classes.item}
            xs={1}
            color={isAfter(offer.endedAt) ? '#D61212' : 'primary'}
          >
            {utils.formatDate(offer.endedAt)}
          </Grid2>
          <Grid2 xs={3} className={classes.item}>
            <Button
              sx={{
                marginLeft: 'auto',
                maxWidth: 140,
                height: 32,
                marginRight: 1,
              }}
              fullWidth
              variant={'contained'}
              disabled={isDisabledButton(offer)}
              className={classes.button}
              onClick={() => sendResponseToOffer(offer.id, 'Accepted')}
            >
              Принять
            </Button>
            <Button
              sx={{ maxWidth: 140, height: 32 }}
              color={'secondary'}
              fullWidth
              disabled={isDisabledButton(offer)}
              variant={'contained'}
              className={classes.button}
              onClick={() => sendResponseToOffer(offer.id, 'Declined')}
            >
              Отклонить
            </Button>
          </Grid2>
        </Fragment>
      );
    },
    [offers]
  );

  const renderItemOnMobile = (offer: IOffer) => {
    return (
      <Box className={classes.mobile} key={offer.id}>
        <div className={classes.mobile__title}>{offer.directionTitle}</div>
        <div className={classes.mobile__column_container}>
          <div className={classes.mobile__column}>
            <div className={classes.mobile__column__title}>Выбрать до</div>
            <div
              className={classes.mobile__column__text}
              color={
                moment().utc().isAfter(moment(offer.endedAt))
                  ? '#D61212'
                  : 'primary'
              }
            >
              {utils.formatDate(offer.endedAt)}
            </div>
            <Button
              sx={{
                marginLeft: 'auto',
                maxWidth: 140,
                height: 32,
                marginRight: 1,
              }}
              fullWidth
              variant={'contained'}
              disabled={isDisabledButton(offer)}
              className={classes.button}
              onClick={() => sendResponseToOffer(offer.id, 'Accepted')}
            >
              Принять
            </Button>
          </div>
          <div className={classes.mobile__column}>
            <div className={classes.mobile__column__title}>Статус</div>
            <div
              className={classes.mobile__column__text}
              color={
                getStatus(offer) === 'Принято'
                  ? '#329D00'
                  : ['Просрочено', 'Отклонено'].includes(getStatus(offer))
                  ? '#D61212'
                  : 'inherit'
              }
            >
              {getStatus(offer)}
            </div>
            <Button
              sx={{ maxWidth: 140, height: 32 }}
              color={'secondary'}
              fullWidth
              disabled={isDisabledButton(offer)}
              variant={'contained'}
              className={classes.button}
              onClick={() => sendResponseToOffer(offer.id, 'Declined')}
            >
              Отклонить
            </Button>
          </div>
        </div>
      </Box>
    );
  };

  return (
    <>
      {offers.length !== 0 ? (
        <>
          <Typography
            variant={'h6'}
            align={'center'}
            className={classes.subtitle}
          >
            Вы можете принять лишь одно приглашение
          </Typography>
          {!isMobile ? (
            <Grid2 container columns={countColumns} className={classes.grid}>
              {renderHeader()}
              {offers.map((offer) => {
                return renderItems(offer);
              })}
            </Grid2>
          ) : (
            <>{offers.map((offer) => renderItemOnMobile(offer))}</>
          )}
        </>
      ) : (
        <Typography
          variant={'h5'}
          fontSize={'1.4rem'}
          align={'center'}
          marginTop={2}
        >
          У вас еще нет приглашений 🙁 <br />
          Чтобы получить приглашения,{' '}
          {authStore.role === 'StudentNotFilled' && (
            <>
              <Link to={'/profile'} style={{ color: '#EF7F1A' }}>
                заполните
              </Link>{' '}
              профиль и
            </>
          )}{' '}
          выполните тестовое задание.
        </Typography>
      )}
      <Snackbar
        open={!!error}
        onClose={() => setError('')}
        message={error}
        autoHideDuration={3000}
      />
    </>
  );
};

const OffersListWrapper = observer(OffersList);
export { OffersListWrapper as OffersList };
