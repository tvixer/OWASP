import { zodResolver } from '@hookform/resolvers/zod';
import {
  Box,
  Button,
  Card,
  CircularProgress,
  Snackbar,
  Stack,
  TextField,
} from '@mui/material';
import React, { FC, useState } from 'react';
import { Controller, SubmitHandler, useForm } from 'react-hook-form';
import { object, string, TypeOf } from 'zod';

import { accountApi } from '../../api/accountAPI';
import classes from './styles.module.scss';

const personalScheme = object({
  name: string().nonempty('Укажите имя'),
  surname: string().nonempty('Укажите фамилию'),
  patronymic: string(),
  phone: string()
    .nonempty('Укажите номер телефона')
    .regex(
      /(^8|7|\+7)((\d{10})|(\s\(\d{3}\)\s\d{3}\s\d{2}\s\d{2}))/,
      'Укажите корректный номер'
    ),
  email: string().email('Укажите правильный адрес почты'),
  telegramUsername: string()
    .nonempty('Укажите ник')
    .regex(/^@[a-zA-Z0-9_]{5,32}$/, 'Укажите валидный ник'),
});

type PersonalProfileInput = TypeOf<typeof personalScheme>;

export const HRTutorPersonalData: FC = () => {
  const {
    register,
    formState: { errors, isLoading, isValid, isDirty, isSubmitting },
    watch,
    reset,
    control,
    handleSubmit,
  } = useForm<PersonalProfileInput>({
    mode: 'onBlur',
    resolver: zodResolver(personalScheme),
    defaultValues: async () => {
      const response = await accountApi.getHRTutorProfile();
      return {
        name: response.name,
        surname: response.surname,
        patronymic: response.patronymic,
        phone: response.phone,
        email: response.email,
        telegramUsername: `@${response.telegramUsername.replace('@', '')}`,
      };
    },
  });

  const [isOpenSnack, setIsOpenSnack] = useState(false);
  const [snackMessage, setSnackMessage] = useState('');

  const onSubmitHandler: SubmitHandler<PersonalProfileInput> = async (
    values
  ) => {
    try {
      await accountApi.updateHRTutorProfile(values);
      setSnackMessage('Профиль успешно обновлен!');
      reset({ ...watch() });
    } catch (e) {
      typeof e === 'string'
        ? setSnackMessage(e as string)
        : setSnackMessage('Произошла неизвестная ошибка');
    } finally {
      setIsOpenSnack(true);
    }
  };

  const getFieldProps = (name: keyof PersonalProfileInput) => {
    return {
      ...register(name),
      error: !!errors[name],
      helperText: errors[name]?.message,
    };
  };

  return (
    <Card>
      <Box maxWidth={600} marginTop={1}>
        {isLoading ? (
          <Box className={classes.loadingContainer}>
            <CircularProgress />
          </Box>
        ) : (
          <Stack spacing={4}>
            <TextField label={'Имя'} {...getFieldProps('name')} />
            <TextField label={'Фамилия'} {...getFieldProps('surname')} />
            <TextField label={'Отчество'} {...getFieldProps('patronymic')} />
            <TextField
              label={'Ник в телеграме'}
              placeholder={'@nickname'}
              {...getFieldProps('telegramUsername')}
            />
            <Stack direction={'row'} spacing={2}>
              <TextField
                disabled
                label={'E-mail'}
                {...getFieldProps('email')}
              />
              <Controller
                name={register('phone').name}
                control={control}
                render={({ field }) => {
                  return (
                    <TextField
                      value={field.value}
                      onChange={(e) => {
                        if (/^\d*$/.test(e.target.value)) {
                          field.onChange(e);
                        }
                      }}
                      error={!!errors['phone']}
                      helperText={errors['phone']?.message}
                      placeholder={'Пример номера: 8987999999'}
                      label={'Номер телефона'}
                    />
                  );
                }}
              />
            </Stack>
            <Button
              variant={'contained'}
              onClick={handleSubmit(onSubmitHandler)}
              disabled={!isValid || !isDirty || isSubmitting}
            >
              Сохранить изменения в профиле
            </Button>
          </Stack>
        )}
      </Box>
      <Snackbar
        open={isOpenSnack}
        autoHideDuration={3000}
        onClose={() => setIsOpenSnack(false)}
        message={snackMessage}
      />
    </Card>
  );
};
