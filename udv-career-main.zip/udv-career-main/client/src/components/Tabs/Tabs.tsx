import clsx from 'clsx';
import React, { FC, ReactNode } from 'react';
import { Navigate, Route, Routes, useNavigate } from 'react-router-dom';

import classes from './styles.module.scss';

export interface Tab {
  label: string;
  content: ReactNode | null;
  urlPath: string;
  title?: string;
}

export interface TabsProps {
  tabs: Tab[];
}

export const Tabs: FC<TabsProps> = ({ tabs }) => {
  const navigate = useNavigate();

  return (
    <div>
      <div className={classes.header}>
        <div className={classes.tabs}>
          {tabs?.map((tab, index) => {
            return tab.content !== null ? (
              <div
                key={index}
                className={clsx(classes.tab, {
                  [classes.tab_active]: window.location.pathname
                    .split('/')
                    .includes(tab.urlPath),
                })}
                onClick={() => navigate(tab.urlPath)}
              >
                {tab.label}
              </div>
            ) : null;
          })}
        </div>
      </div>
      <Routes>
        {tabs?.map((tab) => (
          <Route
            key={tab.urlPath}
            path={`${tab.urlPath}/*`}
            element={tab.content}
          />
        ))}
        <Route
          index
          element={
            <Navigate
              to={tabs?.filter(({ content }) => content !== null)[0].urlPath}
            />
          }
        />
      </Routes>
    </div>
  );
};
