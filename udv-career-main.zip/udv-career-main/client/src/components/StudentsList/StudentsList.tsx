import { Pagination, Typography } from '@mui/material';
import React, { FC, useEffect, useState } from 'react';

import { accountApi } from '../../api/accountAPI';
import { directionApi } from '../../api/directionAPI';
import { utils } from '../../common/utils';
import { IStudentData } from '../../types/directionTypes';
import { UsersList } from '../UsersList/UsersList';

export const StudentsList: FC<{ directionId: number }> = ({ directionId }) => {
  const [students, setStudents] = useState<IStudentData[]>();
  const [countPage, setCountPage] = useState(1);
  const [activePage, setActivePage] = useState(1);

  const getStudents = async () => {
    try {
      const response = await directionApi.getStudents(directionId, activePage);
      setStudents(response.items);
      setCountPage(utils.getCountPage(response.total));
    } catch (e) {
      console.error(e);
    }
  };

  const handleBan = async (id: number) => {
    try {
      await accountApi.ban(id);
      getStudents();
    } catch (e) {
      console.error(e);
    }
  };

  const handleUnBan = async (id: number) => {
    try {
      await accountApi.unBan(id);
      getStudents();
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    getStudents();
  }, [directionId, activePage]);

  return (
    <>
      {students && students.length !== 0 ? (
        <UsersList<IStudentData>
          headers={['ФИО', 'ВУЗ', 'Направление', 'Курс']}
          rows={students?.map((student) => ({
            id: student.id,
            items: [
              [student.surname, student.name, student.patronymic].join(' '),
              student.institute,
              student.specialization,
              student.course.toString(),
            ],
            user: student,
          }))}
          btnText={(user) => (user.isBanned ? 'Восстановить' : 'Удалить')}
          onClick={(user) => {
            user.isBanned ? handleUnBan(user.id) : handleBan(user.id);
          }}
        />
      ) : (
        <Typography variant={'h5'} align={'center'}>
          Нет студентов на направлении :(
        </Typography>
      )}
      {countPage > 1 && (
        <Pagination
          page={activePage}
          count={countPage}
          onChange={(_, value) => setActivePage(value)}
          hidePrevButton
          hideNextButton
        />
      )}
    </>
  );
};
