import { Pagination } from '@mui/material';
import { observer } from 'mobx-react';
import { FC, useCallback, useContext, useEffect, useState } from 'react';

import { accountApi } from '../../api/accountAPI';
import { utils } from '../../common/utils';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import { IUserData } from '../../types/accountTypes';
import { UsersList } from '../UsersList/UsersList';

export enum EmployersType {
  HR = 'hr',
  Tutor = 'tutor',
}

interface EmployersListProps {
  employerType: EmployersType;
  activePage: number;
  setActivePage: (page: number) => void;
}

const EmployersList: FC<EmployersListProps> = ({
  activePage,
  setActivePage,
}) => {
  const [countPage, setCountPage] = useState(1);
  const {
    appStore: { employersListStore },
  } = useContext<AppStoreContext>(StoreCtx);
  const getEmployerType = () =>
    window.location.pathname.split('/')[2] === 'hr'
      ? EmployersType.HR
      : EmployersType.Tutor;

  useEffect(() => {
    (async () =>
      setCountPage(
        await employersListStore.getEmployers(getEmployerType(), activePage)
      ))();
  }, [getEmployerType(), activePage]);

  const handleBan = useCallback(
    async (id: number) => {
      try {
        await accountApi.ban(id);
        setCountPage(
          await employersListStore.getEmployers(getEmployerType(), activePage)
        );
      } catch (e) {
        console.error(e);
      }
    },
    [getEmployerType(), activePage]
  );

  const handleUnBan = useCallback(
    async (id: number) => {
      try {
        await accountApi.unBan(id);
        console.log('in unban', getEmployerType());
        setCountPage(
          await employersListStore.getEmployers(getEmployerType(), activePage)
        );
      } catch (e) {
        console.error(e);
      }
    },
    [getEmployerType(), activePage]
  );

  return (
    <>
      {employersListStore.employers.length !== 0 && (
        <UsersList<IUserData>
          headers={['ФИО', 'email']}
          rows={employersListStore.employers.map((employee) => ({
            id: employee.id,
            items: [
              [employee.surname, employee.name, employee.patronymic].join(' '),
              employee.email,
            ],
            user: employee,
          }))}
          btnText={(user) => (user.isBanned ? 'Восстановить' : 'Удалить')}
          onClick={(user) => {
            user.isBanned ? handleUnBan(user.id) : handleBan(user.id);
          }}
          disableBtn={(user) => user.id == utils.getId()}
        />
      )}
      {countPage > 1 && (
        <Pagination
          page={activePage}
          count={countPage}
          onChange={(_, value) => setActivePage(value)}
          hidePrevButton
          hideNextButton
        />
      )}
    </>
  );
};

const EmployersListWrapped = observer(EmployersList);
export { EmployersListWrapped as EmployersList };
