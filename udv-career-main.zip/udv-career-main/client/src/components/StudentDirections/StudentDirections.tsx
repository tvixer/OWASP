import { Typography } from '@mui/material';
import React, { FC, useEffect, useState } from 'react';

import { directionApi } from '../../api/directionAPI';
import { utils } from '../../common/utils';
import { IDirectionData } from '../../types/directionTypes';
import { DirectionsPalette } from '../DirectionsPalette/DirectionsPalette';

export const StudentDirections: FC = () => {
  const [directions, setDirections] = useState<IDirectionData[]>([]);

  const getDirections = async () => {
    try {
      const directList = await directionApi.getStudentDirections(utils.getId());
      setDirections(directList);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    getDirections();
  }, []);

  return (
    <>
      {directions?.length > 0 ? (
        <DirectionsPalette showAddTile={false} directions={directions} />
      ) : (
        <Typography variant={'h5'} align={'center'}>
          Вы не записались ни на одно направление :(
        </Typography>
      )}
    </>
  );
};
