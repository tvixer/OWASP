import clsx from 'clsx';
import React, { FC, useEffect, useState } from 'react';

import classes from './styles.module.scss';

interface Item {
  label: string;
  value: any;
}

interface SwitchFieldProps {
  defaultValue?: any;
  item1: Item;
  item2: Item;
  onChange: (current: Item) => void;
}

export const SwitchField: FC<SwitchFieldProps> = ({
  item1,
  item2,
  defaultValue,
  onChange,
}) => {
  const [current, setCurrent] = useState<Item>(
    defaultValue == item1.value ? item1 : item2
  );

  useEffect(() => {
    setCurrent(defaultValue == item1.value ? item1 : item2);
  }, [defaultValue]);

  return (
    <div className={classes.itemContainer}>
      <div
        className={clsx(classes.item, {
          [classes.item_active]: current.value === item1.value,
        })}
        onClick={() => {
          setCurrent(item1);
          onChange(item1);
        }}
      >
        {item1.label}
      </div>
      <div
        className={clsx(classes.item, {
          [classes.item_active]: current.value === item2.value,
        })}
        onClick={() => {
          setCurrent(item2);
          onChange(item2);
        }}
      >
        {item2.label}
      </div>
    </div>
  );
};
