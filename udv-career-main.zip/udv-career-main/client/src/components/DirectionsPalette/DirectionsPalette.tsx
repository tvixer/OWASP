import Grid2 from '@mui/material/Unstable_Grid2';
import React, { FC, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

import { IDirectionData } from '../../types/directionTypes';
import { DirectionTile } from '../DirectionTile/DirectionTile';
import classes from './styles.module.scss';

interface DirectionsPaletteProps {
  directions: IDirectionData[];
  showAddTile: boolean;
}

export const DirectionsPalette: FC<DirectionsPaletteProps> = ({
  directions,
  showAddTile,
}) => {
  const navigate = useNavigate();
  const renderAddTile = () => (
    <Grid2 xs={12} sm={6} md={6} lg={4} xl={3}>
      <div
        className={classes.create}
        onClick={() => navigate('/direction/create')}
      >
        <div>+</div>
      </div>
    </Grid2>
  );
  const renderList = useCallback(() => {
    return (
      <Grid2 container spacing={4}>
        {showAddTile && renderAddTile()}
        {directions &&
          directions.map((direction, index) => {
            return (
              <Grid2 xs={12} sm={6} md={6} lg={4} xl={3} key={index}>
                <DirectionTile
                  description={direction.description}
                  title={direction.title}
                  id={direction.id}
                  availablePlaces={direction.availablePlaces}
                  isActive={direction.isActive}
                  department={direction.department}
                  style={{ margin: '0 auto' }}
                />
              </Grid2>
            );
          })}
      </Grid2>
    );
  }, [directions]);

  return renderList();
};
