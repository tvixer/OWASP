import MenuIcon from '@mui/icons-material/Menu';
import { Button, Drawer, MenuItem, Stack, Typography } from '@mui/material';
import clsx from 'clsx';
import { observer } from 'mobx-react';
import React, { FC, useContext, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import Logo from '../../logo.png';
import { Department } from '../../types/directionTypes';
import classes from './styles.module.scss';

interface INavigate {
  name: string;
  path: string;
}

const commonNavigations: INavigate[] = [
  {
    name: 'Направления УЦСБ',
    path: `/${Department.USSC}`,
  },
  {
    name: 'Направления UDV',
    path: `/${Department.UDV}`,
  },
];
const hrNavigations: INavigate[] = [
  {
    name: 'Студенты',
    path: '/students',
  },
  {
    name: 'HR\\Кураторы',
    path: '/hrAndTutors',
  },
];
const tutorNavigations: INavigate[] = [
  {
    name: 'Работы',
    path: '/solutions',
  },
  {
    name: 'Мои направления',
    path: '/myDirections',
  },
];
const studentNavigation: INavigate[] = [
  {
    name: 'Приглашения',
    path: '/offers',
  },
  {
    name: 'Мои направления',
    path: '/myDirections',
  },
];

const Header: FC = () => {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleOpenMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleCloseMenu = () => {
    setAnchorEl(null);
  };
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);
  const navigates = useMemo(() => {
    const navArr: INavigate[] = commonNavigations.slice();
    switch (authStore.role) {
      case 'Hr':
        navArr.push(...hrNavigations);
        break;
      case 'Student':
      case 'StudentNotFilled':
        navArr.push(...studentNavigation);
        break;
      case 'Tutor':
        navArr.push(...tutorNavigations);
        break;
    }
    return navArr;
  }, [authStore.isAuthorized, authStore.role]);
  const exit = () => {
    localStorage.removeItem('authToken');
    window.location.pathname = '/';
  };

  const renderNavigation = (nav: INavigate) => {
    const inLocation =
      (window.location.pathname.includes(nav.path) && nav.path !== '/') ||
      window.location.pathname === nav.path;
    return (
      <Typography
        key={nav.path}
        variant={'body2'}
        onClick={() => navigate(nav.path)}
        whiteSpace={'normal'}
        sx={{
          cursor: 'pointer',
          wordBreak: 'normal',
        }}
        color={inLocation ? '#2B2A29' : '#6F6F6F'}
        fontWeight={inLocation ? 400 : 300}
      >
        {nav.name}
      </Typography>
    );
  };

  const renderLogExit = () => {
    return (
      <>
        {authStore.isAuthorized ? (
          <>
            <div
              className={classes.userName}
              onClick={() => navigate('/profile')}
            >
              Мой профиль
            </div>
            <div className={classes.exit} onClick={() => exit()}>
              Выход
            </div>
          </>
        ) : (
          <div className={classes.userName}>
            <div onClick={() => navigate('/auth')}>Войти</div>
            <div
              className={classes.registration}
              onClick={() => navigate('/registration')}
            >
              Зарегистрироваться
            </div>
          </div>
        )}
      </>
    );
  };

  return (
    <>
      <div className={clsx(classes.container, classes.wide)}>
        <Stack direction={'row'} spacing={4}>
          <img
            onClick={() => navigate('/')}
            className={classes.logo}
            src={Logo}
            alt={'logo'}
          />
          <Stack direction={'row'} spacing={4} alignItems={'center'}>
            {navigates.map((nav) => renderNavigation(nav))}
          </Stack>
        </Stack>
        <div className={classes.infoContainer}>{renderLogExit()}</div>
      </div>
      <div className={classes.mobile}>
        <img
          onClick={() => navigate('/')}
          className={classes.logo}
          src={Logo}
          alt={'logo'}
        />
        <Button onClick={(e) => handleOpenMenu(e)}>
          <MenuIcon color={'secondary'} />
        </Button>
        <Drawer
          onClose={() => handleCloseMenu()}
          open={open}
          anchor={'right'}
          PaperProps={{
            sx: {
              backgroundColor: '#fff',
              borderRadius: 0,
            },
          }}
        >
          {navigates.map((nav) => (
            <MenuItem
              onClick={() => {
                navigate(nav.path);
                handleCloseMenu();
              }}
              key={nav.path}
            >
              {renderNavigation(nav)}
            </MenuItem>
          ))}

          {authStore.isAuthorized ? (
            <MenuItem
              onClick={() => {
                navigate('/profile');
                handleCloseMenu();
              }}
            >
              <Typography variant={'body2'}>Мой профиль</Typography>
            </MenuItem>
          ) : (
            <MenuItem
              onClick={() => {
                navigate('/auth');
                handleCloseMenu();
              }}
            >
              <Typography variant={'body2'}>Войти</Typography>
            </MenuItem>
          )}
          {authStore.isAuthorized ? (
            <MenuItem onClick={() => exit()}>
              <Typography variant={'body2'}>Выход</Typography>
            </MenuItem>
          ) : (
            <MenuItem onClick={() => navigate('/registration')}>
              <Typography variant={'body2'}>Зарегистрироваться</Typography>
            </MenuItem>
          )}
        </Drawer>
      </div>
    </>
  );
};
const HeaderWrapped = observer(Header);
export { HeaderWrapped as Header };
