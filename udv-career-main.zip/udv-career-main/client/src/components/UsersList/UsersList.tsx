import { Button, Typography } from '@mui/material';
import Grid2 from '@mui/material/Unstable_Grid2';
import clsx from 'clsx';
import React, {
  Fragment,
  PropsWithChildren,
  ReactElement,
  useCallback,
  useMemo,
} from 'react';

import classes from './styles.module.scss';

interface UserRow<T> {
  items: string[];
  id: number;
  user: T;
}

interface UsersListProps<T> {
  headers: string[];
  rows: UserRow<T>[];
  btnText: (user: T) => string;
  disableBtn?: (user: T) => boolean;
  onClick: (user: T) => void;
}
export const UsersList = <T,>({
  headers,
  rows,
  btnText,
  onClick,
  disableBtn,
}: PropsWithChildren<UsersListProps<T>>): ReactElement => {
  if (rows.length === 0) {
    return (
      <Typography variant={'h6'} marginTop={2}>
        Нет сотрудников этого типа
      </Typography>
    );
  }

  const countColumns = useMemo(
    () => rows[0].items.length * 2 + 2 /*два на поле и одно на кнопку*/,
    [rows]
  );

  const renderHeader = useCallback(() => {
    return (
      <>
        {headers.map((header) => {
          return (
            <Grid2
              className={clsx(classes.header, classes.item)}
              xs={2}
              key={header}
            >
              {header}
            </Grid2>
          );
        })}
        <Grid2 xs={2} className={clsx(classes.header, classes.item)}></Grid2>
      </>
    );
  }, [headers]);

  const renderItems = useCallback((userRow: UserRow<T>) => {
    return (
      <>
        {userRow.items.map((item) => {
          return (
            <Grid2 className={classes.item} xs={2} key={item}>
              {item}
            </Grid2>
          );
        })}
        <Grid2 xs={2} className={classes.item}>
          <Button
            sx={{ marginLeft: 'auto', maxWidth: 180, height: 32 }}
            fullWidth
            variant={'contained'}
            className={classes.button}
            disabled={disableBtn?.(userRow.user)}
            onClick={() => onClick(userRow.user)}
          >
            {btnText(userRow.user)}
          </Button>
        </Grid2>
      </>
    );
  }, []);

  return (
    <Grid2 container columns={countColumns}>
      {renderHeader()}
      {rows.map((row) => (
        <Fragment key={row.id}>{renderItems(row)}</Fragment>
      ))}
    </Grid2>
  );
};
