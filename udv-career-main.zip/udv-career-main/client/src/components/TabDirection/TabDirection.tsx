import { Box, Card } from '@mui/material';
import clsx from 'clsx';
import { observer } from 'mobx-react';
import React, { FC } from 'react';
import { Navigate, Route, Routes, useNavigate } from 'react-router-dom';

import { TabsProps } from '../Tabs';
import classes from './styles.module.scss';

interface TabDirectionProps extends TabsProps {
  defaultUrl: string;
  maxTabsWidth?: number;
  grey?: boolean;
}

const TabDirection: FC<TabDirectionProps> = ({
  tabs,
  defaultUrl,
  maxTabsWidth,
  grey = false,
}) => {
  const navigate = useNavigate();

  return (
    <div>
      <Box
        gridTemplateColumns={`repeat(${tabs?.length}, 200px)`}
        className={classes.container}
        maxWidth={maxTabsWidth}
      >
        {tabs?.map((tab, index) => (
          <div
            key={index}
            className={clsx(classes.tab, {
              [classes.tab__active]: window.location.pathname
                .split('/')
                .includes(tab.urlPath),
              [classes.tab__grey]: grey,
            })}
            onClick={() => navigate(tab.urlPath)}
          >
            <Box display={'flex'} alignItems={'center'}>
              {tab.label}
            </Box>
          </div>
        ))}
      </Box>
      <Card sx={{ position: 'relative', borderRadius: 6 }}>
        <Routes>
          {tabs?.map((tab) => (
            <>
              <Route
                key={tab.urlPath}
                path={tab.urlPath}
                element={
                  <>
                    {tab.title && (
                      <Box
                        sx={{
                          borderRadius: '25px',
                          border: '1px solid #2B2A29',
                          height: '60px',
                          display: 'flex',
                          alignItems: 'center',
                          padding: '0 128px 0 64px',
                        }}
                      >
                        {tab.title}
                      </Box>
                    )}
                    {tab.content}
                  </>
                }
              />
            </>
          ))}
          <Route index element={<Navigate to={defaultUrl} />} />
        </Routes>
      </Card>
    </div>
  );
};

const TabDirectionWrapped = observer(TabDirection);
export { TabDirectionWrapped as TabDirection };
