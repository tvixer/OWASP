import { animated, useInView } from '@react-spring/web';
import { FC, PropsWithChildren } from 'react';

interface AnimatedProps extends PropsWithChildren {
  animDirection: 'top' | 'bottom' | 'right' | 'left';
}
export const Animated: FC<AnimatedProps> = ({ animDirection, children }) => {
  const offset = 300;
  const getFrom = () => {
    switch (animDirection) {
      case 'top':
        return { y: offset };
      case 'bottom':
        return { y: -offset };
      case 'left':
        return { x: offset };
      case 'right':
        return { x: -offset };
    }
  };

  const [ref, springs] = useInView(() => ({
    from: {
      opacity: 0,
      ...getFrom(),
    },
    to: {
      opacity: 1,
      y: 0,
      x: 0,
    },
  }));

  return (
    <animated.div ref={ref} style={springs}>
      {children}
    </animated.div>
  );
};
