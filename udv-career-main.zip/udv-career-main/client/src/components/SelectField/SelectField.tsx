import { ClickAwayListener } from '@mui/material';
import clsx from 'clsx';
import React, { FC, useState } from 'react';

import { ReactComponent as Arrow } from './Arrow.svg';
import classes from './styles.module.scss';

interface SelectFieldProps {
  className?: string;
  options?: Option[];
  placeholder: string;
  onChange: (option: Option) => void;
  defaultId?: string;
}

export interface Option {
  id: number | string;
  label: string;
}

export const SelectField: FC<SelectFieldProps> = ({
  className,
  placeholder,
  options,
  onChange,
  defaultId,
}) => {
  const [active, setActive] = useState(false);
  const [activeElement, setActiveElement] = useState<Option | undefined>(
    defaultId && options
      ? options?.find((option) => option.id === defaultId)
      : undefined
  );
  return (
    <ClickAwayListener onClickAway={() => setActive(false)}>
      <div className={clsx(className, classes.container)}>
        <div
          className={classes.label}
          style={{ color: 'black' }}
          onClick={() => setActive(!active)}
        >
          {activeElement ? activeElement.label : placeholder}
          <div
            className={clsx(classes.arrow, { [classes.arrow_active]: !active })}
          >
            <Arrow />
          </div>
        </div>
        <ul
          className={classes.select}
          style={{ display: active ? 'flex' : 'none' }}
        >
          {options?.map((option, index) => (
            <li
              className={classes.option}
              value={option.id}
              key={index}
              onClick={() => {
                setActiveElement(option);
                setActive(false);
                onChange(option);
              }}
            >
              {option.label}
            </li>
          ))}
        </ul>
      </div>
    </ClickAwayListener>
  );
};
