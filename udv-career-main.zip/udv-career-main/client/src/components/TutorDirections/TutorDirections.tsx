import {
  Box,
  Button,
  Card,
  Link,
  Pagination,
  Paper,
  Typography,
} from '@mui/material';
import clsx from 'clsx';
import React, { FC, useCallback, useEffect, useState } from 'react';

import { directionApi } from '../../api/directionAPI';
import { utils } from '../../common/utils';
import { IDirectionData } from '../../types/directionTypes';
import classes from './styles.module.scss';

export const TutorDirections: FC = () => {
  const [tutorDirections, setTutorDirections] = useState<IDirectionData[]>();
  const [allDirections, setAllDirections] = useState<IDirectionData[]>();
  const [enrollingId, setEnrollingId] = useState<number | undefined>();
  const [countPage, setCountPage] = useState(1);
  const [activePage, setActivePage] = useState(1);

  const getTutorDirections = async () => {
    setTutorDirections(await directionApi.getTutorDirections(utils.getId()));
  };

  const getAllDirection = async () => {
    const response = await directionApi.getDirections(activePage);
    setCountPage(utils.getCountPage(response.total));
    setAllDirections(response.items);
  };

  const becomeTutor = async (id: number) => {
    setEnrollingId(id);
    await directionApi.becomeTutor(id);
    await getTutorDirections();
    await getAllDirection();
    setEnrollingId(undefined);
  };

  const unsubscribeTutor = async (id: number) => {
    setEnrollingId(id);
    await directionApi.unsubscribeTutor(id);
    await getTutorDirections();
    await getAllDirection();
    setEnrollingId(undefined);
  };

  useEffect(() => {
    getTutorDirections();
  }, []);

  useEffect(() => {
    getAllDirection();
  }, [activePage]);

  useEffect(() => {
    const tutorDirIds = tutorDirections?.map(({ id }) => id);
    setAllDirections((prevDirectionsState) => {
      return prevDirectionsState?.filter(
        ({ id }) => !tutorDirIds?.includes(id)
      );
    });
  }, [tutorDirections, allDirections]);

  const renderListItem = (
    direction: IDirectionData,
    showSolutionLink: boolean,
    showEnrollBtn: boolean
  ) => {
    return (
      <Card
        sx={{ padding: '16px 8px', marginBottom: '1px' }}
        key={direction.id}
      >
        <Box
          display={'grid'}
          gridTemplateColumns="repeat(5, 1fr)"
          className={classes.list}
        >
          <Box gridColumn={'span 2'}>
            <Link
              color={'#232326'}
              target="_blank"
              href={`/direction/${direction.id}`}
              sx={{ textDecoration: 'underline' }}
            >
              <Typography variant={'body2'}>{direction.title}</Typography>
            </Link>
          </Box>
          <Box gridColumn={'span 1'} marginRight={2} whiteSpace={'nowrap'}>
            {showSolutionLink && (
              <Link color={'#232326'} href={`/solutions/${direction.id}`}>
                Показать решения
              </Link>
            )}
          </Box>
          <Box></Box>
          <Box gridColumn={'span 1'} display={'flex'} justifyContent={'end'}>
            {direction.studentIsEnrolled}
            <Button
              onClick={() => {
                showEnrollBtn
                  ? becomeTutor(direction.id)
                  : unsubscribeTutor(direction.id);
              }}
              sx={{ height: 32, width: '200px' }}
              variant={'contained'}
              disabled={enrollingId === direction.id}
            >
              {showEnrollBtn ? 'Записаться' : 'Отписаться'}
            </Button>
          </Box>
        </Box>
      </Card>
    );
  };
  const renderDirectionsList = useCallback(
    (
      directions: IDirectionData[],
      showSolutionLink: boolean,
      showEnrollBtn: boolean,
      showPagination: boolean
    ) => {
      return (
        <Paper sx={{ backgroundColor: '#F3F3F3', padding: '16px 32px' }}>
          <>
            <Box
              display={'grid'}
              gridTemplateColumns="repeat(5, 1fr)"
              className={clsx(classes.title, classes.list)}
              color={'#77767E'}
              paddingRight={1}
              paddingLeft={1}
            >
              <Box paddingLeft={4} gridColumn={'span 2'}>
                <Typography variant={'h6'}>Направление</Typography>
              </Box>
              <Box gridColumn={'span 1'} justifyContent={'center'}></Box>
              <Box gridColumn={'span 1'} width={'153px'}></Box>
              <Box gridColumn={'span 1'} width={'200px'}></Box>
            </Box>
            {directions.map((direction) => {
              return renderListItem(direction, showSolutionLink, showEnrollBtn);
            })}
          </>
          {showPagination && countPage > 1 && (
            <Pagination
              page={activePage}
              count={countPage}
              onChange={(_, value) => setActivePage(value)}
              hidePrevButton
              hideNextButton
            />
          )}
        </Paper>
      );
    },
    [tutorDirections, allDirections, enrollingId]
  );

  return (
    <Card>
      {tutorDirections?.length === 0 ? (
        <Typography variant={'body2'}>
          Вы пока не закреплены за направлением
        </Typography>
      ) : (
        tutorDirections &&
        renderDirectionsList(tutorDirections, true, false, false)
      )}
      <Typography
        marginTop={3}
        variant={'h5'}
        className={classes.title}
        marginBottom={4}
      >
        Все направления
      </Typography>
      {allDirections && renderDirectionsList(allDirections, false, true, true)}
    </Card>
  );
};
