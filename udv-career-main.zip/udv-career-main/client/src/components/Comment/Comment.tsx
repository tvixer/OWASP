import { Stack, Typography } from '@mui/material';
import { FC } from 'react';

import classes from './styles.module.scss';

interface CommentProps {
  author: string;
  text: string;
  side: 'left' | 'right';
}
export const Comment: FC<CommentProps> = ({ author, text, side }) => {
  return (
    <Stack
      className={classes.container}
      sx={{ alignSelf: side === 'left' ? 'flex-start' : 'flex-end' }}
      spacing={1}
    >
      <Typography
        alignSelf={side === 'left' ? 'flex-start' : 'flex-end'}
        color={'primary'}
      >
        {author}
      </Typography>
      <Typography color={'#6e6e6e'} whiteSpace={'break-spaces'}>
        {text}
      </Typography>
    </Stack>
  );
};
