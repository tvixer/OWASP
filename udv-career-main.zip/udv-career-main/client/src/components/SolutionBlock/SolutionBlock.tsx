import {
  Box,
  Button,
  Snackbar,
  Stack,
  TextField,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import React, { FC, useCallback, useEffect, useState } from 'react';

import { directionApi } from '../../api/directionAPI';
import { solutionApi } from '../../api/solutionAPI';
import { utils } from '../../common/utils';
import { ErrorEnum } from '../../types/errorTypes';
import {
  ISolutionDetailedData,
  ISolutionsRequest,
  SolutionStatus,
} from '../../types/solutionsTypes';
import { CommentsBlock } from '../CommentsBlock/CommentsBlock';
import { MyModal } from '../MyModal/MyModal';
import classes from './styles.module.scss';

interface SolutionBlockProps {
  status: SolutionStatus;
  finishAcceptingAt: number;
  directionId: string;
  onFinish: () => void;
  solutionId?: string;
}

interface IAnswer {
  title: string;
  text: string;
  id: number;
}
export const SolutionBlock: FC<SolutionBlockProps> = ({
  status,
  finishAcceptingAt,
  directionId,
  onFinish,
  solutionId,
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [openModal, setOpenModal] = useState(false);
  const [openWarnModal, setOpenWarnModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [answers, setAnswers] = useState<IAnswer[]>();
  const [solution, setSolution] = useState<ISolutionDetailedData>();
  const [UIFeedback, setUIFeedback] = useState('');
  const [taskDescription, setTaskDescription] = useState('');

  const getAnswers = async () => {
    const response = await directionApi.getQuestions(directionId);
    setTaskDescription(response.taskDescription);
    setAnswers(
      response.questions.map((quest) => ({
        text: '',
        id: quest.id,
        title: quest.text,
      }))
    );
  };

  const getSolution = async (solId: string) => {
    const response = await solutionApi.getSolution(solId);
    setSolution(response);
  };

  useEffect(() => {
    getAnswers();
  }, []);

  useEffect(() => {
    solutionId && getSolution(solutionId);
  }, [solutionId]);

  useEffect(() => {
    solution &&
      setAnswers(
        solution.answers.map((answer) => ({
          text: answer.text,
          id: answer.questionId,
          title: answer.questionText,
        }))
      );
  }, [solution]);

  const renderQuestion = useCallback(
    (title: string, answer: string, onValueChange: (value: string) => void) => {
      return (
        <Stack spacing={2} marginTop={2}>
          <Typography variant={'body2'} whiteSpace={'break-spaces'}>
            {title}
          </Typography>{' '}
          <TextField
            disabled={status !== 'NotStarted'}
            multiline
            minRows={4}
            value={answer}
            sx={{
              '.MuiInputBase-root': {
                paddingLeft: '20px',
              },
            }}
            placeholder={'Ваш ответ...'}
            onChange={(e) => onValueChange(e.target.value)}
          />
        </Stack>
      );
    },
    [answers, status]
  );
  const getStatus = (status: SolutionStatus) => {
    switch (status) {
      case 'Approved':
        return 'принято';
      case 'Rejected':
        return 'отклонено';
      case 'OnCheck':
        return 'на рассмотрении';
      case 'NotStarted':
      default:
        return 'не начато';
    }
  };
  const sendSolution = async () => {
    setLoading(true);
    try {
      if (answers) {
        const data: ISolutionsRequest = {
          directionId: directionId,
          answers: answers.map((answer) => ({
            text: answer.text,
            questionId: answer.id,
          })),
        };
        await solutionApi.sendSolution(data);
        setOpenModal(false);
        setUIFeedback('Ответ отправлен успешно');
        //Чтобы обновилось состояние
        onFinish();
        getAnswers();
      }
    } catch (e) {
      typeof e === 'string'
        ? setUIFeedback(e as string)
        : setUIFeedback('Произошла неизвестная ошибка');
      if (e === ErrorEnum['Solution.AcceptingEndedError']) {
        setOpenModal(false);
      }
      console.error(e);
    } finally {
      setOpenWarnModal(false);
      setLoading(false);
    }
  };

  return (
    <div className={classes.container}>
      <Stack spacing={3} className={classes.contentContainer}>
        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          justifyContent={'space-between'}
          spacing={1}
        >
          <Stack direction={'row'} spacing={1}>
            <Typography variant={'h5'} fontSize={'1em'}>
              Срок сдачи:
            </Typography>
            <Typography variant={'h5'} fontSize={'1em'} color={'primary'}>
              {utils.formatDate(finishAcceptingAt)}
            </Typography>
          </Stack>
          <Stack direction={'row'}>
            <Typography variant={'h5'} fontSize={'0.9em'}>
              Статус:{' '}
            </Typography>
            <Typography variant={'h5'} fontSize={'0.9em'} color={'primary'}>
              &nbsp;{getStatus(status)}
            </Typography>
          </Stack>
        </Stack>
        <Stack direction={'row'} justifyContent={'center'}>
          <Button
            variant={'contained'}
            sx={{ width: isMobile ? '100%' : '50%' }}
            onClick={() => setOpenModal(true)}
          >
            {status === 'NotStarted'
              ? 'Перейти к тестовому заданию'
              : 'Посмотреть ответы'}
          </Button>
        </Stack>
        <MyModal
          open={openModal}
          onClose={() => setOpenModal(false)}
          title={'Тестовое задание'}
        >
          <div className={classes.modalContent}>
            <Typography
              whiteSpace={'break-spaces'}
              fontSize={24}
              color={'#6F6F6F'}
            >
              {taskDescription}
            </Typography>
            {answers &&
              answers.map((answer, index) => {
                return renderQuestion(answer.title, answer.text, (value) => {
                  const answerNew = answers.slice(0);
                  answerNew[index].text = value;
                  setAnswers(answerNew);
                });
              })}
            <Stack marginTop={2} direction={'row'} justifyContent={'flex-end'}>
              <Button
                onClick={() => setOpenWarnModal(true)}
                variant={'contained'}
                disabled={
                  status !== 'NotStarted' ||
                  answers?.filter((answer) => answer.text).length !==
                    answers?.length
                }
              >
                Отправить
              </Button>
            </Stack>
          </div>
        </MyModal>
        <MyModal
          open={openWarnModal}
          onClose={() => setOpenWarnModal(false)}
          title={'Предупреждение'}
        >
          <Typography variant={'h6'} marginBottom={2}>
            После отправки вы не сможете изменить свои ответы. Вы уверены, что
            хотите отправить решение?
          </Typography>
          <Stack direction={'row'} spacing={2}>
            <Button
              variant={'contained'}
              onClick={() => setOpenWarnModal(false)}
              color={'secondary'}
              fullWidth
            >
              Отменить
            </Button>
            <Button
              fullWidth
              variant={'contained'}
              onClick={sendSolution}
              disabled={loading}
            >
              Отправить
            </Button>
          </Stack>
        </MyModal>
        <Snackbar
          open={!!UIFeedback}
          message={UIFeedback}
          autoHideDuration={3000}
          onClose={() => setUIFeedback('')}
        />
      </Stack>
      {solutionId &&
      solution &&
      ['Approved', 'Rejected'].includes(solution.status) ? (
        <CommentsBlock
          firstUser={solution.student}
          secondUser={solution.tutor}
          solutionId={solutionId}
        />
      ) : (
        <Box marginTop={5} />
      )}
    </div>
  );
};
