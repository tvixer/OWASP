import { Visibility, VisibilityOff } from '@mui/icons-material';
import { IconButton, InputAdornment, TextField } from '@mui/material';
import { TextFieldProps } from '@mui/material/TextField/TextField';
import React, { FC, useState } from 'react';

export const PasswordField: FC<TextFieldProps> = ({
  onChange,
  onBlur,
  ...props
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const validatePass = () => {
    const value = (props.value as string).trim();
    if (value.length <= 3) {
      setError('Пароль должен быть длинее');
    }
  };
  return (
    <TextField
      {...props}
      type={showPassword ? 'text' : 'password'}
      onBlur={(event) => {
        onBlur?.(event);
        validatePass();
      }}
      onChange={(event) => {
        setError('');
        onChange?.(event);
      }}
      error={!!props.error || !!error}
      helperText={props.helperText || error}
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <IconButton onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? <VisibilityOff /> : <Visibility />}
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
};
