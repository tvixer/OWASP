import { Card, Modal, Typography } from '@mui/material';
import React, { FC, ReactNode } from 'react';

import classes from './styles.module.scss';

interface MyModalProps {
  open: boolean;
  onClose: () => void;
  children?: ReactNode;
  title?: string;
}
export const MyModal: FC<MyModalProps> = ({
  onClose,
  open,
  children,
  title,
}) => {
  return (
    <Modal open={open} onClose={onClose}>
      <Card className={classes.modalContainer}>
        <Typography variant={'h5'} marginBottom={3}>
          {title}
        </Typography>
        <div>{children}</div>
      </Card>
    </Modal>
  );
};
