import { Box, Pagination, Stack, Typography } from '@mui/material';
import { FC, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { solutionApi } from '../../api/solutionAPI';
import { utils } from '../../common/utils';
import { ISolutionData } from '../../types/solutionsTypes';

interface SolutionsListProps {
  directionId: string;
}

export const SolutionsList: FC<SolutionsListProps> = ({ directionId }) => {
  const [countPage, setCountPage] = useState(1);
  const [activePage, setActivePage] = useState(1);
  const [solutions, setSolutions] = useState<ISolutionData[]>([]);
  const navigate = useNavigate();
  const getSolutions = async () => {
    const response = await solutionApi.getSolutions(directionId, activePage);
    setSolutions(response.items);
    setCountPage(utils.getCountPage(response.total));
  };

  useEffect(() => {
    getSolutions();
  }, [directionId, activePage]);

  const goToCheckDirectionPage = (solutionId: number) => {
    navigate(`/checkSolution/${solutionId}`);
  };

  return (
    <Stack spacing={2} padding={3}>
      {solutions.length !== 0 ? (
        solutions.map((solution) => {
          return (
            <Box
              key={solution.sentAt}
              onClick={() => goToCheckDirectionPage(solution.id)}
              sx={{
                cursor: 'pointer',
                borderRadius: 25,
                backgroundColor:
                  solution.status === 'Approved'
                    ? '#EF7F1A'
                    : solution.status === 'Rejected'
                    ? '#ADADAD'
                    : '#CCCCCC',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                height: 56,
                padding: '0 40px 0 64px',
              }}
            >
              <Typography>{solution.studentFullname}</Typography>
              <Typography>{utils.formatDate(solution.sentAt)}</Typography>
            </Box>
          );
        })
      ) : (
        <Typography textAlign={'center'} variant={'body2'}>
          Нет решений
        </Typography>
      )}
      {countPage > 1 && (
        <Pagination
          page={activePage}
          count={countPage}
          onChange={(_, value) => setActivePage(value)}
          hidePrevButton
          hideNextButton
        />
      )}
    </Stack>
  );
};
