import { LIMIT_ON_PAGE } from '../common/utils';
import {
  IHRTutorData,
  IStudent,
  IUpdateStudentProfile,
  IUserResponse,
} from '../types/accountTypes';
import { axiosInstance } from './axios';
import { BaseAPI } from './baseAPI';

class accountAPI extends BaseAPI {
  public async registerStudent(email: string, password: string) {
    return await axiosInstance.post('account/register/student', {
      email,
      password,
    });
  }
  public async login(email: string, password: string) {
    const response = await axiosInstance.post('account/login', {
      email,
      password,
    });
    return response.data;
  }

  public async getStudentProfile(): Promise<IStudent> {
    const response = await axiosInstance.get('account', {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status !== 200) {
      throw response.status;
    }
    return response.data;
  }

  public async updateStudentProfile(
    updateProfileData: IUpdateStudentProfile
  ): Promise<string> {
    const response = await axiosInstance.put('account', updateProfileData, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    return response.data;
  }

  public async getHRTutorProfile(): Promise<IHRTutorData> {
    const response = await axiosInstance.get('account', {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status !== 200) {
      throw response.status;
    }
    return response.data;
  }
  public async updateHRTutorProfile(data: IHRTutorData) {
    const response = await axiosInstance.put('account', data, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status !== 200) {
      throw response.status;
    }
  }

  public async ban(userId: number) {
    const response = await axiosInstance.post(
      'account/ban',
      { userId },
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status !== 200) {
      throw response.status;
    }
  }

  public async unBan(userId: number) {
    const response = await axiosInstance.post(
      'account/unban',
      { userId },
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status !== 200) {
      throw response.status;
    }
  }

  public async getUsers(
    role: 'Tutor' | 'Hr',
    page: number
  ): Promise<IUserResponse> {
    const response = await axiosInstance.get(
      `users?role=${role}&limit=${LIMIT_ON_PAGE}&page=${page}`,
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status !== 200) {
      throw response.status;
    }
    return response.data;
  }

  public async registerHRTutor(
    email: string,
    type: 'tutor' | 'hr'
  ): Promise<void> {
    await axiosInstance.post(
      `account/register/${type}`,
      {
        email,
      },
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
  }

  public async offerToRestorePassword(
    email: string,
    resetPagePath: string
  ): Promise<void> {
    await axiosInstance.post(`account/send-reset-mail`, {
      email,
      resetPagePath,
    });
  }

  public async restorePass(
    token: string | null,
    newPassword: string
  ): Promise<void> {
    await axiosInstance.post(`account/reset-password`, {
      token,
      newPassword,
    });
  }
}

export const accountApi = new accountAPI();
