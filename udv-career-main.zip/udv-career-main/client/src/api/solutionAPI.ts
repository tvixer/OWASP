import { LIMIT_ON_PAGE } from '../common/utils';
import { IComment } from '../types/commentTypes';
import {
  ISolutionDataResponse,
  ISolutionDetailedData,
  ISolutionsRequest,
  IVerdict,
} from '../types/solutionsTypes';
import { axiosInstance } from './axios';
import { BaseAPI } from './baseAPI';

class SolutionAPI extends BaseAPI {
  public async sendSolution(data: ISolutionsRequest): Promise<void> {
    const response = await axiosInstance.post(
      `solutions`,
      {
        ...data,
      },
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) {
      throw response.status;
    }
  }

  public async getSolutions(
    directionId: string,
    activePage: number
  ): Promise<ISolutionDataResponse> {
    const params = new URLSearchParams({
      directionId,
      limit: LIMIT_ON_PAGE,
      page: activePage,
    } as any);
    const url = 'solutions?' + params.toString();

    const response = await axiosInstance.get(url, {
      headers: { ...this.getAuthHeader() },
    });
    if (response.status != 200) {
      throw new response.data.type();
    }
    return response.data;
  }

  public async getSolution(solutionId: string): Promise<ISolutionDetailedData> {
    const response = await axiosInstance.get(`solutions/${solutionId}`, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }

  public async makeVerdict(solutionId: string, data: IVerdict): Promise<void> {
    const response = await axiosInstance.post(
      `solutions/${solutionId}/verdict`,
      {
        ...data,
      },
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) {
      throw response.status;
    }
  }

  public async getComments(solutionId: string): Promise<IComment[]> {
    const response = await axiosInstance.get(
      `solutions/${solutionId}/messages`,
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }

  public async sendComment(solutionId: string, message: string): Promise<void> {
    const response = await axiosInstance.post(
      `solutions/${solutionId}/messages`,
      { text: message },
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) {
      throw response.status;
    }
  }
}

export const solutionApi = new SolutionAPI();
