import { axiosInstance } from './axios';
import { BaseAPI } from './baseAPI';

class StudentsAPI extends BaseAPI {
  public async getReport(): Promise<any> {
    const response = await axiosInstance.get(`students/export`, {
      headers: {
        ...this.getAuthHeader(),
        'Content-Type':
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      },
      responseType: 'arraybuffer',
    });
    if (response.status !== 200) {
      throw response.status;
    }
    return response.data;
  }
}

export const studentsApi = new StudentsAPI();
