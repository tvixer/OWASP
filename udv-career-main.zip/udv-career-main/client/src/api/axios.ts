import axios, { AxiosError } from 'axios';

import { ErrorEnum, IError } from '../types/errorTypes';

axios.defaults.headers.post['Content-Type'] = 'application/json';
axios.defaults.headers.put['Content-Type'] = 'application/json';
export const axiosInstance = axios.create({
  baseURL: '/api/',
  timeout: 10000,
  headers: {
    'Access-Control-Allow-Origin': '*',
    },
});
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      const { response } = error as AxiosError<IError>;
      console.error(error);
      if (response && response.data.type) {
        return Promise.reject((ErrorEnum as any)[response.data.type]);
      }
      return Promise.reject(response);
    }
  }
);
