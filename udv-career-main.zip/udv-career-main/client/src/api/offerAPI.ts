import { IOffer, OfferStatus } from '../types/offerTypes';
import { axiosInstance } from './axios';
import { BaseAPI } from './baseAPI';

class OfferAPI extends BaseAPI {
  public async getOffers(studentId: number): Promise<IOffer[]> {
    const response = await axiosInstance.get(`offers?studentId=${studentId}`, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }

  public async sendResponseToOffer(offerId: number, offerStatus: OfferStatus) {
    const response = await axiosInstance.post(
      `offers/${offerId}`,
      offerStatus,
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) {
      throw response.status;
    }
  }
}

export const offerApi = new OfferAPI();
