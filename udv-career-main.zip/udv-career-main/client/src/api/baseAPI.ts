export class BaseAPI {
  protected getAuthHeader() {
    return {
      Authorization: 'Bearer ' + localStorage['authToken'],
    };
  }
}
