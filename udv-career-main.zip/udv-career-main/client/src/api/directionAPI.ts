import { LIMIT_ON_PAGE } from '../common/utils';
import {
  Department,
  ICreateDirectionData,
  IDirectionData,
  IDirectionsResponse,
  IQuestionResponse,
  IStudentResponse,
  IUpdateDirectionData,
} from '../types/directionTypes';
import { axiosInstance } from './axios';
import { BaseAPI } from './baseAPI';

class DirectionAPI extends BaseAPI {
  public async getDirections(
    page: number,
    department?: Department,
    limit = LIMIT_ON_PAGE
  ): Promise<IDirectionsResponse> {
    const params = new URLSearchParams({
      page,
      limit,
      ...(department ? { department } : {}),
    } as any);
    const response = await axiosInstance.get(
      `directions?${params.toString()}`,
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) throw response.status;
    return response.data;
  }

  public async getDirection(id: string): Promise<IDirectionData> {
    const response = await axiosInstance.get(`directions/${id}`, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }

  public async getStudentDirections(
    studentId: number
  ): Promise<IDirectionData[]> {
    const response = await axiosInstance.get(
      `students/${studentId}/directions`,
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }

  public async getTutorDirections(tutorId: number): Promise<IDirectionData[]> {
    const response = await axiosInstance.get(`tutor/${tutorId}/directions`, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }
  public async enrollDirection(id: number): Promise<{
    tutorName: string;
  }> {
    const response = await axiosInstance.post(
      `directions/${id}/students`,
      {},
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) throw new Error(response.status.toString());
    return response.data;
  }

  async becomeTutor(id: number): Promise<void> {
    const response = await axiosInstance.post(
      `directions/${id}/tutors`,
      {},
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }

  public async unsubscribeTutor(id: number): Promise<void> {
    const response = await axiosInstance.delete(`directions/${id}/tutors`, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }

  public async createDirection(
    createDirectionData: ICreateDirectionData
  ): Promise<void> {
    const response = await axiosInstance.post(
      'directions',
      createDirectionData,
      { headers: { ...this.getAuthHeader() } }
    );
    if (response.status != 200) throw new Error(response.status.toString());
  }

  public async updateDirection(
    updateDirection: IUpdateDirectionData,
    id: string
  ): Promise<void> {
    const response = await axiosInstance.put(
      `directions/${id}`,
      updateDirection,
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status != 200) throw new Error(response.status.toString());
  }

  public async deleteDirection(id: string) {
    const response = await axiosInstance.delete(`directions/${id}`, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status != 200) throw new Error(response.status.toString());
  }

  public async getQuestions(id: string): Promise<IQuestionResponse> {
    const response = await axiosInstance.get(`directions/${id}/questions`, {
      headers: {
        ...this.getAuthHeader(),
      },
    });
    if (response.status != 200) {
      throw response.status;
    }
    return response.data;
  }
  public async getStudents(
    directId: number,
    page: number
  ): Promise<IStudentResponse> {
    const response = await axiosInstance.get(
      `directions/${directId}/students?limit=${LIMIT_ON_PAGE}&page=${page}`,
      {
        headers: {
          ...this.getAuthHeader(),
        },
      }
    );
    if (response.status !== 200) {
      throw response.status;
    }
    return response.data;
  }
}

export const directionApi = new DirectionAPI();
