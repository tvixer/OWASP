import React, { FC } from 'react';

import { TutorDirections } from '../../components/TutorDirections';
import { MyCard } from '../../containers/MyCard/MyCard';

export const TutorDirectionsPage: FC = () => {
  return (
    <MyCard title={'Мои направления'}>
      <TutorDirections />
    </MyCard>
  );
};
