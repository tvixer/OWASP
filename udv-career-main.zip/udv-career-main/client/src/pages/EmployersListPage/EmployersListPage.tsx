import { Box, Button, Snackbar, TextField, Typography } from '@mui/material';
import { observer } from 'mobx-react';
import React, { FC, useContext, useState } from 'react';

import { accountApi } from '../../api/accountAPI';
import { utils } from '../../common/utils';
import {
  EmployersList,
  EmployersType,
} from '../../components/EmployersList/EmployersList';
import { MyModal } from '../../components/MyModal/MyModal';
import { TabDirection } from '../../components/TabDirection';
import { MyCard } from '../../containers/MyCard/MyCard';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';

const EmployersListPage: FC = () => {
  const [openModal, setOpenModal] = useState(false);
  const [email, setEmail] = useState('');
  const [errorEmail, setErrorEmail] = useState('');
  const [openSnackBar, setOpenSnackBar] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [activePage, setActivePage] = useState(1);
  const {
    appStore: { employersListStore },
  } = useContext<AppStoreContext>(StoreCtx);

  const getEmployerType = () =>
    window.location.pathname.split('/')[2] === 'hr' ? 'hr' : 'tutor';

  const handleCreate = async () => {
    try {
      setIsLoading(true);
      await accountApi.registerHRTutor(email, getEmployerType());
      await employersListStore.getEmployers(
        getEmployerType() === 'hr' ? EmployersType.HR : EmployersType.Tutor,
        activePage
      );
      setOpenModal(false);
      setEmail('');
      setOpenSnackBar(true);
    } catch (e) {
      typeof e === 'string'
        ? setError(e as string)
        : setError('Произошла неизвестная ошибка');
    } finally {
      setIsLoading(false);
    }
  };
  const renderModal = () => {
    return (
      <>
        <TextField
          onChange={(e) => {
            setError('');
            if (!utils.validateEmail(e.target.value)) {
              setErrorEmail('Неправильный email');
            } else {
              setErrorEmail('');
            }
            setEmail(e.target.value);
          }}
          value={email}
          type={'email'}
          placeholder={'email'}
          error={!!errorEmail}
          helperText={errorEmail}
        />
        <Typography margin={'13px 0'} height={'21px'} variant={'subtitle2'}>
          {error}
        </Typography>
        <Button
          variant={'contained'}
          onClick={handleCreate}
          disabled={!!errorEmail || isLoading}
        >
          Создать
        </Button>
      </>
    );
  };

  return (
    <MyCard title={'HR и Курторы'}>
      <Box justifyContent={'end'} display={'flex'}>
        <Button
          sx={{ width: 330, height: 53, marginBottom: 2 }}
          variant={'contained'}
          onClick={() => setOpenModal(true)}
        >
          Создать
        </Button>
      </Box>
      <TabDirection
        tabs={[
          {
            label: 'HR',
            urlPath: EmployersType.HR,
            content: (
              <EmployersList
                setActivePage={setActivePage}
                activePage={activePage}
                employerType={EmployersType.HR}
              />
            ),
          },
          {
            label: 'Кураторы',
            urlPath: EmployersType.Tutor,
            content: (
              <EmployersList
                setActivePage={setActivePage}
                activePage={activePage}
                employerType={EmployersType.Tutor}
              />
            ),
          },
        ]}
        defaultUrl={EmployersType.HR}
        maxTabsWidth={460}
        grey
      />
      <MyModal
        title={getEmployerType() === 'hr' ? 'Новый HR' : 'Новый куратор'}
        open={openModal}
        onClose={() => setOpenModal(false)}
      >
        {renderModal()}
      </MyModal>
      <Snackbar
        open={openSnackBar}
        autoHideDuration={5000}
        onClose={() => setOpenSnackBar(false)}
        message={`${getEmployerType() === 'hr' ? 'Новый HR' : 'Новый куратор'}
          успешно зарегистрирован`}
      />
    </MyCard>
  );
};

const EmployersListPageWrapped = observer(EmployersListPage);
export { EmployersListPageWrapped as EmployersListPage };
