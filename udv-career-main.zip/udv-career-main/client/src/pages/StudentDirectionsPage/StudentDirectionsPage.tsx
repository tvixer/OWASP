import { FC } from 'react';

import { StudentDirections } from '../../components/StudentDirections';
import { MyCard } from '../../containers/MyCard/MyCard';

export const StudentDirectionsPage: FC = () => {
  return (
    <MyCard title={'Мои направления'}>
      <StudentDirections />
    </MyCard>
  );
};
