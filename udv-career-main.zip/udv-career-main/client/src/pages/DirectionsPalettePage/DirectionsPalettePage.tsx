import { Pagination } from '@mui/material';
import { observer } from 'mobx-react';
import React, { FC, useContext, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

import { directionApi } from '../../api/directionAPI';
import { utils } from '../../common/utils';
import { DirectionsPalette } from '../../components/DirectionsPalette/DirectionsPalette';
import { MyCard } from '../../containers/MyCard/MyCard';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import { Department, IDirectionData } from '../../types/directionTypes';

const DirectionsPalettePage: FC = () => {
  const [directions, setDirections] = useState<IDirectionData[]>();
  const [activePage, setActivePage] = useState(1);
  const [countPage, setCountPage] = useState(1);
  const { department } = useParams();
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);

  useEffect(() => {
    (async () => {
      const response = await directionApi.getDirections(
        activePage,
        department as Department
      );
      setDirections(response.items);
      setCountPage(utils.getCountPage(response.total));
    })();
  }, [activePage, department]);

  return (
    <MyCard title={'Все направления'}>
      {directions && (
        <DirectionsPalette
          directions={directions}
          showAddTile={authStore.role === 'Hr'}
        />
      )}
      {countPage > 1 && (
        <Pagination
          page={activePage}
          count={countPage}
          onChange={(_, value) => setActivePage(value)}
          hidePrevButton
          hideNextButton
        />
      )}
    </MyCard>
  );
};

const DirectionsPalettePageWrapped = observer(DirectionsPalettePage);
export { DirectionsPalettePageWrapped as DirectionsPalettePage };
