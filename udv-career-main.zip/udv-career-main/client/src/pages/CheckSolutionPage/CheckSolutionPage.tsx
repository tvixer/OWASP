import {
  Box,
  Button,
  Snackbar,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import React, { FC, useCallback, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

import { solutionApi } from '../../api/solutionAPI';
import { utils } from '../../common/utils';
import { CommentsBlock } from '../../components/CommentsBlock/CommentsBlock';
import { SelectField } from '../../components/SelectField';
import { MyCard } from '../../containers/MyCard/MyCard';
import {
  IAnswerWithQuestion,
  ISolutionDetailedData,
  SolutionStatus,
} from '../../types/solutionsTypes';

const statusCompare: Record<SolutionStatus, string> = {
  OnCheck: 'На рассмотрении',
  Approved: 'Принято',
  Rejected: 'Отклонено',
  NotStarted: '',
};
export const CheckSolutionPage: FC = () => {
  const { solutionId } = useParams();
  const [status, setStatus] = useState<SolutionStatus>('OnCheck');
  const [solution, setSolution] = useState<ISolutionDetailedData>();
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [openSnackBar, setOpenSnackBar] = useState(false);

  useEffect(() => {
    solutionId && getSolution(solutionId);
  }, [solutionId]);

  const getSolution = async (id: string) => {
    const sol = await solutionApi.getSolution(id);
    setSolution(sol);
    setStatus(sol.status);
  };
  const handleSubmit = async () => {
    setSuccess('');
    setError('');
    setIsLoading(true);
    try {
      solutionId &&
        (await solutionApi.makeVerdict(solutionId, {
          status,
          message: feedback,
        }));
      setSuccess('Сохранено!');
      status === 'Approved' && setOpenSnackBar(true);
      solutionId && getSolution(solutionId);
    } catch (e) {
      setError('Что-то пошло не так');
    } finally {
      setIsLoading(false);
    }
  };

  const renderAnswer = useCallback(
    (answer: IAnswerWithQuestion) => {
      return (
        <Stack spacing={1} marginTop={3}>
          <Typography marginLeft={2} fontSize={24} color={'#6F6F6F'}>
            {answer.questionText}
          </Typography>{' '}
          <TextField
            multiline
            minRows={2}
            value={answer.text}
            sx={{
              '.MuiInputBase-root': {
                paddingLeft: '20px',
              },
            }}
            placeholder={'Ваш ответ...'}
            disabled
          />
        </Stack>
      );
    },
    [solution]
  );

  return (
    <MyCard
      title={`${solution?.student.fullname} от ${
        solution?.sentAt && utils.formatDate(solution.sentAt)
      }`}
      style={{ paddingBottom: 165 }}
      showBack
    >
      <>
        {solution &&
          solution.answers.map((answer) => {
            return renderAnswer(answer);
          })}
      </>
      {utils.getId() == solution?.tutor.id && (
        <>
          <Box>
            {solution && solution.status === 'OnCheck' ? (
              <TextField
                defaultValue={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                variant={'filled'}
                multiline
                minRows={6}
                placeholder={'Комментарий'}
                sx={{
                  marginTop: 3,
                  '.MuiInputBase-root': {
                    paddingLeft: 3,
                  },
                }}
              />
            ) : (
              solution && (
                <Box
                  sx={{
                    backgroundColor: '#F3F3F3',
                    borderRadius: 6,
                    marginTop: 4,
                  }}
                >
                  <CommentsBlock
                    firstUser={solution.tutor}
                    secondUser={solution.student}
                    solutionId={solutionId!}
                  />
                </Box>
              )
            )}
          </Box>
          <Stack
            marginTop={4}
            spacing={2}
            display={'flex'}
            justifyContent={'end'}
            direction={'row'}
          >
            <Box flexBasis={390}>
              {solution && (
                <SelectField
                  defaultId={solution.status}
                  placeholder={statusCompare[status]}
                  options={[
                    {
                      label: statusCompare.OnCheck,
                      id: 'OnCheck' as SolutionStatus,
                    },
                    {
                      label: statusCompare.Approved,
                      id: 'Approved' as SolutionStatus,
                    },
                    {
                      label: statusCompare.Rejected,
                      id: 'Rejected' as SolutionStatus,
                    },
                  ]}
                  onChange={(option) => {
                    setStatus(option.id as SolutionStatus);
                  }}
                />
              )}
            </Box>
            <div
              style={{ flexBasis: 280 }}
              title={'Перед сохранением выберите статус слева'}
            >
              <Button
                onClick={handleSubmit}
                fullWidth
                variant={'contained'}
                disabled={
                  status === 'OnCheck' ||
                  (solution && solution.status === 'OnCheck' && !feedback) ||
                  isLoading
                }
              >
                Сохранить
              </Button>
            </div>
          </Stack>
        </>
      )}
      {success && (
        <Typography
          paddingRight={12}
          marginTop={2}
          textAlign={'right'}
          variant={'subtitle1'}
        >
          {success}
        </Typography>
      )}
      {error && (
        <Typography
          paddingRight={12}
          marginTop={2}
          textAlign={'right'}
          variant={'subtitle2'}
        >
          {error}
        </Typography>
      )}
      {solution && (
        <Snackbar
          open={openSnackBar}
          autoHideDuration={5000}
          onClose={() => setOpenSnackBar(false)}
          message={`Мест на направлении осталось: ${
            solution.availablePlaces - 1
          }`}
        />
      )}
    </MyCard>
  );
};
