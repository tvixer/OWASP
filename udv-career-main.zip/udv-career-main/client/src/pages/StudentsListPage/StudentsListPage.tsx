import { Box, Button, Typography } from '@mui/material';
import React, { createRef, FC, useEffect, useState } from 'react';

import { directionApi } from '../../api/directionAPI';
import { studentsApi } from '../../api/studentsAPI';
import { utils } from '../../common/utils';
import { StudentsList } from '../../components/StudentsList/StudentsList';
import { TabDirection } from '../../components/TabDirection';
import { MyCard } from '../../containers/MyCard/MyCard';
import { IDirectionData } from '../../types/directionTypes';

export const StudentsListPage: FC = () => {
  const [directions, setDirections] = useState<IDirectionData[]>();
  const link = createRef<HTMLAnchorElement>();

  useEffect(() => {
    (async () => {
      const total = (await directionApi.getDirections(1, undefined, 1)).total;
      setDirections(
        (await directionApi.getDirections(1, undefined, total)).items
      );
    })();
  }, []);

  const createReport = async () => {
    const result = studentsApi.getReport();

    const blob = await result;
    const href = window.URL.createObjectURL(new Blob([blob]));
    console.log(href);
    if (link.current) {
      const date = new Date();
      link.current.download = `reportAt${date.getFullYear()}_${date.getMonth()}_${date.getDate()}.xlsx`;
      link.current.href = href;
    }
    link.current?.click();
  };

  return (
    <MyCard title={'Список студентов'}>
      <Box justifyContent={'end'} display={'flex'}>
        <Button
          sx={{ width: 330, height: 53, marginBottom: 2 }}
          variant={'contained'}
          onClick={createReport}
        >
          Сформировать отчёт
        </Button>
        <a hidden href="" ref={link}></a>
      </Box>
      {directions && (
        <>
          {directions.length !== 0 ? (
            <TabDirection
              tabs={directions?.map((direct) => {
                return {
                  label: utils.ellipses(direct.title, 15),
                  urlPath: direct.id.toString(),
                  content: <StudentsList directionId={direct.id} />,
                };
              })}
              defaultUrl={directions[0].id.toString()}
              grey
            />
          ) : (
            <Typography variant={'h5'} align={'center'}>
              Нет направлений :(
            </Typography>
          )}
        </>
      )}
    </MyCard>
  );
};
