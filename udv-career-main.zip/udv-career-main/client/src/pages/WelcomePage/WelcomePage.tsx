import MenuIcon from '@mui/icons-material/Menu';
import { Button, Drawer, MenuItem } from '@mui/material';
import { animated, useSpring } from '@react-spring/web';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import Carousel from 'react-material-ui-carousel';

import { directionApi } from '../../api/directionAPI';
import { AUTH_PAGE_PATH } from '../../common/utils';
import { Animated } from '../../components/Animated/Animated';
import { DirectionTile } from '../../components/DirectionTile/DirectionTile';
import { Department, IDirectionData } from '../../types/directionTypes';
import iscraMan from './img/iskraman.png';
import PC from './img/PC.png';
import katya from './img/reviews/katya.jpg';
import nastya from './img/reviews/nastya.jpg';
import tanya from './img/reviews/tanya.png';
import hrImg from './img/steps/hr.svg';
import readyImg from './img/steps/ready.svg';
import regImg from './img/steps/registration.svg';
import taskImg from './img/steps/task.svg';
import ucsbLogo from './img/ucsbLogo.png';
import udvImg from './img/udvLogo.png';
import classes from './styles.module.scss';

interface IReview {
  description: string;
  contact: string;
  img: string;
}

const reviews: IReview[] = [
  {
    description:
      'Проходила практику в качестве дизайнера. Со своей командой мы проходили курс проектной разработки от UDV, и в команде я тоже была дизайнером, получила награду за лучшего дизайнера, поэтому мне понравилась компания, и я решила сюда пойти на практику.',
    contact: 'Татьяна Вострецова, ИРИТ-РТФ, 3 курс',
    img: tanya,
  },
  {
    description:
      'Проходила практику в UDV в продукте CL DATAPK в качестве дизайнера.\n' +
      'Я проходила курсы по графическому дизайну UI/UX дизайну от UDV. Оттуда и узнала  про практику. \n' +
      'Практика прошла достаточно просто, потому что мне было очень интересно. Мне понравилось, что давали задачи не просто какие-то в стол, а реальную практику, которая пригодятся в дальнейшем. \n',
    contact: 'Анастасия Черепанова, ИРИТ-РТФ УрФУ',
    img: nastya,
  },
  {
    description:
      'Практику проходила в департаменте системной интеграции. Изначально я обратилась к Юлии Котовой по совету моей знакомой, ей очень понравилось на практике еще год назад, и она сказала: Катя, иди, ты не пожалеешь, будет классно. И я действительно не пожалела.',
    contact: 'Екатерина, ФТИ, 4 курс',
    img: katya,
  },
];

export default function WelcomePage() {
  const [usscDirections, setUsscDirections] = useState<IDirectionData[]>([]);
  const [udvDirections, setUdvDirections] = useState<IDirectionData[]>([]);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const animationToRight = useSpring({
    from: {
      opacity: 0,
      x: -200,
    },
    to: {
      opacity: 1,
      x: 0,
    },
  });
  const animationToLeft = useSpring({
    from: {
      opacity: 0,
      x: 200,
    },
    to: {
      opacity: 1,
      x: 0,
    },
  });
  const animationToTop = useSpring({
    from: {
      opacity: 0,
      y: -200,
    },
    to: {
      opacity: 1,
      y: 0,
    },
  });
  const open = Boolean(anchorEl);
  const handleOpenMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  useEffect(() => {
    (async () => {
      setUsscDirections(
        (await directionApi.getDirections(1, Department.USSC, 6)).items
      );
      setUdvDirections(
        (await directionApi.getDirections(1, Department.UDV, 6)).items
      );
    })();
  }, []);

  return (
    <main className={classes.main}>
      <header className={clsx(classes.header, classes.horizontalFlex)}>
        <div className={classes.horizontalFlex}>
          <div className={classes.header__logos_container}>
            <img src={udvImg} alt="ucsbLogo" height={40} />
            <img src={ucsbLogo} alt="udvLogo" height={30} />
          </div>
          <nav className={classes.header__nav}>
            <a href="#usscDirections" className={classes.header__nav__item}>
              Направления УЦСБ
            </a>
            <a href="#udvDirections" className={classes.header__nav__item}>
              Направления UDV
            </a>
          </nav>
        </div>
        <div>
          <div className={classes.header__mobile}>
            <Button onClick={(e) => handleOpenMenu(e)}>
              <MenuIcon color={'secondary'} />
            </Button>
            <Drawer
              onClose={() => handleCloseMenu()}
              open={open}
              disableRestoreFocus
              anchor={'right'}
              PaperProps={{
                sx: {
                  backgroundColor: '#fff',
                  borderRadius: 0,
                },
              }}
            >
              <a href="#usscDirections">
                <MenuItem className={classes.header__mobile__item}>
                  Направления УЦСБ
                </MenuItem>
              </a>
              <a href="#udvDirections">
                <MenuItem className={classes.header__mobile__item}>
                  Направления UDV
                </MenuItem>
              </a>
              <a href={`/${AUTH_PAGE_PATH}`}>
                <MenuItem className={classes.header__mobile__item}>
                  Вход
                </MenuItem>
              </a>
            </Drawer>
          </div>
          <a
            className={clsx(classes.text, classes.header__link)}
            href={`/${AUTH_PAGE_PATH}`}
          >
            Вход
          </a>
        </div>
      </header>
      <div className={classes.centerContainer}>
        <article className={clsx(classes.horizontalFlex, classes.first)}>
          <animated.img
            src={PC}
            style={animationToRight}
            className={classes.first__img}
            alt="компики"
          />
          <animated.div
            style={animationToLeft}
            className={classes.verticalFlex}
          >
            <h1 className={classes.first__title}>
              <span>USUMMER&nbsp;SCHOOL</span>
              <br />
              ЛЕТНЯЯ&nbsp;ПРАКТИКА ДЛЯ СТУДЕНТОВ
            </h1>
            <a
              href="/registration"
              className={clsx(classes.first__link, classes.horizontalFlex)}
            >
              Зарегистрироваться
            </a>
          </animated.div>
        </article>
        <animated.article
          style={animationToTop}
          className={clsx(classes.text, classes.aboutUCSB, classes.flexCenter)}
        >
          Важное направление деятельности компании УЦСБ - образовательные IT-
          курсы и сотрудничество со студентами. Рады видеть в наших рядах
          молодых специалистов и готовы предложить уникальные условия для
          профессионального становления
        </animated.article>
        <article className={classes.practice}>
          <Animated animDirection={'right'}>
            <section>
              <h3 className={clsx(classes.practice__title, classes.flexCenter)}>
                <div>
                  Практика в<br />
                  <span className={classes.primaryColorText}>
                    USummerSchool
                  </span>
                </div>
              </h3>
              <div className={classes.practice__listContainer}>
                <ul>
                  <li>
                    Продолжительность практики -{' '}
                    <span className={classes.primaryColorText}>1 месяц</span>
                  </li>
                  <li>
                    <span className={classes.primaryColorText}>Реальные</span>{' '}
                    рабочие задачи
                  </li>
                  <li>
                    Обучение у
                    <span className={classes.primaryColorText}>
                      {' '}
                      экспертов{' '}
                    </span>
                    компании
                  </li>
                  <li>
                    К <span className={classes.primaryColorText}>каждому</span>{' '}
                    студенту прикрепляется куратор
                  </li>
                  <li>
                    Оплата за практику{' '}
                    <span className={classes.primaryColorText}>
                      НЕ производится
                    </span>
                  </li>
                  <li>
                    Лучшие студенты получают овозможность{' '}
                    <span className={classes.primaryColorText}>
                      пройти стажировку в компании
                    </span>
                  </li>
                </ul>
                <div className={classes.practice__listFooter}>
                  Практика в{' '}
                  <span className={classes.primaryColorText}>
                    USummer School
                  </span>{' '}
                  может стать хорошей базой для преддипломной практики, а диплом
                  имеет шансы стать уже рабочей задачей.
                </div>
              </div>
            </section>
          </Animated>
          <Animated animDirection={'left'}>
            <section>
              <h3 className={clsx(classes.practice__title, classes.flexCenter)}>
                <div>
                  Стажировка в<br />
                  <span className={classes.primaryColorText}>
                    USummerSchool
                  </span>
                </div>
              </h3>
              <div className={classes.practice__listContainer}>
                <ul>
                  <li>
                    Стажировка проходит на{' '}
                    <span className={classes.primaryColorText}>
                      реальных проектах
                    </span>{' '}
                    c наставниками
                  </li>
                  <li>
                    После прохождения стажировки, студенты{' '}
                    <span className={classes.primaryColorText}>
                      трудоустраиваются
                    </span>{' '}
                    в штат компании и получают{' '}
                    <span className={classes.primaryColorText}>
                      заработную плату
                    </span>
                  </li>
                  <li>
                    Возможность составить{' '}
                    <span className={classes.primaryColorText}>
                      индивидуальный график работы
                    </span>{' '}
                    по согласованию с руководителем, для комфортного совмещения
                    стажировки и учебы в вузе.
                  </li>
                </ul>
                <div className={classes.practice__listFooter}>
                  Стажировка в{' '}
                  <span className={classes.primaryColorText}>
                    USummer School
                  </span>{' '}
                  - это начало карьеры в крупной IT-компании и последующее
                  развитие в сфере IT
                </div>
              </div>
            </section>
          </Animated>
        </article>
      </div>
      <article className={clsx(classes.how__wrapper, classes.flexCenter)}>
        <div className={classes.how}>
          <h3 className={classes.how__title}>
            Как попасть на
            <span className={classes.primaryColorText}> практику</span> или
            <span className={classes.primaryColorText}> стажировку</span>?
          </h3>
          <div className={classes.how__steps}>
            <img src={iscraMan} alt="искрачел" />
            <Animated animDirection={'right'}>
              <section className={classes.how__step}>
                <img src={regImg} alt="Регистрация" />
                <div className={classes.how__step__content}>
                  <h4 className={classes.how__step__title}>
                    ШАГ 1 — Регистрация
                  </h4>
                  <p>
                    Первым делом нужно зарегистрироваться и<br />
                    заполнить анкету
                  </p>
                </div>
              </section>
            </Animated>
            <Animated animDirection={'left'}>
              <section className={classes.how__step}>
                <img src={taskImg} alt="Тестовое задание" />
                <div className={classes.how__step__content}>
                  <h4 className={classes.how__step__title}>
                    ШАГ 2 — Тестовое задание
                  </h4>
                  <p>
                    Затем можно изучить направления, записаться на понравившиеся
                    и приступить к выполнению тестового задания{' '}
                  </p>
                </div>
              </section>
            </Animated>
            <Animated animDirection={'right'}>
              <section className={classes.how__step}>
                <img src={hrImg} alt="Собеседование с HR" />
                <div className={classes.how__step__content}>
                  <h4 className={classes.how__step__title}>
                    ШАГ 3 — Собеседование с HR
                  </h4>
                  <p>
                    После успешного выполнения тестового задания ждите
                    приглашения на собеседование с HR
                  </p>
                </div>
              </section>
            </Animated>
            <Animated animDirection={'left'}>
              <section className={classes.how__step}>
                <img src={readyImg} alt="Готово" />
                <div className={classes.how__step__content}>
                  <h4 className={classes.how__step__title}>ШАГ 4 — Готово!</h4>
                  <p>
                    Как сложно думать ну тут тип вооот умничка ты попал на
                    стажировку крутой
                  </p>
                </div>
              </section>
            </Animated>
          </div>
        </div>
      </article>
      <div className={classes.centerContainer}>
        <div>
          <article id={'usscDirections'} className={classes.directions}>
            <h4 className={classes.directions__title}>Направления УЦСБ</h4>
            <div className={classes.directions__list}>
              {usscDirections.map((direction) => (
                <DirectionTile
                  description={direction.description}
                  title={direction.title}
                  id={direction.id}
                  availablePlaces={direction.availablePlaces}
                  isActive={direction.isActive}
                  department={direction.department}
                />
              ))}
            </div>
          </article>
          <article id={'udvDirections'} className={classes.directions}>
            <h4 className={classes.directions__title}>Направления UDV</h4>
            <div className={classes.directions__list}>
              {udvDirections.map((direction) => (
                <DirectionTile
                  description={direction.description}
                  title={direction.title}
                  id={direction.id}
                  availablePlaces={direction.availablePlaces}
                  isActive={direction.isActive}
                  department={direction.department}
                />
              ))}
            </div>
          </article>
        </div>
        <article className={classes.review}>
          <h4 className={classes.review__title}>Отзывы</h4>
          <Animated animDirection={'top'}>
            <Carousel
              animation={'slide'}
              className={classes.review__carousel}
              autoPlay={false}
            >
              {reviews.map((review) => (
                <section
                  className={clsx(classes.review__item, classes.flexCenter)}
                >
                  <div className={classes.review__item__content}>
                    <p className={classes.review__item__decription}>
                      {review.description}
                    </p>
                    <div className={classes.review__item__contact}>
                      {review.contact}
                    </div>
                  </div>
                  <div
                    className={classes.review__item__img}
                    style={{ backgroundImage: `url(${review.img})` }}
                  ></div>
                </section>
              ))}
            </Carousel>
          </Animated>
        </article>
      </div>
      <footer className={classes.footer}>
        <div className={classes.footer__content}>
          <div>© 2023 UDV x USSC</div>
          <div>
            <a href={'mailto: hr@udv.dev'}>hr@udv.dev</a>
            <div>Россия, 620100, г. Екатеринбург, ул. Ткачей, 6</div>
          </div>
        </div>
      </footer>
    </main>
  );
}
