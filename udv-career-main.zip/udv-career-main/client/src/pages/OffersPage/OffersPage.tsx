import { FC } from 'react';

import { OffersList } from '../../components/OffersList/OffersList';
import { MyCard } from '../../containers/MyCard/MyCard';

export const OffersPage: FC = () => {
  return (
    <MyCard title={'Приглашения'}>
      <OffersList />
    </MyCard>
  );
};
