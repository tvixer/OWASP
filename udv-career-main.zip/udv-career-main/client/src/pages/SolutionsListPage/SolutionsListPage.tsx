import { Box, CircularProgress, Container, Typography } from '@mui/material';
import React, { FC, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { directionApi } from '../../api/directionAPI';
import { utils } from '../../common/utils';
import { SolutionsList } from '../../components/SolutionsList';
import { TabDirection } from '../../components/TabDirection';
import { IDirectionData } from '../../types/directionTypes';
import classes from './styles.module.scss';

export const SolutionsListPage: FC = () => {
  const [directs, setDirects] = useState<IDirectionData[]>();
  const [loading, setLoading] = useState(true);

  const getDirections = async () => {
    setDirects(await directionApi.getTutorDirections(utils.getId()));
    setLoading(false);
  };

  useEffect(() => {
    getDirections();
  }, []);

  return (
    <div className={classes.mainContainer}>
      {loading ? (
        <Container>
          <Box display={'flex'} justifyContent={'center'}>
            <CircularProgress />
          </Box>
        </Container>
      ) : (
        <>
          {directs && directs.length > 0 ? (
            <TabDirection
              tabs={directs?.map((direct) => {
                return {
                  label: utils.ellipses(direct.title, 15),
                  urlPath: direct.id.toString(),
                  content: <SolutionsList directionId={direct.id.toString()} />,
                  title: direct.title,
                };
              })}
              defaultUrl={directs[0] ? directs[0].id.toString() : ''}
            />
          ) : (
            <Container>
              <Typography variant={'h5'} color={'#222'}>
                Чтобы увидедеть работы студентов{' '}
                <Link to={'/myDirections'}>
                  <Typography
                    variant={'h5'}
                    color={'primary'}
                    sx={{ display: 'inline' }}
                  >
                    закрепитесь{' '}
                  </Typography>
                </Link>
                за направлением.
              </Typography>
            </Container>
          )}
        </>
      )}
    </div>
  );
};
