import {
  Button,
  Link,
  Snackbar,
  Stack,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import { observer } from 'mobx-react';
import React, { FC, useCallback, useContext, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import { directionApi } from '../../api/directionAPI';
import { SolutionBlock } from '../../components/SolutionBlock/SolutionBlock';
import { MyCard } from '../../containers/MyCard/MyCard';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';
import { Department, IDirectionData } from '../../types/directionTypes';

const DirectionPage: FC = () => {
  const { directionId } = useParams();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  const [enrollError, setEnrollError] = useState('');
  const [direction, setDirection] = useState<IDirectionData>({
    studentIsEnrolled: false,
    title: '',
    availablePlaces: 0,
    description: '',
    id: 0,
    finishAcceptingAt: 0,
    status: 'NotStarted',
    isActive: true,
    department: Department.UDV,
  });
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);

  const studentEnroll = useCallback(async () => {
    if (!authStore.isAuthorized) {
      return navigate('/registration');
    }
    if (!direction.studentIsEnrolled) {
      if (directionId) {
        try {
          await directionApi.enrollDirection(+directionId);
          getDirection();
        } catch (e) {
          console.error(e);
          setEnrollError(
            'Пока что нельзя записаться на данное направление ☹. Попробуйте позже'
          );
        }
      }
    }
  }, [authStore.isAuthorized, direction]);

  const getDirection = async () => {
    setDirection(await directionApi.getDirection(directionId!));
  };

  useEffect(() => {
    (async () => {
      try {
        if (!directionId) {
          window.location.href = '404';
          return;
        }
        getDirection();
      } catch (e) {
        if (e === 404) {
          window.location.href = '404';
        }
        console.error(e);
      }
    })();
  }, []);

  const renderButton = useCallback(() => {
    const style = !isMobile ? { width: 200 } : undefined;
    switch (authStore.role) {
      case 'Hr':
        return (
          <Button
            style={style}
            variant={'contained'}
            onClick={() => navigate(`/direction/edit/${direction.id}`)}
          >
            Изменить
          </Button>
        );
      case 'StudentNotFilled':
        return (
          <Typography textAlign={'center'} variant={'body2'} maxWidth={250}>
            Чтобы записаться на&nbsp;направление
            <br />
            <Link
              sx={{ cursor: 'pointer' }}
              onClick={() => navigate('/profile/personalData')}
            >
              заполните профиль
            </Link>
          </Typography>
        );
      case 'Student':
        return (
          <Button
            style={style}
            variant={'contained'}
            onClick={studentEnroll}
            disabled={direction.studentIsEnrolled}
          >
            {direction.studentIsEnrolled ? 'Вы записаны' : 'Записаться'}
          </Button>
        );
      case null:
        return (
          <Button
            style={style}
            variant={'contained'}
            onClick={() => navigate('/auth')}
          >
            Записаться
          </Button>
        );
      default:
        return null;
    }
  }, [authStore.role, direction]);

  return (
    <MyCard title={isMobile ? direction.title : undefined} showBack>
      <Stack spacing={isMobile ? 1 : 5}>
        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          justifyContent={'space-between'}
          spacing={3}
          padding={isMobile ? '25px 15px' : '12px 0 24px'}
          sx={{
            backgroundColor: isMobile ? '#F3F3F3' : 'unset',
            borderRadius: 4,
          }}
        >
          <Stack flexGrow={1}>
            {!isMobile && (
              <Typography
                sx={{
                  paddingBottom: 2,
                  borderBottom: '5px solid #d9d9d9',
                }}
                variant={'h5'}
              >
                {direction.title}
              </Typography>
            )}
            <Typography
              marginTop={2}
              variant={'body2'}
              whiteSpace={'break-spaces'}
            >
              {direction.description}
            </Typography>
          </Stack>
          <Stack spacing={2}>
            <div>
              <Typography
                textAlign={isMobile ? 'left' : 'center'}
                variant={'h1'}
                fontSize={50}
                lineHeight={1}
                whiteSpace={'nowrap'}
              >
                {direction.availablePlaces}
              </Typography>
              <Typography
                textAlign={isMobile ? 'left' : 'center'}
                variant={'h1'}
                fontSize={40}
                lineHeight={1}
                whiteSpace={'nowrap'}
              >
                мест
              </Typography>
            </div>
            {!isMobile && renderButton()}
          </Stack>
          {isMobile && renderButton()}
        </Stack>
        <Snackbar
          open={!!enrollError}
          message={enrollError}
          autoHideDuration={3000}
          onClose={() => setEnrollError('')}
        />
        {authStore.role === 'Student' && direction.studentIsEnrolled && (
          <SolutionBlock
            directionId={directionId!}
            status={direction.status}
            solutionId={direction.solutionId?.toString()}
            finishAcceptingAt={direction.finishAcceptingAt}
            onFinish={getDirection}
          />
        )}
      </Stack>
    </MyCard>
  );
};

const DirectionPageWrapped = observer(DirectionPage);
export { DirectionPageWrapped as DirectionPage };
