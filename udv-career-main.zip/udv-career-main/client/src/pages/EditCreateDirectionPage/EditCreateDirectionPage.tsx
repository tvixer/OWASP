import {
  Box,
  Button,
  Snackbar,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import moment, { Moment } from 'moment';
import React, { FC, useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import { directionApi } from '../../api/directionAPI';
import { MyModal } from '../../components/MyModal/MyModal';
import { SwitchField } from '../../components/SwitchField';
import { MyCard } from '../../containers/MyCard/MyCard';
import { Department, IQuestion } from '../../types/directionTypes';
import classes from './styles.module.scss';

export const EditCreateDirectionPage: FC<{ changing?: boolean }> = ({
  changing,
}) => {
  const [isActive, setIsActive] = useState(true);
  const [title, setTitle] = useState('');
  const [finishingAcceptingAtDate, setFinishingAcceptingAtDate] =
    useState<Moment | null>(null);
  const [description, setDescription] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [department, setDepartment] = useState<Department>(Department.USSC);
  const [willBeAcceptedCount, setWillBeAcceptedCount] = useState<number | ''>(
    ''
  );
  const [questions, setQuestions] = useState<IQuestion[]>([
    { id: 0, text: '' },
  ]);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [openModal, setOpenModal] = useState(false);
  const [disableBtn, setDisableBtn] = useState(true);
  const { directionId } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (changing) {
      getDirectionInfo();
    }
  }, []);
  //валидация
  useEffect(() => {
    const valArr = [
      title,
      description,
      finishingAcceptingAtDate,
      willBeAcceptedCount,
      questions.map((quest) => quest.text).join(),
    ];
    setDisableBtn(valArr.filter((value) => value).length !== valArr.length);
  }, [
    title,
    description,
    finishingAcceptingAtDate,
    willBeAcceptedCount,
    isActive,
    questions,
    department,
  ]);

  const getDirectionInfo = async () => {
    if (directionId) {
      try {
        const dir = await directionApi.getDirection(directionId);
        const questResponse = await directionApi.getQuestions(directionId);
        setQuestions(questResponse.questions);
        setTaskDescription(questResponse.taskDescription);
        setDescription(dir.description);
        setTitle(dir.title);
        setIsActive(dir.isActive);
        setFinishingAcceptingAtDate(moment(dir.finishAcceptingAt).utc());
        setWillBeAcceptedCount(dir.availablePlaces);
        setDepartment(dir.department);
      } catch (e) {
        console.error(e);
      }
    }
  };

  const deleteDirection = async () => {
    directionId && (await directionApi.deleteDirection(directionId));
    navigate('/');
  };

  const createDirection = useCallback(async () => {
    try {
      await directionApi.createDirection({
        title,
        description,
        willBeAcceptedCount: willBeAcceptedCount || 0,
        endedAt: finishingAcceptingAtDate?.utc().valueOf(),
        isActive,
        questions: questions.map((quest) => quest.text),
        taskDescription,
        department,
      });
      setTitle('');
      setDescription('');
      setQuestions([{ id: 0, text: '' }]);
      setFinishingAcceptingAtDate(null);
      setWillBeAcceptedCount('');
      setTaskDescription('');
      setDepartment(Department.USSC);
      setSuccess('Направление успешно создано!');
    } catch (e) {
      console.error(e);
      setError('Произошла ошибка');
    } finally {
      setTimeout(() => {
        setSuccess('');
        setError('');
      }, 10000);
    }
  }, [
    isActive,
    title,
    finishingAcceptingAtDate,
    description,
    willBeAcceptedCount,
    taskDescription,
    questions,
    department,
  ]);

  const updateDirection = useCallback(async () => {
    try {
      await directionApi.updateDirection(
        {
          title,
          description,
          willBeAcceptedCount: willBeAcceptedCount || 0,
          finishingAcceptingAt: finishingAcceptingAtDate?.utc().valueOf(),
          isActive,
          questions: questions.map((quest) => ({
            text: quest.text,
          })),
          taskDescription,
          department,
        },
        directionId!
      );
      setSuccess('Направление успешно изменено!');
    } catch (e) {
      console.error(e);
      setError('Произошла ошибка');
    } finally {
      setTimeout(() => {
        setSuccess('');
        setError('');
      }, 10000);
    }
  }, [
    isActive,
    title,
    finishingAcceptingAtDate,
    description,
    willBeAcceptedCount,
    taskDescription,
    questions,
    department,
  ]);

  return (
    <LocalizationProvider dateAdapter={AdapterMoment}>
      <MyCard
        title={changing ? 'Изменение направления' : 'Новое направление'}
        showBack
      >
        <div className={classes.container}>
          {changing && (
            <button
              onClick={() => setOpenModal(true)}
              className={classes.removeButton}
            >
              Удалить
            </button>
          )}
          <Stack spacing={4}>
            <TextField
              label={'Название направления'}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={'Название направления'}
            />
            <Stack direction={'row'} spacing={2}>
              <DateTimePicker
                format={'YY.MM.DD/HH:mm'}
                value={finishingAcceptingAtDate}
                onChange={(e) => setFinishingAcceptingAtDate(e)}
                label={'Дата и время сдачи'}
                sx={{ width: '33%' }}
              />
              <TextField
                value={willBeAcceptedCount}
                onChange={(e) => {
                  const count = parseInt(e.target.value);
                  isNaN(count) || count < 0
                    ? setWillBeAcceptedCount('')
                    : setWillBeAcceptedCount(count);
                }}
                label={'Места'}
                type={'number'}
                placeholder={'Места'}
                sx={{ width: '10%' }}
              />
              <Box width={'28%'}>
                <SwitchField
                  item1={{ label: 'УЦСБ', value: Department.USSC }}
                  item2={{ label: 'UDV', value: Department.UDV }}
                  defaultValue={department}
                  onChange={(current) => setDepartment(current.value)}
                />
              </Box>
              <Box width={'28%'}>
                <SwitchField
                  item1={{ label: 'Активно', value: true }}
                  item2={{ label: 'Неактивно', value: false }}
                  defaultValue={isActive}
                  onChange={(current) => setIsActive(current.value)}
                />
              </Box>
            </Stack>
            <TextField
              value={description}
              multiline
              minRows={6}
              label={'Описание'}
              sx={{
                '.MuiInputBase-root': {
                  paddingLeft: '20px',
                },
              }}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={'Описание'}
            />
            <Typography variant={'h5'} marginLeft={2}>
              Тестовое задание
            </Typography>
            <TextField
              value={taskDescription}
              label={'Описание задания'}
              multiline
              minRows={2}
              sx={{
                '.MuiInputBase-root': {
                  paddingLeft: '20px',
                },
              }}
              onChange={(e) => setTaskDescription(e.target.value)}
              placeholder={'Описание задания'}
            />
            {questions.map((question, index) => {
              return (
                <div key={question.id} className={classes.questContainer}>
                  <TextField
                    label={'Вопрос'}
                    key={question.id}
                    value={question.text}
                    placeholder={'Вопрос'}
                    sx={{
                      '.MuiInputBase-root': {
                        paddingLeft: '20px',
                      },
                    }}
                    multiline
                    onChange={(e) => {
                      setQuestions(() => {
                        const newQuestions = questions.slice(0);
                        newQuestions[index].text = e.target.value;
                        return newQuestions;
                      });
                    }}
                  />
                  {index !== 0 && (
                    <div
                      className={classes.removeQuestBtn}
                      onClick={() => {
                        setQuestions(() => {
                          const newQuestions = questions.slice(0);
                          newQuestions.splice(index, 1);
                          return newQuestions;
                        });
                      }}
                    >
                      -
                    </div>
                  )}
                </div>
              );
            })}
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
              <div
                className={classes.addQuestion}
                onClick={() => {
                  setQuestions(() => {
                    const newQuestions = questions.slice(0);
                    newQuestions.push({
                      id: questions.length !== 0 ? questions.pop()!.id + 1 : 1,
                      text: '',
                    });
                    return newQuestions;
                  });
                }}
              >
                <div>+</div>
              </div>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Button
                disabled={disableBtn}
                variant={'contained'}
                size={'large'}
                onClick={changing ? updateDirection : createDirection}
              >
                Сохранить
              </Button>
            </Box>
            {error && <Typography variant={'subtitle2'}>{error}</Typography>}
          </Stack>
        </div>
        <MyModal
          open={openModal}
          onClose={() => setOpenModal(false)}
          title={'Вы уверены, что хотите удалить направление?'}
        >
          <Stack
            direction={'row'}
            spacing={3}
            justifyContent={'space-between'}
            width={'60%'}
            margin={'0 auto'}
          >
            <Button
              color={'secondary'}
              variant={'contained'}
              onClick={deleteDirection}
              fullWidth
            >
              Удалить
            </Button>
            <Button
              fullWidth
              variant={'contained'}
              onClick={() => setOpenModal(false)}
            >
              Отменить
            </Button>
          </Stack>
        </MyModal>
      </MyCard>
      <Snackbar
        open={!!success}
        autoHideDuration={3000}
        onClose={() => setSuccess('')}
        message={success}
      />
    </LocalizationProvider>
  );
};
