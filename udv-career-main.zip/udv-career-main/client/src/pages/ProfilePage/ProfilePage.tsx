import { observer } from 'mobx-react';
import React, { FC, useCallback, useContext } from 'react';

import {
  HRTutorPersonalData,
  StudentPersonalData,
} from '../../components/PersonalData';
import { MyCard } from '../../containers/MyCard/MyCard';
import {
  AppStoreContext,
  StoreCtx,
} from '../../containers/WithStore/WithStore';

const ProfilePage: FC = () => {
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);

  const renderProfileByRole = useCallback(() => {
    switch (authStore.role) {
      case 'Student':
      case 'StudentNotFilled':
        return <StudentPersonalData />;
      case 'Hr':
      case 'Tutor':
        return <HRTutorPersonalData />;
    }
    return null;
  }, [authStore.role]);

  return <MyCard title={'Личные данные'}>{renderProfileByRole()}</MyCard>;
};

const ProfilePageWrapped = observer(ProfilePage);
export { ProfilePageWrapped as ProfilePage };
