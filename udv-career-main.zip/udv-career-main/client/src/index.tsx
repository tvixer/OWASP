import './mainStyle.scss';
import './zero.css';

import { CircularProgress, ThemeProvider } from '@mui/material';
import { observer } from 'mobx-react';
import React, { FC, lazy, Suspense, useContext } from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import { RESET_PASS_PAGE_PATH } from './common/utils';
import {
  AppStoreContext,
  StoreCtx,
  WithStore,
} from './containers/WithStore/WithStore';
import { theme } from './theme';

const WelcomePage = lazy(() => import('./pages/WelcomePage/WelcomePage'));
const Auth = lazy(() => import('./views/Auth/Auth'));
const Registration = lazy(() => import('./views/Registration/Registration'));
const RestorePass = lazy(() => import('./views/RestorePass/RestorePass'));
const App = lazy(() => import('./views/App/App'));
const OfferRestorePass = lazy(
  () => import('./views/OfferRestorePass/OfferRestorePass')
);

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

const Loading = () => (
  <div className={'loading'}>
    <CircularProgress />
  </div>
);

const Index: FC = observer(() => {
  const {
    appStore: { authStore },
  } = useContext<AppStoreContext>(StoreCtx);

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path={'/auth'}
          element={
            <Suspense fallback={Loading()}>
              <Auth />
            </Suspense>
          }
        />
        <Route
          path={'/registration'}
          element={
            <Suspense fallback={Loading()}>
              <Registration />
            </Suspense>
          }
        />
        <Route
          path={'/offer-restore-pass'}
          element={
            <Suspense fallback={Loading()}>
              <OfferRestorePass />
            </Suspense>
          }
        />
        <Route
          path={`/${RESET_PASS_PAGE_PATH}`}
          element={
            <Suspense fallback={Loading()}>
              <RestorePass />
            </Suspense>
          }
        />
        {!authStore.isAuthorized && (
          <Route
            index
            element={
              <Suspense fallback={Loading()}>
                <WelcomePage />
              </Suspense>
            }
          />
        )}
        <Route
          path={'/*'}
          element={
            <Suspense fallback={Loading()}>
              <App />
            </Suspense>
          }
        />
      </Routes>
    </BrowserRouter>
  );
});

root.render(
  <WithStore>
    <ThemeProvider theme={theme}>
      <Index />
    </ThemeProvider>
  </WithStore>
);
