import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Card, useMediaQuery } from '@mui/material';
import clsx from 'clsx';
import { CSSProperties, FC, ReactNode } from 'react';

import { theme } from '../../theme';
import classes from './styles.module.scss';

export const MyCard: FC<{
  children: ReactNode;
  title?: string;
  style?: CSSProperties;
  onBackText?: string;
  showBack?: boolean;
}> = ({ children, title, style, onBackText = 'Назад', showBack = false }) => {
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Card className={classes.container} style={style}>
      {!isMobile && showBack && (
        <div onClick={() => history.back()} className={classes.back}>
          <ArrowBackIosIcon sx={{ fontSize: '0.6rem', marginRight: '-4px' }} />{' '}
          {onBackText}
        </div>
      )}
      {title && (
        <div
          className={clsx(classes.title, {
            [classes.title__with_back]: !isMobile && showBack,
          })}
        >
          {title}
        </div>
      )}
      <div>{children}</div>
    </Card>
  );
};
