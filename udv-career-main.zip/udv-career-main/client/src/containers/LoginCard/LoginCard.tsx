import { Box } from '@mui/material';
import React, { FC, ReactNode } from 'react';

import logo from '../../logo.png';
import classes from './styles.module.scss';

export const LoginCard: FC<{ children: ReactNode; title: string }> = ({
  children,
  title,
}) => {
  return (
    <div className={classes.root}>
      <Box onClick={() => (window.location.pathname = '/')}>
        <img alt={'Лого'} src={logo} height={152} />
      </Box>
      <div className={classes.container}>
        <div className={classes.title}>{title}</div>
        {children}
      </div>
    </div>
  );
};
