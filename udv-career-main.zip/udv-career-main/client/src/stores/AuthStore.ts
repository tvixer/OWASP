import { makeAutoObservable } from 'mobx';
import { decodeToken } from 'react-jwt';

import { accountApi } from '../api/accountAPI';

enum Role {
  'Student' = 'Student',
  'Tutor' = 'Tutor',
  'Hr' = 'Hr',
  'Banned' = 'Banned',
  'StudentNotFilled' = 'StudentNotFilled',
}

export class AuthStore {
  isAuthorized: boolean;
  role: Role | null;

  constructor() {
    const authInfo = decodeToken(localStorage['authToken']) as any;
    if (authInfo == null) {
      this.isAuthorized = false;
      this.role = null;
    } else {
      this.isAuthorized = true;
      this.role = authInfo.role;
    }
    makeAutoObservable(this);
  }

  public async login(email: string, password: string) {
    const token = await accountApi.login(email, password);
    localStorage.setItem('authToken', token);
    const data = decodeToken(token) as any;
    this.isAuthorized = true;
    this.role = data.role;
  }

  public updateAuthInfo(authToken: string) {
    this.role = (decodeToken(authToken) as any).role as Role;
    localStorage.setItem('authToken', authToken);
  }
}
