import { AuthStore } from './AuthStore';
import { EmployersListStore } from './EmployersListStore';

export interface AppStore {
  authStore: AuthStore;
  employersListStore: EmployersListStore;
}

export const createAppStore = (): AppStore => ({
  authStore: new AuthStore(),
  employersListStore: new EmployersListStore(),
});
