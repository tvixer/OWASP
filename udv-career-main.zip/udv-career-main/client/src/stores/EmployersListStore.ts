import { action, makeAutoObservable } from 'mobx';

import { accountApi } from '../api/accountAPI';
import { utils } from '../common/utils';
import { EmployersType } from '../components/EmployersList/EmployersList';
import { IUserData, IUserResponse } from '../types/accountTypes';

export class EmployersListStore {
  public employers: IUserData[];

  constructor() {
    this.employers = [];
    makeAutoObservable(this);
  }

  /**
   * В сторе устанавливает список сотрудников, и возвращает количество страниц.
   * @param employerType
   * @param activePage
   */
  public async getEmployers(
    employerType: EmployersType,
    activePage: number
  ): Promise<number> {
    let response: IUserResponse;
    if (employerType === EmployersType.Tutor) {
      response = await accountApi.getUsers('Tutor', activePage);
    } else {
      response = await accountApi.getUsers('Hr', activePage);
    }

    this.setEmployers((this.employers = response.items));
    return utils.getCountPage(response.total);
  }

  @action
  setEmployers = (employers: IUserData[]) => {
    this.employers = employers;
  };
}
